/**
 * news.js - News Retrieve & Search Engine (Vanilla JS / ES Module)
 * 
 * Manages queries, search indexing, infinite-scroll page cursors,
 * and filtering on Firestore databases.
 */

import { db } from "./firebase.js";
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  limit, 
  startAfter, 
  getDocs,
  doc,
  updateDoc,
  increment 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

/**
 * Fetch news articles with support for pagination, categories, and search filters.
 * @param {Object} options 
 * @param {string} [options.category] Filter by exact Malayalam category tab
 * @param {string} [options.search] Filter by string contents (case-insensitive local matching)
 * @param {string} [options.location] Filter by reported district/location
 * @param {number} [options.pageSize] Number of items to query (e.g. 5 or 10)
 * @param {DocumentSnapshot} [options.lastDoc] The reference document cursor for infinite scroll start
 * @returns {Promise<{ articles: Array, lastVisible: DocumentSnapshot }>}
 */
export async function getNewsFeed({ 
  category = "എല്ലാം", 
  search = "", 
  location = "", 
  pageSize = 6, 
  lastDoc = null 
} = {}) {
  try {
    const newsCollection = collection(db, "news");
    let constraints = [];

    // Assemble query constraints
    if (category && category !== "എല്ലാം") {
      constraints.push(where("category", "==", category));
    }
    
    if (location) {
      constraints.push(where("location", "==", location));
    }

    // Sort newest articles first
    constraints.push(orderBy("createdAt", "desc"));
    constraints.push(limit(pageSize));

    // Page anchor token for infinite scroll
    if (lastDoc) {
      constraints.push(startAfter(lastDoc));
    }

    const q = query(newsCollection, ...constraints);
    const querySnapshot = await getDocs(q);
    
    let results = [];
    querySnapshot.forEach((doc) => {
      const data = doc.data();
      results.push({
        id: doc.id,
        ...data,
        createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : new Date().toISOString()
      });
    });

    const lastVisible = querySnapshot.docs[querySnapshot.docs.length - 1] || null;

    // Apply local search filtering if string query exists
    if (search) {
      const rawSearch = search.toLowerCase().trim();
      results = results.filter(art => 
        (art.title && art.title.toLowerCase().includes(rawSearch)) ||
        (art.description && art.description.toLowerCase().includes(rawSearch)) ||
        (art.content && art.content.toLowerCase().includes(rawSearch)) ||
        (art.location && art.location.toLowerCase().includes(rawSearch))
      );
    }

    return {
      articles: results,
      lastVisible: lastVisible
    };
  } catch (error) {
    console.error("❌ Failed to query news feed from Firestore:", error);
    throw error;
  }
}

/**
 * Perform incremental views/likes state update gates.
 * @param {string} articleId 
 * @param {"views"|"likes"|"shares"} actionType 
 */
export async function interactWithArticle(articleId, actionType) {
  try {
    const docRef = doc(db, "news", articleId);
    const updates = {};
    updates[actionType] = increment(1);
    await updateDoc(docRef, updates);
  } catch (error) {
    console.error(`❌ Failed to log ${actionType} interaction:`, error);
  }
}
