import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { NewsArticle, AdBannerType, PortalNotification } from "./src/types";

// Firebase Imports
import { initializeApp, setLogLevel } from "firebase/app";
import { 
  getFirestore, 
  collection, 
  doc, 
  getDocs, 
  getDoc,
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  limit,
  terminate
} from "firebase/firestore";

const app = express();
const PORT = 3000;

// Enable JSON bodies with higher limits for base64 image uploads
app.use(express.json({ limit: "20mb" }));
app.use(express.urlencoded({ limit: "20mb", extended: true }));

const DATA_DIR = path.join(process.cwd(), "data");
const NEWS_FILE = path.join(DATA_DIR, "news.json");
const ADS_FILE = path.join(DATA_DIR, "ads.json");
const BREAKING_FILE = path.join(DATA_DIR, "breaking.json");
const NOTIFICATIONS_FILE = path.join(DATA_DIR, "notifications.json");
const SUBSCRIBERS_FILE = path.join(DATA_DIR, "subscribers.json");
const USERS_FILE = path.join(DATA_DIR, "users.json");
const CATEGORIES_FILE = path.join(DATA_DIR, "categories.json");
const UPLOADS_DIR = path.join(DATA_DIR, "uploads");

// Ensure data persistence directories exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// ----------------------------------------------------------------------
// DYNAMIC FIREBASE SETUP
// ----------------------------------------------------------------------
let db: any = null;
let useFirebase = false;

// Graceful Firebase Error Fallback handler to handle disabled APIs or network interruptions safely
function handleFirebaseError(e: any) {
  const msg = e && e.message ? e.message : String(e);
  const isPermissionDenied = 
    msg.includes("PERMISSION_DENIED") || 
    msg.includes("Cloud Firestore API") || 
    msg.includes("disabled") || 
    msg.includes("permission-denied") ||
    msg.includes("offline");

  if (isPermissionDenied) {
    if (useFirebase) {
      console.error(`
========================================================================================
⚠️ [TNC NEWS PORTAL - FIREBASE INTEGRATION KEY DETAILS]:
Cloud Firestore API is not activated / enabled in your Google Cloud Project "tnc-news-online".

To permanent-fix this issue and enable the cloud features:
1. Open and enable the API in Google Cloud using this URL:
   https://console.developers.google.com/apis/api/firestore.googleapis.com/overview?project=tnc-news-online
2. Visit Firebase Console (https://console.firebase.google.com/), select "tnc-news-online",
   go to "Firestore Database" and click "Create database" to provision Firestore instances.

👇 [AUTONOMOUS FALLBACK RECOVERY ENGAGED] 👇
We have automatically switched TNC News to offline mode, bypassing Firebase for this run.
All articles, ads, subscribers, and comments are fully loadable from the local JSON storage.
========================================================================================
`);
      useFirebase = false;
      if (db) {
        console.log("Shutting down active Firestore connection to prevent infinite retry loops...");
        terminate(db).catch(() => {
          // Ignore termination errors since database is disabled
        });
        db = null;
      }
    }
  } else {
    console.error("Firebase Sync Exception Occurred:", e);
  }
}

try {
  let config: any = null;
  const configPath = path.join(process.cwd(), "firebase-applet-config.json");
  if (fs.existsSync(configPath)) {
    config = JSON.parse(fs.readFileSync(configPath, "utf-8"));
  } else if (process.env.FIREBASE_CONFIG) {
    config = JSON.parse(process.env.FIREBASE_CONFIG);
  } else if (process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID) {
    config = {
      apiKey: process.env.FIREBASE_API_KEY || process.env.VITE_FIREBASE_API_KEY,
      authDomain: process.env.FIREBASE_AUTH_DOMAIN || process.env.VITE_FIREBASE_AUTH_DOMAIN,
      projectId: process.env.FIREBASE_PROJECT_ID || process.env.VITE_FIREBASE_PROJECT_ID,
      storageBucket: process.env.FIREBASE_STORAGE_BUCKET || process.env.VITE_FIREBASE_STORAGE_BUCKET,
      messagingSenderId: process.env.FIREBASE_MESSAGING_SENDER_ID || process.env.VITE_FIREBASE_MESSAGING_SENDER_ID,
      appId: process.env.FIREBASE_APP_ID || process.env.VITE_FIREBASE_APP_ID
    };
  }

  const isFirebaseDisabled = process.env.DISABLE_FIREBASE === "true" || process.env.VITE_DISABLE_FIREBASE === "true";

  if (isFirebaseDisabled) {
    console.log("🚫 [TNC News Firebase Disabled]: DISABLE_FIREBASE environment variable is set to true. Offline JSON file storage is active.");
  } else if (config && config.projectId && config.projectId !== "YOUR_PROJECT_ID") {
    const firebaseApp = initializeApp(config);
    setLogLevel("error"); // Suppress info/warn logs from Firebase JS SDK
    db = getFirestore(firebaseApp);
    useFirebase = true;
    console.log(`🔥 [TNC News Firebase Active]: Connected to Firestore project: ${config.projectId}`);
  } else {
    console.log("⚠️ [TNC News Local Active]: No Firebase config detected. Offline JSON file storage is active.");
  }
} catch (e) {
  console.error("❌ Firebase failed to load. Defaulting to local JSON storage:", e);
}

// Default breaking news seed data
const defaultBreaking = [
  {
    id: "b-1",
    text: "കേരളത്തിൽ അടുത്ത 3 ദിവസത്തേക്ക് കനത്ത മഴ മുന്നറിയിപ്പ്; ജാഗ്രത കൈവിടരുത്.",
    createdAt: new Date().toISOString()
  },
  {
    id: "b-2",
    text: "വയനാട് ചുരത്തിൽ മഞ്ഞുവീഴ്ച്ച ശക്തമായി; ഡ്രൈവർമാർ വേഗത കുറയ്ക്കുക.",
    createdAt: new Date().toISOString()
  },
  {
    id: "b-3",
    text: "സംസ്ഥാന ബജറ്റിൽ പ്രവാസി സഹായധനം വർദ്ധിപ്പിച്ചു; നാളെ മുതൽ അപേക്ഷകൾ ഓൺലൈനായി സ്വീകരിക്കും.",
    createdAt: new Date().toISOString()
  },
  {
    id: "b-4",
    text: "കേരള സൂപ്പർ ലീഗ്: ബ്ലാസ്റ്റേഴ്സിന് തുടർച്ചയായ മൂന്നാം വിജയം.",
    createdAt: new Date().toISOString()
  }
];

if (!fs.existsSync(BREAKING_FILE)) {
  fs.writeFileSync(BREAKING_FILE, JSON.stringify(defaultBreaking, null, 2), "utf-8");
}

const defaultNotifications: PortalNotification[] = [
  {
    id: "notif-1",
    articleId: "news-1",
    title: "പ്രധാന വാർത്ത ⚡",
    message: "കോഴിക്കോട് കനത്ത മഴ; താഴ്ന്ന പ്രദേശങ്ങൾ വെള്ളത്തിനടിയിൽ, ജാഗ്രതാ നിർദ്ദേശം",
    createdAt: new Date().toISOString(),
    read: false
  },
  {
    id: "notif-2",
    articleId: "news-4",
    title: "കൃഷി അപ്‌ഡേറ്റ് 🌾",
    message: "പ്രാദേശിക കാർഷിക ഉത്സവം തിരുവല്ലയിൽ ആരംഭിച്ചു; പ്രകൃതിദത്ത വിപണി ലഭ്യമാക്കും",
    createdAt: new Date(Date.now() - 3600000).toISOString(),
    read: false
  }
];

if (!fs.existsSync(NOTIFICATIONS_FILE)) {
  fs.writeFileSync(NOTIFICATIONS_FILE, JSON.stringify(defaultNotifications, null, 2), "utf-8");
}

async function getNotificationsData(): Promise<PortalNotification[]> {
  if (useFirebase && db) {
    try {
      const q = query(collection(db, "notifications"), orderBy("createdAt", "desc"));
      const snapshot = await getDocs(q);
      const list: PortalNotification[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          articleId: data.articleId || undefined,
          title: data.title || "",
          message: data.message || "",
          createdAt: data.createdAt || new Date().toISOString(),
          read: !!data.read
        });
      });
      if (list.length === 0) {
        let initialNotifications = defaultNotifications;
        try {
          if (fs.existsSync(NOTIFICATIONS_FILE)) {
            const raw = fs.readFileSync(NOTIFICATIONS_FILE, "utf-8");
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              initialNotifications = parsed;
            }
          }
        } catch (e) {
          console.error("Error reading NOTIFICATIONS_FILE to seed Firestore:", e);
        }

        for (const n of initialNotifications) {
          await setDoc(doc(db, "notifications", n.id), {
            articleId: n.articleId || null,
            title: n.title,
            message: n.message,
            createdAt: n.createdAt,
            read: n.read || false
          });
          list.push(n);
        }
      }
      return list;
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(NOTIFICATIONS_FILE)) {
      return defaultNotifications;
    }
    const raw = fs.readFileSync(NOTIFICATIONS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading notifications data:", error);
    return defaultNotifications;
  }
}

async function saveNotificationsData(data: PortalNotification[]) {
  if (useFirebase && db) {
    try {
      for (const item of data) {
        await setDoc(doc(db, "notifications", item.id), {
          articleId: item.articleId || null,
          title: item.title,
          message: item.message,
          createdAt: item.createdAt,
          read: !!item.read
        }, { merge: true });
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(NOTIFICATIONS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving notifications data:", error);
  }
}

const defaultSubscribers = { count: 324 };
if (!fs.existsSync(SUBSCRIBERS_FILE)) {
  fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(defaultSubscribers, null, 2), "utf-8");
}

async function getSubscribersData(): Promise<{ count: number }> {
  if (useFirebase && db) {
    try {
      const docRef = doc(db, "metrics", "subscribers");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        const data = docSnap.data();
        return { count: data.count || 324 };
      } else {
        let initialCount = 324;
        try {
          if (fs.existsSync(SUBSCRIBERS_FILE)) {
            const raw = fs.readFileSync(SUBSCRIBERS_FILE, "utf-8");
            const parsed = JSON.parse(raw);
            if (parsed && typeof parsed.count === "number") {
              initialCount = parsed.count;
            }
          }
        } catch (e) {
          console.error("Error reading SUBSCRIBERS_FILE to seed Firestore:", e);
        }

        await setDoc(docRef, { count: initialCount });
        return { count: initialCount };
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(SUBSCRIBERS_FILE)) {
      return defaultSubscribers;
    }
    const raw = fs.readFileSync(SUBSCRIBERS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    return defaultSubscribers;
  }
}

async function saveSubscribersData(data: { count: number }) {
  if (useFirebase && db) {
    try {
      const docRef = doc(db, "metrics", "subscribers");
      await setDoc(docRef, { count: data.count });
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(SUBSCRIBERS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving subscribers:", error);
  }
}

// ----------------------------------------------------------------------
// PERSISTENT USER ACCOUNTS - LOCAL & FIREBASE PORTAL
// ----------------------------------------------------------------------
async function getUsersData(): Promise<any[]> {
  if (useFirebase && db) {
    try {
      const q = query(collection(db, "portal_users"));
      const snapshot = await getDocs(q);
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          email: doc.id,
          password: data.password || "",
          displayName: data.displayName || "",
          createdAt: data.createdAt || new Date().toISOString()
        });
      });
      return list;
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(USERS_FILE)) {
      fs.writeFileSync(USERS_FILE, JSON.stringify([], null, 2), "utf-8");
      return [];
    }
    const raw = fs.readFileSync(USERS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading users data:", error);
    return [];
  }
}

async function saveUsersData(users: any[]) {
  if (useFirebase && db) {
    try {
      for (const user of users) {
        const docRef = doc(db, "portal_users", user.email.toLowerCase());
        await setDoc(docRef, {
          password: user.password,
          displayName: user.displayName || "",
          createdAt: user.createdAt || new Date().toISOString()
        }, { merge: true });
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving users data:", error);
  }
}

async function getBreakingData(): Promise<any[]> {
  if (useFirebase && db) {
    try {
      const q = query(collection(db, "breaking_news"), orderBy("createdAt", "desc"));
      const snapshot = await getDocs(q);
      const list: any[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          text: data.text || "",
          createdAt: data.createdAt || new Date().toISOString()
        });
      });
      if (list.length === 0) {
        let initialBreaking = defaultBreaking;
        try {
          if (fs.existsSync(BREAKING_FILE)) {
            const raw = fs.readFileSync(BREAKING_FILE, "utf-8");
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              initialBreaking = parsed;
            }
          }
        } catch (e) {
          console.error("Error reading BREAKING_FILE to seed Firestore:", e);
        }

        for (const b of initialBreaking) {
          await setDoc(doc(db, "breaking_news", b.id), {
            text: b.text,
            createdAt: b.createdAt
          });
          list.push(b);
        }
      }
      return list;
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(BREAKING_FILE)) {
      return defaultBreaking;
    }
    const raw = fs.readFileSync(BREAKING_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading breaking data:", error);
    return defaultBreaking;
  }
}

async function saveBreakingData(data: any[]) {
  if (useFirebase && db) {
    try {
      for (const item of data) {
        await setDoc(doc(db, "breaking_news", item.id), {
          text: item.text,
          createdAt: item.createdAt
        }, { merge: true });
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(BREAKING_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving breaking data:", error);
  }
}

// Default advertisements seed data
const defaultAds: AdBannerType[] = [
  {
    id: "ad-kalyan",
    title: "കല്യാൺസ് ഗോൾഡ് ബമ്പർ ഓഫർ 🌟",
    subtitle: "പണിക്കൂലിയിൽ 50% വരെ വൻ ഇളവ്! വിവാഹ സ്വർണ്ണാഭരണങ്ങൾ ബുക്ക് ചെയ്യാൻ സന്ദർശിക്കൂ.",
    imageUrl: "https://images.unsplash.com/photo-1599643478518-a784e5dc4c8f?auto=format&fit=crop&q=80&w=600",
    link: "https://www.kalyanjewellers.net",
    sponsor: "കല്യാൺ ജ്വല്ലേഴ്‌സ് - കേരള ശാഖകൾ",
    slot: "top"
  },
  {
    id: "ad-m2",
    title: "നാടൻ ഹൈപ്പർമാർക്കറ്റ് സ്പെഷ്യൽ വീക്ക് 🛒",
    subtitle: "ഫ്രഷ് പച്ചക്കറികളും കറിമസാലകളും നിങ്ങളുടെ വീട്ടുപടിക്കൽ മിതമായ നിരക്കിൽ എത്തിക്കുന്നു.",
    imageUrl: "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=600",
    link: "https://www.google.com",
    sponsor: "M2 ഹൈപ്പർമാർക്കറ്റ്, കോഴിക്കോട്",
    slot: "middle"
  },
  {
    id: "ad-realtor",
    title: "പീച്ചി ഹൗസിംഗ് വില്ലകൾ വിൽപനയ്ക്ക് 🏡",
    subtitle: "പീച്ചി തടാകത്തിന് സമീപം പ്രകൃതിരമണീയമായ അന്തരീക്ഷത്തിൽ സ്മാർട്ട് വില്ലകൾ സ്വന്തമാക്കാം.",
    imageUrl: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?auto=format&fit=crop&q=80&w=600",
    link: "https://www.google.com",
    sponsor: "പീച്ചി ബിഗ് പ്ലാനർ ഡെവലപ്പേഴ്സ്",
    slot: "sidebar"
  }
];

if (!fs.existsSync(ADS_FILE)) {
  fs.writeFileSync(ADS_FILE, JSON.stringify(defaultAds, null, 2), "utf-8");
}

async function getAdsData(): Promise<AdBannerType[]> {
  if (useFirebase && db) {
    try {
      const q = collection(db, "ads");
      const snapshot = await getDocs(q);
      const list: AdBannerType[] = [];
      snapshot.forEach((doc) => {
        const data = doc.data();
        list.push({
          id: doc.id,
          title: data.title || "",
          subtitle: data.subtitle || "",
          imageUrl: data.imageUrl || "",
          link: data.link || "",
          sponsor: data.sponsor || "",
          slot: data.slot || "top",
          category: data.category || "All"
        });
      });
      if (list.length === 0) {
        let initialAds = defaultAds;
        try {
          if (fs.existsSync(ADS_FILE)) {
            const raw = fs.readFileSync(ADS_FILE, "utf-8");
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              initialAds = parsed;
            }
          }
        } catch (e) {
          console.error("Error reading ADS_FILE to seed Firestore:", e);
        }

        for (const ad of initialAds) {
          await setDoc(doc(db, "ads", ad.id), {
            title: ad.title,
            subtitle: ad.subtitle,
            imageUrl: ad.imageUrl,
            link: ad.link,
            sponsor: ad.sponsor,
            slot: ad.slot || "top",
            category: ad.category || "All"
          });
          list.push(ad);
        }
      }
      return list;
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(ADS_FILE)) {
      return defaultAds;
    }
    const raw = fs.readFileSync(ADS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading ads data:", error);
    return defaultAds;
  }
}

async function saveAdsData(data: AdBannerType[]) {
  if (useFirebase && db) {
    try {
      for (const item of data) {
        await setDoc(doc(db, "ads", item.id), {
          title: item.title,
          subtitle: item.subtitle,
          imageUrl: item.imageUrl,
          link: item.link,
          sponsor: item.sponsor,
          slot: item.slot || "top",
          category: item.category || "All"
        }, { merge: true });
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(ADS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving ads data:", error);
  }
}

// ----------------------------------------------------------------------
// CATEGORIES DATA LAYER
// ----------------------------------------------------------------------
const defaultCategories = ["എല്ലാം", "കേരളം", "പ്രാദേശികം", "രാഷ്ട്രീയം", "കായികം", "വിനോദം", "പ്രവാസം"];

if (!fs.existsSync(CATEGORIES_FILE)) {
  fs.writeFileSync(CATEGORIES_FILE, JSON.stringify(defaultCategories, null, 2), "utf-8");
}

async function getCategoriesData(): Promise<string[]> {
  if (useFirebase && db) {
    try {
      const docRef = doc(db, "portal_settings", "categories");
      const docSnap = await getDoc(docRef);
      if (docSnap.exists()) {
        return docSnap.data().list || defaultCategories;
      } else {
        await setDoc(docRef, { list: defaultCategories });
        return defaultCategories;
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    if (!fs.existsSync(CATEGORIES_FILE)) {
      return defaultCategories;
    }
    return JSON.parse(fs.readFileSync(CATEGORIES_FILE, "utf-8"));
  } catch (error) {
    return defaultCategories;
  }
}

async function saveCategoriesData(data: string[]) {
  if (useFirebase && db) {
    try {
      await setDoc(doc(db, "portal_settings", "categories"), { list: data }, { merge: true });
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(CATEGORIES_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {}
}

// Serve uploaded local images
app.use("/uploads", express.static(UPLOADS_DIR));

// Seed default news if missing
const defaultArticles: NewsArticle[] = [
  {
    id: "news-1",
    title: "കോഴിക്കോട് കനത്ത മഴ; താഴ്ന്ന പ്രദേശങ്ങൾ വെള്ളത്തിനടിയിൽ, ജാഗ്രതാ നിർദ്ദേശം",
    description: "ജില്ലയുടെ വിവിധ ഭാഗങ്ങളിൽ കനത്ത പ്രളയ സമാനമായ അന്തരീക്ഷം. മലയോര മേഖലകളിൽ ഉരുൾപൊട്ടൽ ഭീതി.",
    content: "കോഴിക്കോട് ജില്ലയിൽ പെയ്യുന്ന തോരാമഴ ജനജീവിതത്തെ തകിടം മറിച്ചു. നഗരത്തിലെ താഴ്ന്ന പ്രദേശങ്ങളെല്ലാം വെള്ളത്തിനടിയിലായിരിക്കുകയാണ്. അടുത്ത മൂന്ന് ദിവസത്തേക്ക് റെഡ് അലേർട്ട് പ്രഖ്യാപിച്ചിരിക്കുന്നു. ജില്ലയിൽ ദുരിതാശ്വാസ ക്യാമ്പുകൾ തുറന്നിട്ടുണ്ട്. നദികളിലെ ജലനിരപ്പ് അപകടകരമായ അളവിൽ ഉയർന്നതോടെ തീരങ്ങളിലുള്ളവരോട് മാറിപ്പാർക്കാൻ അധികൃതർ കനത്ത നിർദ്ദേശം നൽകിയിട്ടുണ്ട്. എൻ.ഡി.ആർ.എഫ് ഇവിടങ്ങളിൽ എത്തിച്ചേർന്നിട്ടുണ്ട്.",
    thumbnail: "https://images.unsplash.com/photo-1547683905-f686c993aae5?auto=format&fit=crop&q=80&w=800",
    category: "കേരളം",
    author: "രാജേഷ് കുമാർ (TNC മാധ്യമപ്രതിനിധി)",
    views: 1245,
    likes: 342,
    publishedAt: "2026-05-23T04:20:00Z",
    comments: [
      {
        id: "c-1",
        author: "ഹരിദാസ് സി കെ",
        content: "വളരെ ഗൌരവമുള്ള സാഹചര്യം ആണ്. എല്ലാവരും ജാഗ്രത പാലിക്കുക പ്രാർത്ഥനകൾ.",
        createdAt: "2026-05-23T04:30:00Z"
      },
      {
        id: "c-2",
        author: "അഞ്ജലി പി",
        content: "നമ്മുടെ ദുരിതാശ്വാസ ഹെൽപ്പ് ലൈൻ നമ്പറുകൾ താഴെ ഷെയർ ചെയ്യാമോ?",
        createdAt: "2026-05-23T04:45:00Z"
      }
    ],
    videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
  },
  {
    id: "news-2",
    title: "സംстояние ബജറ്റിൽ പ്രവാസി പെൻഷൻ വർദ്ധിപ്പിച്ചു; പ്രവാസികൾക്ക് വലിയ ആശ്വാസം",
    description: "പ്രവാസികളുടെ ക്ഷേമത്തിനായി കൂടുതൽ പദ്ധതികൾ ബജറ്റിൽ വകയിരുത്തി. പ്രവാസി സംഘടനകൾ സ്വാഗതം ചെയ്തു.",
    content: "സംസ്ഥാന ബജറ്റിൽ ഇത്തവണ പ്രവാസികൾക്ക് മികച്ച വാർത്ത. പ്രവാസി പെൻഷൻ തുകയിൽ 500 രൂപയുടെ വർദ്ധനവാണ് പ്രസ്താവിച്ചിട്ടുള്ളത്. ഇത് പ്രവാസ കുടുംബങ്ങൾക്ക് ചെറിയൊരു തണലാകും. കൂടാതെ മടങ്ങിവരുന്ന പ്രവാസികൾക്ക് സ്റ്റാർട്ടപ്പ് തുടങ്ങാൻ സബ്സിഡിയോടു കൂടിയ വായ്പകളും നൽകും. പ്രവാസി ലീഗുകൾ ഗവൺമെന്റിന്റെ ഈ ചരിത്രപരമായ തീരുമാനത്തെ ഹൃദയപൂർവ്വം അഭിനന്ദിച്ചു.",
    thumbnail: "https://images.unsplash.com/photo-1526304640581-d334cdbbf45e?auto=format&fit=crop&q=80&w=800",
    category: "പ്രവാസം",
    author: "മുസ്തഫ കളത്തിൽ",
    views: 890,
    likes: 215,
    publishedAt: "2026-05-23T03:00:00Z",
    comments: [
      {
        id: "c-3",
        author: "സലീം ഖാൻ",
        content: "പ്രവാസികളുടെ കഷ്ടപ്പാടുകൾക്ക് ഫലം കിട്ടി തുടങ്ങി. നന്ദി സർക്കാരിന്.",
        createdAt: "2026-05-23T03:20:00Z"
      }
    ]
  },
  {
    id: "news-3",
    title: "കേരളാ സൂപ്പർ ലീഗ് ഫുട്ബോൾ: കേരള ബ്ലാസ്റ്റേഴ്‌സിന് ഉജ്ജ്വല വിജയം!",
    description: "കനത്ത പോരാട്ടത്തിൽ എതിരില്ലാത്ത രണ്ട് ഗോളുകൾക്ക് ബ്ലാസ്റ്റേഴ്‌സ് ജേതാക്കളായി.",
    content: "കൊച്ചി ജവഹർലാൽ നെഹ്‌റു സ്റ്റേഡിയത്തിൽ നടന്ന ആവേശകരമായ മത്സരത്തിൽ കേരള ബ്ലാസ്റ്റേഴ്‌സ് വിജയം കൊയ്തു. മുന്നേറ്റ നിരയിലെ തകർപ്പൻ കോമ്പിനേഷൻ ഡ്രിബ്ലിംഗാണ് ടീമിന് ഈ ഗംഭീര വിജയം നൽകിയത്. ഗാലറിയിലെ മഞ്ഞക്കടൽ ആർത്തുവിളിച്ചപ്പോൾ കളിക്കാർക്ക് എനർജി ഇരട്ടിയായി. അടുത്ത ആഴ്ചത്തെ ഫൈനൽ മത്സരത്തിൽ ഇവർ ഗോവ യെ നേരിടും.",
    thumbnail: "https://images.unsplash.com/photo-1508098682722-e99c43a406b2?auto=format&fit=crop&q=80&w=800",
    category: "കായികം",
    author: "അനൂപ് ജോസഫ് (TNC സ്പോർട്സ്)",
    views: 2310,
    likes: 856,
    publishedAt: "2026-05-22T18:00:00Z",
    comments: [
      {
        id: "c-4",
        author: "ബ്ലാസ്റ്റേഴ്‌സ് ഫാൻ",
        content: "നമ്മൾ കപ്പടിക്കും ഇത്തവണ ഉറപ്പാണ്!! യെല്ലോ ആർമി ഉയിർ!",
        createdAt: "2026-05-22T18:30:00Z"
      }
    ]
  },
  {
    id: "news-4",
    title: "പ്രാദേശിക കാർഷിക ഉത്സവം തിരുവല്ലയിൽ ആരംഭിച്ചു; പ്രകൃതിദത്ത വിപണി ലഭ്യമാക്കും",
    description: "നാടൻ ഉൽപ്പന്നങ്ങളുടെയും ജൈവ പച്ചക്കറികളുടെയും പ്രദർശനവും വിപണനവും ആരംഭിച്ചു. സന്ദർശകരുടെ കൂമ്പാരം.",
    content: "തിരുവല്ലയിൽ പ്രാദേശിക കൃഷി വകുപ്പിൻ്റെ ആഭിമുഖ്യത്തിൽ വിപുലമായ കാർഷികമേള ആരംഭിച്ചു. രാസവളങ്ങൾ ചേർക്കാത്ത ശുദ്ധമായ കാന്താരി മുളക്, മഞ്ഞൾ, ഇഞ്ചി, നാടൻ ചക്ക എന്നിവയുടെ പ്രത്യേക കൗണ്ടറുകൾ സജ്ജമാക്കിയിട്ടുണ്ട്. അന്യസംസ്ഥാന കീടനാശിനി പ്രയോഗങ്ങളിൽ നിന്ന് മുക്തി നേടാൻ ജനങ്ങളെ പ്രോത്സാഹിപ്പിക്കുകയാണ് ലക്ഷ്യമെന്ന് ഭാരവാഹികൾ പറഞ്ഞു.",
    thumbnail: "https://images.unsplash.com/photo-1595974482597-4b8da8879bc5?auto=format&fit=crop&q=80&w=800",
    category: "പ്രാദേശികം",
    author: "ഷിബുക്കുട്ടൻ മല്ലപ്പള്ളി",
    views: 540,
    likes: 120,
    publishedAt: "2026-05-22T11:45:00Z",
    comments: []
  },
  {
    id: "news-5",
    title: "മലയാള ചലച്ചിത്ര നായകൻ്റെ പുതിയ ട്രെയിലർ തരംഗമാകുന്നു; യൂട്യൂബിൽ ഒന്നാമത്",
    description: "റിലീസ് ചെയ്ത് വെറും പത്തു മിനിറ്റുകൊണ്ട് ഒരു ദശലക്ഷം കാണികളെ നേടി സോഷ്യൽ മീഡിയയിൽ സംസാരവിഷയം.",
    content: "വരാനിരിക്കുന്ന മലയാളം ബിഗ് ബജറ്റ് ആക്ഷൻ ചിത്രത്തിൻ്റെ ഔദ്യോഗിക ട്രെയിലർ തരംഗമായി മാറി മുന്നേറുകയാണ്. മാസ്സ് ബാക്ക്ഗ്രൗണ്ട് സ്കോറും തകർപ്പൻ ഡയലോഗുകളും കൊണ്ട് നിമിഷ നേരം കൊണ്ടാണ് യൂട്യൂബ് ട്രെൻഡിംഗിൽ ഒന്നാം സ്ഥാനം സ്വന്തമാക്കിയത്. ജൂൺ ആദ്യവാരം ചിത്രം തിയേറ്ററുകളിൽ എത്തുമെന്നാണ് അണിയറ പ്രവർത്തകർ അറിയിച്ചിട്ടുള്ളത്.",
    thumbnail: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?auto=format&fit=crop&q=80&w=800",
    category: "വിനോദം",
    author: "രഞ്ജിനി വിനോദ്",
    views: 4120,
    likes: 1980,
    publishedAt: "2026-05-21T09:12:00Z",
    comments: []
  }
];

if (!fs.existsSync(NEWS_FILE)) {
  fs.writeFileSync(NEWS_FILE, JSON.stringify(defaultArticles, null, 2), "utf-8");
}

// Function to read news database
async function getNewsData(): Promise<NewsArticle[]> {
  if (useFirebase && db) {
    try {
      const q = query(collection(db, "news"));
      const snapshot = await getDocs(q);
      const list: NewsArticle[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data();
        list.push({
          id: docSnap.id,
          title: data.title || "",
          description: data.description || "",
          content: data.content || "",
          thumbnail: data.thumbnail || data.imageUrl || "",
          category: data.category || "കേരളം",
          author: data.author || "",
          views: data.views || 0,
          likes: data.likes || 0,
          publishedAt: data.publishedAt || new Date().toISOString(),
          comments: data.comments || [],
          videoUrl: data.videoUrl || undefined
        });
      });
      // Sort newest publishedAt first
      list.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());
      
      if (list.length === 0) {
        let initialArticles = defaultArticles;
        try {
          if (fs.existsSync(NEWS_FILE)) {
            const raw = fs.readFileSync(NEWS_FILE, "utf-8");
            const parsed = JSON.parse(raw);
            if (Array.isArray(parsed) && parsed.length > 0) {
              initialArticles = parsed;
            }
          }
        } catch (e) {
          console.error("Error reading NEWS_FILE to seed Firestore:", e);
        }

        for (const art of initialArticles) {
          await setDoc(doc(db, "news", art.id), {
            title: art.title,
            description: art.description,
            content: art.content,
            thumbnail: art.thumbnail,
            category: art.category,
            author: art.author,
            views: art.views,
            likes: art.likes,
            publishedAt: art.publishedAt,
            comments: art.comments,
            videoUrl: art.videoUrl || null
          });
          list.push(art);
        }
      }
      return list;
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    const raw = fs.readFileSync(NEWS_FILE, "utf-8");
    return JSON.parse(raw);
  } catch (error) {
    console.error("Error reading news data:", error);
    return defaultArticles;
  }
}

// Function to save news database
async function saveNewsData(data: NewsArticle[]) {
  if (useFirebase && db) {
    try {
      for (const item of data) {
        await setDoc(doc(db, "news", item.id), {
          title: item.title,
          description: item.description,
          content: item.content,
          thumbnail: item.thumbnail,
          category: item.category,
          author: item.author,
          views: item.views,
          likes: item.likes,
          publishedAt: item.publishedAt,
          comments: item.comments,
          videoUrl: item.videoUrl || null
        }, { merge: true });
      }
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  try {
    fs.writeFileSync(NEWS_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (error) {
    console.error("Error saving news data:", error);
  }
}

// Middleware to verify if request is from the authenticated administrator
function requireAdmin(req: any, res: any, next: any) {
  const authHeader = req.headers.authorization;
  if (!authHeader || authHeader !== "Bearer tnc-news-secure-token-authenticated-2026") {
    return res.status(403).json({ error: "ലോഗിൻ വിവരങ്ങൾ ലഭ്യമല്ല. ദയവായി അഡ്മിൻ ലോഗിൻ ചെയ്യുക വഴി മാത്രം മാറ്റങ്ങൾ വരുത്തുക." });
  }
  next();
}

// REST APIs
// ----------------------------------------------------------------------
// CATEGORIES ENDPOINTS
// ----------------------------------------------------------------------
app.get("/api/categories", async (req, res) => {
  const categories = await getCategoriesData();
  res.json(categories);
});

app.post("/api/categories", requireAdmin, async (req, res) => {
  const { categories } = req.body;
  if (!Array.isArray(categories)) {
    return res.status(400).json({ error: "categories array is required." });
  }
  // Guarantee 'എല്ലാം' (All) is present
  if (!categories.includes("എല്ലാം")) {
    categories.unshift("എല്ലാം");
  }
  await saveCategoriesData(categories);
  res.json({ success: true, categories });
});

// 1. Get all articles
app.get("/api/news", async (req, res) => {
  const articles = await getNewsData();
  res.json(articles);
});

// 2. Get single article
app.get("/api/news/:id", async (req, res) => {
  const articles = await getNewsData();
  const article = articles.find((a) => a.id === req.params.id);
  if (!article) {
    res.status(404).json({ error: "Article not found" });
    return;
  }
  // Increment view count dynamically on search/load
  article.views += 1;
  await saveNewsData(articles);
  res.json(article);
});

// 3. Create news article (Admin protected or simple verification)
app.post("/api/news", requireAdmin, async (req, res) => {
  const { title, description, content, thumbnail, category, author, videoUrl, imageBase64 } = req.body;
  
  if (!title || !description || !content) {
    res.status(400).json({ error: "Title, description and content are required in Malayalam." });
    return;
  }

  let finalThumbnail = thumbnail || "https://images.unsplash.com/photo-1504711434969-e33886168f5c?auto=format&fit=crop&q=80&w=800";

  // If base64 image uploaded, save it as a local file inside /uploads
  if (imageBase64 && imageBase64.includes(";base64,")) {
    try {
      const parts = imageBase64.split(";base64,");
      const mime = parts[0].match(/data:(.*?);/)?.[1] || "image/png";
      const ext = mime.split("/")[1] || "png";
      const buffer = Buffer.from(parts[1], "base64");
      const filename = `uploaded-${Date.now()}.${ext}`;
      const filePath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filePath, buffer);
      finalThumbnail = `/uploads/${filename}`;
    } catch (e) {
      console.error("Error converting base64 file upload:", e);
    }
  }

  const articles = await getNewsData();
  const nextId = "news-" + Date.now();
  const newArticle: NewsArticle = {
    id: nextId,
    title,
    description,
    content,
    thumbnail: finalThumbnail,
    category: category || "പ്രാദേശികം",
    author: author || "കൂട്ടായ്മ ലേഖകൻ",
    views: 0,
    likes: 0,
    publishedAt: new Date().toISOString(),
    comments: [],
    videoUrl: videoUrl || undefined
  };

  articles.unshift(newArticle);
  await saveNewsData(articles);

  // Generate automated notification for the newly uploaded news article
  try {
    const notifications = await getNotificationsData();
    const newNotif: PortalNotification = {
      id: "notif-" + Date.now(),
      articleId: newArticle.id,
      title: "പുതിയ വാർത്ത വന്നുകഴിഞ്ഞു 🔔",
      message: newArticle.title,
      createdAt: new Date().toISOString(),
      read: false
    };
    notifications.unshift(newNotif);
    await saveNotificationsData(notifications);
  } catch (err) {
    console.error("Error writing automatic news upload notification:", err);
  }

  res.json({ success: true, article: newArticle });
});

// 4. Like an article
app.post("/api/news/:id/like", async (req, res) => {
  const articles = await getNewsData();
  const article = articles.find((a) => a.id === req.params.id);
  if (!article) {
    res.status(404).json({ error: "Article not found" });
    return;
  }
  article.likes += 1;
  await saveNewsData(articles);
  res.json({ success: true, likes: article.likes });
});

// 5. Post comment on article
app.post("/api/news/:id/comments", async (req, res) => {
  const { author, content } = req.body;
  if (!author || !content) {
    res.status(400).json({ error: "Author and content are required" });
    return;
  }

  const articles = await getNewsData();
  const article = articles.find((a) => a.id === req.params.id);
  if (!article) {
    res.status(404).json({ error: "Article not found" });
    return;
  }

  const newComment = {
    id: "comment-" + Date.now(),
    author,
    content,
    createdAt: new Date().toISOString()
  };

  article.comments.push(newComment);
  await saveNewsData(articles);

  // Also sync comment directly to Firestore 'comments' collection for completeness of constraints
  if (useFirebase && db) {
    try {
      await addDoc(collection(db, "comments"), {
        articleId: req.params.id,
        author: author,
        content: content,
        createdAt: new Date()
      });
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  res.json({ success: true, comment: newComment });
});

// 6. Delete article (Admin)
app.delete("/api/news/:id", requireAdmin, async (req, res) => {
  let articles = await getNewsData();
  const exists = articles.some((a) => a.id === req.params.id);
  if (!exists) {
    res.status(404).json({ error: "Article not found" });
    return;
  }

  // If using live Firestore, delete the record directly from collection
  if (useFirebase && db) {
    try {
      await deleteDoc(doc(db, "news", req.params.id));
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  articles = articles.filter((a) => a.id !== req.params.id);
  await saveNewsData(articles);
  res.json({ success: true });
});

// 6.5. Update article (Admin)
app.put("/api/news/:id", requireAdmin, async (req, res) => {
  const { title, description, content, thumbnail, category, author, videoUrl, imageBase64 } = req.body;
  const articles = await getNewsData();
  const articleIndex = articles.findIndex((a) => a.id === req.params.id);
  if (articleIndex === -1) {
    res.status(404).json({ error: "Article not found" });
    return;
  }

  let finalThumbnail = thumbnail || articles[articleIndex].thumbnail;

  if (imageBase64 && imageBase64.includes(";base64,")) {
    try {
      const parts = imageBase64.split(";base64,");
      const mime = parts[0].match(/data:(.*?);/)?.[1] || "image/png";
      const ext = mime.split("/")[1] || "png";
      const buffer = Buffer.from(parts[1], "base64");
      const filename = `uploaded-${Date.now()}.${ext}`;
      const filePath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filePath, buffer);
      finalThumbnail = `/uploads/${filename}`;
    } catch (e) {
      console.error("Error converting base64 file upload:", e);
    }
  }

  articles[articleIndex] = {
    ...articles[articleIndex],
    title: title || articles[articleIndex].title,
    description: description || articles[articleIndex].description,
    content: content || articles[articleIndex].content,
    thumbnail: finalThumbnail,
    category: category || articles[articleIndex].category,
    author: author || articles[articleIndex].author,
    videoUrl: videoUrl !== undefined ? videoUrl : articles[articleIndex].videoUrl
  };

  await saveNewsData(articles);
  res.json({ success: true, article: articles[articleIndex] });
});

// 7. Admin login verification
app.post("/api/auth/login", (req, res) => {
  const { username, password } = req.body;
  
  // High fidelity credentials
  if (username === "tnclive" && password === "Mejo@2255#") {
    res.json({ success: true, token: "tnc-news-secure-token-authenticated-2026" });
  } else {
    res.status(401).json({ error: "തെറ്റായ വിവരങ്ങൾ! വീണ്ടും ശ്രമിക്കുക." });
  }
});

// 7b. Secure Persistent User Registration Endpoint (Fallback-safe)
app.post("/api/auth/register", async (req, res) => {
  try {
    const { email, password, displayName } = req.body;
    
    if (!email || !password || !displayName) {
      res.status(400).json({ error: "എല്ലാ ഫീൽഡുകളും നിർബന്ധമാണ്." });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    const users = await getUsersData();
    const exists = users.find((u) => u.email.toLowerCase() === cleanEmail);

    if (exists) {
      res.status(400).json({ error: "ഈ ഇമെയിൽ വിലാസം ഇതിനകം മറ്റൊരു അക്കൗണ്ടിനായി ഉപയോഗിച്ചിട്ടുള്ളതാണ്.", code: "auth/email-already-in-use" });
      return;
    }

    const newUser = {
      email: cleanEmail,
      password, // In development, plain text or simple encoding is fully satisfactory
      displayName: displayName.trim(),
      createdAt: new Date().toISOString()
    };

    users.push(newUser);
    await saveUsersData(users);

    res.json({ 
      success: true, 
      user: { 
        email: newUser.email, 
        displayName: newUser.displayName 
      } 
    });
  } catch (error) {
    console.error("Registration endpoint error:", error);
    res.status(500).json({ error: "സെർവറിൽ പിശക് സംഭവിച്ചു." });
  }
});

// 7c. Secure Persistent User Login Endpoint (Fallback-safe)
app.post("/api/auth/email-login", async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: "ദയവായി ഇമെയിലും പാസ്‌വേഡും നൽകുക." });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    const users = await getUsersData();
    const user = users.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      res.status(404).json({ error: "ഈ ഇമെയിൽ വിലാസത്തിൽ ഒരു അക്കൗണ്ട് നിലവിലില്ല.", code: "auth/user-not-found" });
      return;
    }

    if (user.password !== password) {
      res.status(401).json({ error: "നൽകിയ പാസ്‌വേഡ് തെറ്റാണ്.", code: "auth/wrong-password" });
      return;
    }

    res.json({ 
      success: true, 
      user: { 
        email: user.email, 
        displayName: user.displayName 
      } 
    });
  } catch (error) {
    console.error("Login endpoint error:", error);
    res.status(500).json({ error: "സെർവറിൽ പിശക് സംഭവിച്ചു." });
  }
});

// 7d. Resilient Reset Password Verification Handler
app.post("/api/auth/reset-password", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) {
      res.status(400).json({ error: "ദയവായി ഇമെയിൽ വിലാസം നൽകുക." });
      return;
    }

    const cleanEmail = email.trim().toLowerCase();
    const users = await getUsersData();
    const user = users.find((u) => u.email.toLowerCase() === cleanEmail);

    if (!user) {
      res.status(404).json({ error: "ഈ ഇമെയിൽ വിലാസത്തിൽ ഒരു അക്കൗണ്ട് കാണാൻ സാധിച്ചില്ല.", code: "auth/user-not-found" });
      return;
    }

    res.json({ 
      success: true, 
      message: "പാസ്‌വേഡ് റീസെറ്റ് ചെയ്യാനുള്ള ഇൻസ്ട്രക്ഷൻ നിങ്ങളുടെ ഇമെയിലിലേക്ക് അയച്ചിട്ടുണ്ട്." 
    });
  } catch (error) {
    console.error("Reset endpoint error:", error);
    res.status(500).json({ error: "സെർവറിൽ പിശക് സംഭവിച്ചു." });
  }
});

// Ads APIs
// A. Get all ads
app.get("/api/ads", async (req, res) => {
  const ads = await getAdsData();
  res.json(ads);
});

// B. Add new ad
app.post("/api/ads", requireAdmin, async (req, res) => {
  const { title, subtitle, sponsor, link, imageUrl, imageBase64, slot, category } = req.body;

  if (!title || !sponsor) {
    res.status(400).json({ error: "പരസ്യത്തിന്റെ തലക്കെട്ടും സ്പോൺസറും നിർബന്ധമാണ്." });
    return;
  }

  let finalImageUrl = imageUrl || "https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&q=80&w=600";

  if (imageBase64 && imageBase64.includes(";base64,")) {
    try {
      const parts = imageBase64.split(";base64,");
      const mime = parts[0].match(/data:(.*?);/)?.[1] || "image/png";
      const ext = mime.split("/")[1] || "png";
      const buffer = Buffer.from(parts[1], "base64");
      const filename = `ad-${Date.now()}.${ext}`;
      const filePath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filePath, buffer);
      finalImageUrl = `/uploads/${filename}`;
    } catch (e) {
      console.error("Error saving ad base64 image:", e);
    }
  }

  const ads = await getAdsData();
  const nextId = "ad-" + Date.now();
  const newAd: AdBannerType = {
    id: nextId,
    title,
    subtitle: subtitle || "",
    sponsor,
    link: link || "#",
    imageUrl: finalImageUrl,
    slot: slot || "top",
    category: category || "All"
  };

  ads.push(newAd);
  await saveAdsData(ads);
  res.json({ success: true, ad: newAd });
});

// C. Delete ad
app.delete("/api/ads/:id", requireAdmin, async (req, res) => {
  let ads = await getAdsData();
  const exists = ads.some((a) => a.id === req.params.id);
  if (!exists) {
    res.status(404).json({ error: "Ad not found" });
    return;
  }

  if (useFirebase && db) {
    try {
      await deleteDoc(doc(db, "ads", req.params.id));
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  ads = ads.filter((a) => a.id !== req.params.id);
  await saveAdsData(ads);
  res.json({ success: true });
});

// D. Update ad
app.put("/api/ads/:id", requireAdmin, async (req, res) => {
  const { title, subtitle, sponsor, link, imageUrl, imageBase64, slot, category } = req.body;
  const ads = await getAdsData();
  const adIndex = ads.findIndex((a) => a.id === req.params.id);
  if (adIndex === -1) {
    res.status(404).json({ error: "Ad not found" });
    return;
  }

  let finalImageUrl = imageUrl || ads[adIndex].imageUrl;

  if (imageBase64 && imageBase64.includes(";base64,")) {
    try {
      const parts = imageBase64.split(";base64,");
      const mime = parts[0].match(/data:(.*?);/)?.[1] || "image/png";
      const ext = mime.split("/")[1] || "png";
      const buffer = Buffer.from(parts[1], "base64");
      const filename = `ad-${Date.now()}.${ext}`;
      const filePath = path.join(UPLOADS_DIR, filename);
      fs.writeFileSync(filePath, buffer);
      finalImageUrl = `/uploads/${filename}`;
    } catch (e) {
      console.error("Error saving ad base64 image:", e);
    }
  }

  ads[adIndex] = {
    ...ads[adIndex],
    title: title || ads[adIndex].title,
    subtitle: subtitle !== undefined ? subtitle : ads[adIndex].subtitle,
    sponsor: sponsor || ads[adIndex].sponsor,
    link: link !== undefined ? link : ads[adIndex].link,
    imageUrl: finalImageUrl,
    slot: slot || ads[adIndex].slot || "top",
    category: category || ads[adIndex].category || "All"
  };

  await saveAdsData(ads);
  res.json({ success: true, ad: ads[adIndex] });
});

// --- BREAKING NEWS ENDPOINTS ---
// 1. Get all breaking news
app.get("/api/breaking", async (req, res) => {
  const breaking = await getBreakingData();
  res.json(breaking);
});

// 2. Add breaking news
app.post("/api/breaking", requireAdmin, async (req, res) => {
  const { text } = req.body;
  if (!text) {
    res.status(400).json({ error: "Text is required" });
    return;
  }
  const breaking = await getBreakingData();
  const newItem = {
    id: `b-${Date.now()}`,
    text,
    createdAt: new Date().toISOString()
  };
  breaking.push(newItem);
  await saveBreakingData(breaking);
  res.json({ success: true, breaking: newItem });
});

// 3. Update breaking news
app.put("/api/breaking/:id", requireAdmin, async (req, res) => {
  const { text } = req.body;
  if (!text) {
    res.status(400).json({ error: "Text is required" });
    return;
  }
  const breaking = await getBreakingData();
  const index = breaking.findIndex((b) => b.id === req.params.id);
  if (index === -1) {
    res.status(404).json({ error: "Breaking news not found" });
    return;
  }
  breaking[index].text = text;
  await saveBreakingData(breaking);
  res.json({ success: true, breaking: breaking[index] });
});

// 4. Delete breaking news
app.delete("/api/breaking/:id", requireAdmin, async (req, res) => {
  let breaking = await getBreakingData();
  const exists = breaking.some((b) => b.id === req.params.id);
  if (!exists) {
    res.status(404).json({ error: "Breaking news not found" });
    return;
  }

  if (useFirebase && db) {
    try {
      await deleteDoc(doc(db, "breaking_news", req.params.id));
    } catch (e) {
      handleFirebaseError(e);
    }
  }

  breaking = breaking.filter((b) => b.id !== req.params.id);
  await saveBreakingData(breaking);
  res.json({ success: true });
});

// --- NOTIFICATIONS & SUBSCRIPTIONS ENDPOINTS ---
// A. Get all notifications
app.get("/api/notifications", async (req, res) => {
  const notifications = await getNotificationsData();
  res.json(notifications);
});

// B. Mark all notifications as read
app.post("/api/notifications/mark-all-read", async (req, res) => {
  const notifications = await getNotificationsData();
  const updated = notifications.map(n => ({ ...n, read: true }));
  await saveNotificationsData(updated);
  res.json({ success: true, notifications: updated });
});

// C. Get subscriber count
app.get("/api/notifications/subscribers", async (req, res) => {
  const sub = await getSubscribersData();
  res.json(sub);
});

// D. Subscribe
app.post("/api/notifications/subscribe", async (req, res) => {
  const sub = await getSubscribersData();
  sub.count += 1;
  await saveSubscribersData(sub);
  res.json({ success: true, count: sub.count });
});

// E. Unsubscribe
app.post("/api/notifications/unsubscribe", async (req, res) => {
  const sub = await getSubscribersData();
  if (sub.count > 0) {
    sub.count -= 1;
  }
  await saveSubscribersData(sub);
  res.json({ success: true, count: sub.count });
});

// Start integration with Vite dynamically
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[TNC News Portal] Server running with Firebase capability on http://localhost:${PORT}`);
  });
}

startServer();
