/**
 * admin.js - Administrative Dashboard Controller (Vanilla JS / ES Module)
 * 
 * Provides services for creating, modifying, and deleting articles, sponsored ads,
 * and breaking news banners on Firestore. Includes YouTube thumbnail autoextraction.
 */

import { db } from "./firebase.js";
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  updateDoc, 
  deleteDoc, 
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

/**
 * Extracts the 11-digit video ID from common YouTube links and generates the thumbnail preview URL.
 * Supports standard watch urls, share links (youtu.be), or embed paths.
 * @param {string} url 
 * @returns {string|null} Thumbnail URL or null if invalid
 */
export function getYoutubeThumbnail(url) {
  if (!url) return null;
  const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
  const match = url.match(regExp);
  
  if (match && match[2].length === 11) {
    const videoId = match[2];
    return `https://img.youtube.com/vi/${videoId}/0.jpg`;
  }
  return null;
}

/**
 * Persists a new Malayalam news article to the Firestore database.
 * @param {Object} item 
 * @returns {Promise<string>} Created document ID
 */
export async function addNewsArticle(item) {
  try {
    const newsCollection = collection(db, "news");
    
    // Auto-resolve video thumbnail if a Youtube URL is specified
    let thumbnail = item.imageUrl || "";
    if (item.youtubeUrl) {
      const ytThumb = getYoutubeThumbnail(item.youtubeUrl);
      if (ytThumb && !item.imageUrl) {
        thumbnail = ytThumb;
      }
    }

    const payload = {
      title: item.title || "അപ്‌ഡേറ്റ്",
      category: item.category || "കേരളം",
      description: item.description || "",
      content: item.content || "",
      imageUrl: item.imageUrl || "",
      youtubeUrl: item.youtubeUrl || "",
      location: item.location || "",
      thumbnail: thumbnail,
      views: item.views || 0,
      likes: item.likes || 0,
      shares: item.shares || 0,
      isSponsored: !!item.isSponsored,
      createdAt: serverTimestamp()
    };

    const docRef = await addDoc(newsCollection, payload);
    console.log("📝 Created news article with Firestore ID:", docRef.id);
    return docRef.id;
  } catch (error) {
    console.error("❌ Failed to add news:", error);
    throw error;
  }
}

/**
 * Modifies an existing news article document in Firestore.
 * @param {string} id 
 * @param {Object} updates 
 */
export async function editNewsArticle(id, updates) {
  try {
    const docRef = doc(db, "news", id);
    
    if (updates.youtubeUrl) {
      const ytThumb = getYoutubeThumbnail(updates.youtubeUrl);
      if (ytThumb && !updates.imageUrl) {
        updates.thumbnail = ytThumb;
      }
    }
    
    await updateDoc(docRef, {
      ...updates,
      updatedAt: serverTimestamp()
    });
    console.log("✏️ Updated news article:", id);
  } catch (error) {
    console.error("❌ Failed to edit news:", error);
    throw error;
  }
}

/**
 * Deletes a news article.
 * @param {string} id 
 */
export async function deleteNewsArticle(id) {
  try {
    const docRef = doc(db, "news", id);
    await deleteDoc(docRef);
    console.log("🗑️ Deleted news article:", id);
  } catch (error) {
    console.error("❌ Failed to delete news:", error);
    throw error;
  }
}

/**
 * Adds or updates a sponsored advertisement baner on the database.
 * @param {Object} ad 
 */
export async function addSponsoredAd(ad) {
  try {
    const adsCollection = collection(db, "ads");
    const payload = {
      title: ad.title || "",
      subtitle: ad.subtitle || "",
      imageUrl: ad.imageUrl || "",
      link: ad.link || "",
      sponsor: ad.sponsor || "",
      slot: ad.slot || "top", // e.g. "top", "middle", "sidebar"
      createdAt: serverTimestamp()
    };
    
    if (ad.id) {
      await setDoc(doc(db, "ads", ad.id), payload, { merge: true });
      return ad.id;
    } else {
      const docRef = await addDoc(adsCollection, payload);
      return docRef.id;
    }
  } catch (error) {
    console.error("❌ Failed to register advertisement:", error);
    throw error;
  }
}

/**
 * Deletes an existing advertisement banner.
 * @param {string} id 
 */
export async function deleteSponsoredAd(id) {
  try {
    await deleteDoc(doc(db, "ads", id));
    console.log("🗑️ Deleted ad banner:", id);
  } catch (error) {
    console.error("❌ Failed to delete ad:", error);
    throw error;
  }
}
