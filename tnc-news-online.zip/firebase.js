/**
 * firebase.js - Firebase Initialization and Service Exports (Vanilla JS / ES Module)
 * 
 * This file handles the setup and configuration of the Firebase App,
 * Firestore Database, and Firebase Authentication Services using the modern Firebase modular SDK.
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";
import { getFirestore } from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

// Dedicated Firebase Configuration (Update this with your live project keys)
export const firebaseConfig = {
  apiKey: "AIzaSyC6Num1n8QrxPPaYSNwVFUMS09zxUKYUdQ",
  authDomain: "tnc-news-online.firebaseapp.com",
  projectId: "tnc-news-online",
  storageBucket: "tnc-news-online.firebasestorage.app",
  messagingSenderId: "278369319678",
  appId: "1:278369319678:web:aa1cf59d0d17ad36b8c3af",
  measurementId: "G-3CH3ZC4TTL"
};

// Initialize Firebase App
let app;
try {
  app = initializeApp(firebaseConfig);
  console.log("🔥 Firebase initialized successfully.");
} catch (error) {
  console.error("❌ Failed to initialize Firebase. Verify your configuration credentials:", error);
}

// Export Authentication and Firestore references
export const auth = getAuth(app);
export const db = getFirestore(app);
export default app;
