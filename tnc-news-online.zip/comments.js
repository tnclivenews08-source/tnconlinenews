/**
 * comments.js - User Comments Handler (Vanilla JS / ES Module)
 * 
 * Manages posting, fetching, and ordering article-specific user responses.
 */

import { db } from "./firebase.js";
import { 
  collection, 
  query, 
  where, 
  orderBy, 
  addDoc, 
  getDocs,
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-firestore.js";

/**
 * Fetch all verified user comments associated with a specific news article.
 * @param {string} articleId 
 * @returns {Promise<Array>}
 */
export async function getCommentsForArticle(articleId) {
  try {
    const commentsCol = collection(db, "comments");
    const q = query(
      commentsCol, 
      where("articleId", "==", articleId), 
      orderBy("createdAt", "asc")
    );
    
    const snapshot = await getDocs(q);
    const results = [];
    
    snapshot.forEach((docSnap) => {
      const data = docSnap.data();
      results.push({
        id: docSnap.id,
        ...data,
        createdAt: data.createdAt ? data.createdAt.toDate().toISOString() : new Date().toISOString()
      });
    });
    
    return results;
  } catch (error) {
    console.error(`❌ Failed to load comments for article ${articleId}:`, error);
    // Fallback to empty list or print error
    return [];
  }
}

/**
 * Appends a comment to a news article in Firestore.
 * @param {string} articleId 
 * @param {string} author Author screen name 
 * @param {string} content Malayalam feedback text
 * @returns {Promise<Object>} Created comment record
 */
export async function addCommentToArticle(articleId, author, content) {
  try {
    const commentsCol = collection(db, "comments");
    const payload = {
      articleId: articleId,
      author: author || "അജ്ഞാതൻ",
      content: content || "",
      createdAt: serverTimestamp()
    };
    
    const docRef = await addDoc(commentsCol, payload);
    console.log("💬 Posted comment with Firestore ID:", docRef.id);
    
    return {
      id: docRef.id,
      ...payload,
      createdAt: new Date().toISOString() // Local optimistic date
    };
  } catch (error) {
    console.error("❌ Failed to register comment:", error);
    throw error;
  }
}
