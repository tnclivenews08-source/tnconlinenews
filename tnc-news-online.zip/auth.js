/**
 * auth.js - Firebase Authentication Manager (Vanilla JS / ES Module)
 * 
 * Implements the administrative user control gates. Includes Email-Password
 * verification credentials and active session listeners.
 */

import { auth } from "./firebase.js";
import { 
  signInWithEmailAndPassword, 
  signOut, 
  onAuthStateChanged,
  setPersistence,
  browserLocalPersistence
} from "https://www.gstatic.com/firebasejs/10.8.0/firebase-auth.js";

/**
 * Perform Email and Password Authentication for Admin dashboard access.
 * Automatically configures persistent browser state.
 * @param {string} email 
 * @param {string} password 
 * @returns {Promise<UserCredential>}
 */
export async function loginAdmin(email, password) {
  try {
    // Force local storage persistence to keep the session active across refreshes
    await setPersistence(auth, browserLocalPersistence);
    const userCredential = await signInWithEmailAndPassword(auth, email, password);
    console.log("🔓 Admin authenticated successfully:", userCredential.user.email);
    return userCredential;
  } catch (error) {
    console.error("❌ Authentication failed:", error.message);
    throw error;
  }
}

/**
 * Sign out the currently active admin session.
 * @returns {Promise<void>}
 */
export async function logoutAdmin() {
  try {
    await signOut(auth);
    console.log("🔒 Admin logged out successfully.");
  } catch (error) {
    console.error("❌ Sign out failed:", error);
    throw error;
  }
}

/**
 * Register state listener callback to observe session survival.
 * @param {function(User|null)} callback 
 */
export function watchAdminSession(callback) {
  return onAuthStateChanged(auth, (user) => {
    if (user) {
      console.log("👤 Session Active - Email:", user.email);
      callback(user);
    } else {
      console.log("👤 No session active.");
      callback(null);
    }
  });
}
