export interface Comment {
  id: string;
  author: string;
  content: string;
  createdAt: string;
}

export interface NewsArticle {
  id: string;
  title: string;       // Malayalam Title
  description: string; // Malayalam Short Description
  content: string;     // Malayalam Full Content
  thumbnail: string;   // Image URL or Base64
  category: string;    // e.g., 'രാഷ്ട്രീയം' (Politics), 'പ്രാദേശികം' (Local), 'കായികം' (Sports), 'വിനോദം' (Entertainment)
  author: string;      // Reporter Name
  views: number;
  likes: number;
  publishedAt: string;
  comments: Comment[];
  videoUrl?: string;   // Optional YouTube URL to show embedded player (great for YouTube news look!)
}

export type NewsCategory = 'എല്ലാം' | 'രാഷ്ട്രീയം' | 'പ്രാദേശികം' | 'കായികം' | 'വിനോദം' | 'പ്രവാസം' | 'കേരളം';

export interface AdBannerType {
  id: string;
  title: string;       // Malayalam Ad text
  subtitle: string;
  imageUrl: string;
  link: string;
  sponsor: string;
  slot?: "top" | "middle" | "sidebar";
  category?: string;   // specific category or "All"
}

export interface BreakingNews {
  id: string;
  text: string;
  createdAt: string;
}

export interface PortalNotification {
  id: string;
  articleId?: string;
  title: string;
  message: string;
  createdAt: string;
  read?: boolean;
}

