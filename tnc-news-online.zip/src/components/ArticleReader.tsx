import { ArrowLeft, User, Eye, Calendar, Award, Volume2, VolumeX, Megaphone, Pencil } from "lucide-react";
import { NewsArticle, AdBannerType } from "../types";
import CommentsSection from "./CommentsSection";
import React, { useState } from "react";

interface ArticleReaderProps {
  article: NewsArticle;
  onBack: () => void;
  onLike: () => void;
  onPostComment: (author: string, content: string) => Promise<void>;
  relatedArticles: NewsArticle[];
  onSelectArticle: (article: NewsArticle) => void;
  ads: AdBannerType[];
  isAdmin?: boolean;
  onOpenAdmin?: (tab?: "news" | "ads" | "breaking") => void;
}

export default function ArticleReader({
  article,
  onBack,
  onLike,
  onPostComment,
  relatedArticles,
  onSelectArticle,
  ads,
  isAdmin = false,
  onOpenAdmin,
}: ArticleReaderProps) {
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [speechSynthesisObj, setSpeechSynthesisObj] = useState<SpeechSynthesisUtterance | null>(null);

  // Helper to extract clean youtube embed URL from any watch or share links
  const getYouTubeEmbedUrl = (url: string | undefined): string | null => {
    if (!url) return null;
    const trimmed = url.trim();
    // Regular expression to match standard watch, short, search, or mobile share URLs
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=|shorts\/)([^#\&\?]*).*/;
    const match = trimmed.match(regExp);
    
    if (match && match[2].length === 11) {
      return `https://www.youtube.com/embed/${match[2]}`;
    }
    
    // Check if it is a bare 11-char video ID
    if (trimmed.length === 11 && !trimmed.includes("/") && !trimmed.includes(".")) {
      return `https://www.youtube.com/embed/${trimmed}`;
    }
    
    return trimmed;
  };

  // Native text to speech simulator or native web speech
  const toggleTTS = () => {
    if (isSpeaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    } else {
      // Clean Malayalam reading
      const utterance = new SpeechSynthesisUtterance(article.content);
      // Attempt Malayalam locale
      utterance.lang = "ml-IN";
      utterance.onend = () => setIsSpeaking(false);
      window.speechSynthesis.speak(utterance);
      setSpeechSynthesisObj(utterance);
      setIsSpeaking(true);
    }
  };

  const shareViaPlatform = (platform: string) => {
    const text = `TNC News: ${article.title}`;
    const url = window.location.href;
    switch (platform) {
      case "whatsapp":
        window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(text + " - " + url)}`);
        break;
      case "facebook":
        window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`);
        break;
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="mb-6 flex items-center space-x-2 text-gray-500 hover:text-brand-red font-bold text-sm transition-colors group cursor-pointer"
      >
        <ArrowLeft className="w-4 h-4 group-hover:-translate-x-1 transition-transform" />
        <span>പ്രധാന താളിലേക്ക് (Back to Home)</span>
      </button>

      {/* Main Content & Sidebar Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Left Side: Full Article View */}
        <div className="lg:col-span-8 space-y-6">
          {/* Article Header */}
          <div className="space-y-4">
            <span className="bg-brand-red/10 text-brand-red text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider">
              {article.category}
            </span>

            <h1 className="text-xl md:text-3xl font-extrabold text-gray-950 tracking-tight leading-tight md:leading-snug text-left">
              {article.title}
            </h1>

            {/* Author / Views Metas */}
            <div className="flex flex-wrap items-center justify-between gap-4 py-3.5 border-y border-gray-100 text-xs md:text-sm text-gray-500 font-semibold">
              <div className="flex items-center space-x-5">
                <div className="flex items-center space-x-1.5">
                  <User className="w-4 h-4 text-brand-red" />
                  <span className="text-gray-900 font-bold">{article.author}</span>
                </div>
                <div className="flex items-center space-x-1.5 pl-0">
                  <Calendar className="w-4 h-4" />
                  <span>
                    {new Date(article.publishedAt).toLocaleDateString("ml-IN", {
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </span>
                </div>
              </div>

              <div className="flex items-center space-x-4">
                <span className="flex items-center space-x-1 bg-gray-50 py-1 px-2.5 rounded-md border border-gray-100">
                  <Eye className="w-4 h-4 text-gray-400" />
                  <span>{article.views} റിവ്യൂസ്</span>
                </span>

                {/* Text-to-speech toggler */}
                <button
                  onClick={toggleTTS}
                  className="flex items-center space-x-1.5 text-xs text-rose-700 bg-rose-50 hover:bg-rose-100 border border-rose-200 py-1 px-3 rounded-full cursor-pointer font-bold"
                  title="വാർത്ത കേൾക്കുക"
                >
                  {isSpeaking ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5" />
                      <span>വാർത്ത നിർത്തുക</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5 animate-pulse" />
                      <span>വാർത്ത കേൾക്കുക</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>

          {/* YouTube News or Image Banner */}
          {article.videoUrl ? (
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden shadow bg-black border border-gray-100">
              <iframe
                src={getYouTubeEmbedUrl(article.videoUrl) || undefined}
                title="TNC News Video Player"
                className="absolute inset-0 w-full h-full border-0"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              />
            </div>
          ) : (
            <div className="relative aspect-video w-full rounded-2xl overflow-hidden shadow-sm bg-gray-100">
              <img
                src={article.thumbnail}
                alt={article.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>
          )}

          {/* Main Article Text */}
          <div className="text-left py-2">
            <p className="text-base md:text-lg text-gray-800 font-normal leading-relaxed whitespace-pre-line first-letter:text-4xl first-letter:font-extrabold first-letter:text-brand-red first-letter:float-left first-letter:mr-3 first-letter:mt-1">
              {article.content}
            </p>
          </div>

          {/* Core User Comment Box */}
          <CommentsSection
            comments={article.comments}
            likes={article.likes}
            onPostComment={onPostComment}
            onLike={onLike}
            onShare={shareViaPlatform}
            shareUrl={window.location.href}
          />
        </div>

        {/* Right Side: Magazine Sidebars */}
        <div className="lg:col-span-4 space-y-6">
          {/* Dynamic Sidebar Ads */}
          {ads && ads.filter(ad => {
            const isSidebar = (ad.slot || "top") === "sidebar";
            const isMatch = !ad.category || ad.category === "All" || ad.category === article.category;
            return isSidebar && isMatch;
          }).map(ad => (
            <div
              key={ad.id}
              onClick={() => {
                let destination = ad.link || "#";
                if (destination !== "#" && !/^https?:\/\//i.test(destination) && !destination.startsWith("/")) {
                  destination = "https://" + destination;
                }
                if (destination !== "#") {
                  window.open(destination, "_blank", "noopener,noreferrer");
                }
              }}
              className="group cursor-pointer bg-white border border-gray-150 rounded-3xl p-5 shadow-sm space-y-3 hover:shadow-md transition-all text-left animate-fade-in"
            >
              <div className="relative aspect-video rounded-2xl overflow-hidden bg-gray-100 shrink-0">
                <img
                  src={ad.imageUrl}
                  alt={ad.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-2 left-2 bg-black/75 text-amber-400 text-[8px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
                  SPONSORED
                </span>
              </div>
               <div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-1">
                    <Megaphone className="w-3 h-3 text-brand-red shrink-0" />
                    <p className="text-[10px] text-brand-red font-bold uppercase tracking-wider line-clamp-1">
                      {ad.sponsor}
                    </p>
                  </div>
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onOpenAdmin) onOpenAdmin("ads");
                      }}
                      className="bg-yellow-400 hover:bg-yellow-500 text-black font-black text-[9px] px-1.5 py-0.5 rounded-lg shadow-sm hover:scale-105 transition-all cursor-pointer flex items-center gap-0.5 z-10 hover:brightness-110 active:scale-95"
                    >
                      <Pencil className="w-2.5 h-2.5 shrink-0" />
                      <span>എഡിറ്റ്</span>
                    </button>
                  )}
                </div>
                <h4 className="text-sm font-bold text-gray-950 mt-1 line-clamp-2 leading-snug group-hover:text-brand-red transition-colors">
                  {ad.title}
                </h4>
                {ad.subtitle && (
                  <p className="text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed">
                    {ad.subtitle}
                  </p>
                )}
              </div>
            </div>
          ))}

          {/* Editor selection recommendation ad */}
          <div className="bg-brand-red text-white p-5 rounded-3xl relative overflow-hidden shadow-md">
            <Award className="w-10 h-10 text-yellow-300 mb-3" />
            <h4 className="text-base font-extrabold mb-1">TNC പ്രീമിയം വെരിഫൈഡ് വാർത്തകൾ</h4>
            <p className="text-xs text-red-500 leading-relaxed font-semibold">
              ഞങ്ങളുടെ ലേഖകർ തത്സമയം വിശ്വസനീയമായി റിപ്പോർട്ട് ചെയ്യുന്ന പ്രാദേശിക വാർത്തകൾ നിങ്ങളുടെ ഫോണിൽ നേരിട്ട് ലഭ്യമാക്കുന്നു.
            </p>
          </div>

          {/* Related Stories list */}
          <div className="bg-white border border-gray-100 rounded-3xl p-5 shadow-sm space-y-4">
            <div className="flex items-center space-x-2 border-b border-gray-100 pb-3 mb-4 text-left select-none">
              <span className="w-1.5 h-4 bg-brand-red rounded-full shrink-0"></span>
              <h3 className="text-sm font-black text-gray-950 tracking-wider uppercase">
                മറ്റു പ്രധാന വാർത്തകൾ (Popular News)
              </h3>
            </div>

            <div className="space-y-4">
              {relatedArticles
                .filter((a) => a.id !== article.id)
                .slice(0, 4)
                .map((related) => (
                  <div
                    key={related.id}
                    onClick={() => onSelectArticle(related)}
                    className="flex space-x-3 cursor-pointer group hover:bg-gray-50 p-2.5 rounded-xl transition-all border border-transparent hover:border-red-55 border-b-gray-50/50"
                  >
                    <img
                      src={related.thumbnail}
                      alt={related.title}
                      referrerPolicy="no-referrer"
                      className="w-16 h-16 rounded-lg object-cover bg-gray-100 shrink-0"
                    />
                    <div className="flex flex-col justify-between overflow-hidden">
                      <h4 className="text-xs md:text-sm font-bold text-gray-900 group-hover:text-brand-red transition-colors line-clamp-2 leading-snug text-left">
                        {related.title}
                      </h4>
                      <p className="text-[10px] text-gray-400 font-bold mt-1 text-left">
                        {related.category} • {related.views} views
                      </p>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
