import { useState } from "react";
import { Megaphone, ExternalLink, ShieldCheck, Pencil } from "lucide-react";
import { AdBannerType } from "../types";

interface AdBannerProps {
  ads: AdBannerType[];
  slot?: "top" | "middle" | "sidebar";
  isAdmin?: boolean;
  onOpenAdmin?: (tab?: "news" | "ads" | "categories") => void;
  currentCategory?: string;
}

export default function AdBanner({ ads, slot = "top", isAdmin = false, onOpenAdmin, currentCategory = "All" }: AdBannerProps) {
  const [adClicks, setAdClicks] = useState<Record<string, number>>({});
  const [showToast, setShowToast] = useState<string | null>(null);

  const handleAdClick = (ad: AdBannerType) => {
    setAdClicks((prev) => ({
      ...prev,
      [ad.id]: (prev[ad.id] || 0) + 1
    }));

    let destination = ad.link || "#";
    if (destination !== "#" && !/^https?:\/\//i.test(destination) && !destination.startsWith("/")) {
      destination = "https://" + destination;
    }

    if (destination !== "#") {
      setShowToast(`[${ad.sponsor}] എന്ന സ്പോൺസറുടെ വെബ്സൈറ്റിലേക്ക് നിങ്ങളെ നയിക്കുന്നു!`);
      setTimeout(() => {
        try {
          window.open(destination, "_blank", "noopener,noreferrer");
        } catch (e) {
          console.error("Popup blocked:", e);
        }
      }, 800);
      setTimeout(() => {
        setShowToast(null);
      }, 4000);
    } else {
      setShowToast(`[${ad.sponsor}] - ഈ പരസ്യത്തിന് സ്വർണ്ണ ലിങ്ക് നൽകിയിട്ടില്ല.`);
      setTimeout(() => {
        setShowToast(null);
      }, 3000);
    }
  };

  const filteredAds = (ads || []).filter((ad) => {
    const adSlot = ad.slot || "top";
    if (adSlot !== slot) return false;
    if (currentCategory && currentCategory !== "എല്ലാം" && ad.category && ad.category !== "All" && ad.category !== currentCategory) {
      return false;
    }
    return true;
  });

  if (filteredAds.length === 0) {
    return null; // Return empty space if no ads for this slot
  }

  return (
    <div className="my-2.5 md:my-6 max-w-7xl mx-auto px-4">
      {/* Toast Notice */}
      {showToast && (
        <div className="fixed bottom-6 right-6 bg-emerald-900 border border-emerald-500 text-emerald-100 px-4 py-3.5 rounded-xl shadow-2xl flex items-center space-x-3 z-50 animate-bounce">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
          <p className="text-xs font-bold">{showToast}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredAds.map((ad) => (
          <div
            key={ad.id}
            onClick={() => handleAdClick(ad)}
            className="group relative cursor-pointer bg-white border border-rose-100 rounded-2xl overflow-hidden hover:shadow-lg transition-all duration-300 flex flex-col h-full animate-fade-in"
          >
            {/* Image section with relative badge */}
            <div className="relative aspect-video w-full overflow-hidden bg-gray-50 shrink-0">
              <img
                src={ad.imageUrl}
                alt={ad.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
              />
              <span className="absolute top-2.5 left-2.5 bg-black/75 text-amber-400 text-[9px] font-black px-2 py-0.5 rounded tracking-widest uppercase">
                SPONSORED
              </span>
            </div>

            {/* Content section */}
            <div className="p-3 md:p-4 flex flex-col justify-between flex-grow">
              <div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center space-x-1">
                    <Megaphone className="w-3.5 h-3.5 text-brand-red shrink-0" />
                    <p className="text-[10px] md:text-xs text-brand-red font-bold uppercase tracking-wider line-clamp-1 text-left">
                      {ad.sponsor}
                    </p>
                  </div>
                  {isAdmin && (
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        if (onOpenAdmin) onOpenAdmin("ads");
                      }}
                      className="bg-yellow-400 hover:bg-yellow-500 text-black font-black text-[9px] px-1.5 py-0.5 rounded shadow-sm hover:scale-105 transition-all cursor-pointer flex items-center gap-0.5 z-10"
                    >
                      <Pencil className="w-2.5 h-2.5 shrink-0" />
                      <span>എഡിറ്റ്</span>
                    </button>
                  )}
                </div>
                <h4 className="text-sm md:text-base font-extrabold text-gray-950 tracking-tight mt-1.5 leading-snug group-hover:text-brand-red transition-colors text-left">
                  {ad.title}
                </h4>
                {ad.subtitle && (
                  <p className="text-[11px] md:text-xs text-gray-500 mt-1 line-clamp-2 leading-relaxed text-left">
                    {ad.subtitle}
                  </p>
                )}
              </div>

              <div className="mt-3 pt-3 border-t border-dashed border-gray-100 flex items-center justify-between">
                <span className="text-[10px] font-semibold text-gray-400">
                  {adClicks[ad.id] || 0} ക്ലിക്കുകൾ
                </span>
                <span className="text-xs font-bold text-brand-red group-hover:underline flex items-center space-x-1">
                  <span>கூടുതൽ കാണുക</span>
                  <ExternalLink className="w-3 h-3" />
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
