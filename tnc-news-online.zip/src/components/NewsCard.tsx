import { Eye, ThumbsUp, Calendar, Play } from "lucide-react";
import { NewsArticle } from "../types";

interface NewsCardProps {
  article: NewsArticle;
  onClick: () => void;
}

export default function NewsCard({ article, onClick }: NewsCardProps) {
  // Format dates in Malayalam format or nice relative terms
  const formatMalayalamTime = (dateStr: string) => {
    try {
      const date = new Date(dateStr);
      const now = new Date();
      const diffMs = now.getTime() - date.getTime();
      const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));

      if (diffHrs < 1) return "ഇപ്പോൾ തന്നെ";
      if (diffHrs < 24) return `${diffHrs} മണിക്കൂർ മുൻപ്`;
      
      const diffDays = Math.floor(diffHrs / 24);
      return `${diffDays} ദിവസം മുൻപ്`;
    } catch {
      return "കുറച്ചു മുൻപ്";
    }
  };

  // Safe category color pairing
  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case "രാഷ്ട്രീയം": return "bg-red-600 text-white";
      case "കായികം": return "bg-blue-600 text-white";
      case "വിനോദം": return "bg-pink-600 text-white";
      case "പ്രവാസം": return "bg-amber-600 text-white";
      case "കേരളം": return "bg-emerald-600 text-white";
      default: return "bg-brand-red text-white";
    }
  };

  return (
    <article
      onClick={onClick}
      className="group cursor-pointer bg-white rounded-xl md:rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-gray-100 transition-all duration-300 flex flex-col h-full transform hover:-translate-y-1"
    >
      {/* 16:9 Thumbnail Cover */}
      <div className="relative aspect-video w-full overflow-hidden bg-gray-100 shrink-0">
        <img
          src={article.thumbnail}
          alt={article.title}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
          loading="lazy"
        />

        {/* Video Icon if Video URL is provided */}
        {article.videoUrl && (
          <div className="absolute inset-0 bg-black/25 flex items-center justify-center group-hover:bg-black/40 transition-colors">
            <div className="bg-red-600/90 text-white p-2.5 rounded-full shadow-lg group-hover:scale-110 transition-transform duration-300">
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </div>
          </div>
        )}

        {/* Category Overlay Pill */}
        <span className={`absolute bottom-2.5 left-2.5 text-[9px] md:text-[10px] font-black tracking-wide px-2 py-0.5 md:px-2.5 md:py-1 rounded shadow-md ${getCategoryColor(article.category)}`}>
          {article.category}
        </span>

        {/* Live views indicator */}
        <span className="absolute bottom-2.5 right-2.5 bg-black/75 text-white text-[9px] md:text-[10px] font-bold px-2 py-0.5 md:px-2.5 md:py-1 rounded flex items-center space-x-1 backdrop-blur-xs">
          <Eye className="w-3 h-3 text-red-400" />
          <span>{article.views} views</span>
        </span>
      </div>

      {/* YouTube Layout details section below image */}
      <div className="p-3 md:p-4 flex space-x-3 items-start flex-grow min-w-0">
        {/* News logo circular avatar (Always visible, just like YouTube!) */}
        <div className="shrink-0">
          <div className="w-8 h-8 md:w-9 md:h-9 rounded-full bg-brand-light border border-red-200 text-brand-red flex items-center justify-center font-bold text-xs ring-2 ring-transparent group-hover:ring-brand-red transition-all">
            {article.author ? article.author[0] : "T"}
          </div>
        </div>

        {/* News text info */}
        <div className="flex flex-col justify-between w-full min-w-0">
          <div className="text-left">
            <h3 className="line-clamp-2 text-sm md:text-base font-extrabold text-gray-950 tracking-tight leading-snug group-hover:text-brand-red transition-colors mb-1">
              {article.title}
            </h3>
            <p className="line-clamp-2 text-[11px] md:text-xs text-gray-500 font-medium leading-relaxed mb-3">
              {article.description}
            </p>
          </div>

          <div className="flex flex-wrap items-center text-[10px] md:text-[11px] text-gray-400 font-semibold border-t border-gray-50 pt-2 shrink-0">
            <span className="truncate hover:text-brand-red font-semibold text-gray-600 mr-2">
              {article.author || "ലേഖകൻ"}
            </span>
            <div className="flex items-center space-x-2 shrink-0">
              <span className="hidden xs:inline">•</span>
              <span className="flex items-center text-rose-500">
                <ThumbsUp className="w-2.5 h-2.5 md:w-3 md:h-3 mr-0.5" />
                <span>{article.likes}</span>
              </span>
              <span>•</span>
              <span className="flex items-center">
                <Calendar className="w-2.5 h-2.5 md:w-3 md:h-3 mr-0.5" />
                <span>{formatMalayalamTime(article.publishedAt)}</span>
              </span>
            </div>
          </div>
        </div>
      </div>
    </article>
  );
}
