import React, { useState } from "react";
import { 
  signInWithEmailAndPassword, 
  createUserWithEmailAndPassword, 
  sendPasswordResetEmail, 
  updateProfile 
} from "firebase/auth";
import { auth } from "../firebase";
import { Mail, Lock, User, KeyRound, Eye, EyeOff, CheckCircle2, AlertCircle, RefreshCw } from "lucide-react";

interface AuthViewProps {
  onSuccess: (email: string, displayName?: string) => void;
  onCancel?: () => void;
  defaultMode?: "login" | "signup";
}

export default function AuthView({ onSuccess, onCancel, defaultMode = "login" }: AuthViewProps) {
  const [mode, setMode] = useState<"login" | "signup" | "forgot">(defaultMode);
  
  // Input fields
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [fullName, setFullName] = useState("");
  
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [hasConfigError, setHasConfigError] = useState(false);
  
  // Messaging & UI alerts
  const [errorText, setErrorText] = useState("");
  const [successText, setSuccessText] = useState("");

  const handleTogglePassword = () => setShowPassword(!showPassword);

  const resetFormStates = () => {
    setErrorText("");
    setSuccessText("");
    setHasConfigError(false);
  };

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormStates();
    
    if (!email.trim() || !password) {
      setErrorText("ദയവായി ഇമെയിലും പാസ്‌വേഡും നൽകുക.");
      return;
    }
    
    setIsLoading(true);

    // Strict Admin Credential Enforcer
    if (email.trim().toLowerCase() === "mejo274@gmail.com") {
      if (password === "Mejo2255@tnc") {
        setSuccessText("ലോഗിൻ വിജയകരമായി! (Secure Admin Access)");
        const userObj = { email: "mejo274@gmail.com", displayName: "Mejo (Admin)" };
        localStorage.setItem("tnc_custom_user", JSON.stringify(userObj));
        setTimeout(() => {
          onSuccess("mejo274@gmail.com", "Mejo (Admin)");
        }, 1000);
        return;
      } else {
        setErrorText("അഡ്മിൻ പാസ്‌വേഡ് തെറ്റാണ്. (Incorrect Admin Password)");
        setIsLoading(false);
        return;
      }
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email.trim(), password);
      const user = userCredential.user;
      setSuccessText("ലോഗിൻ വിജയകരമായി!");
      setTimeout(() => {
        onSuccess(user.email || "", user.displayName || "");
      }, 1000);
    } catch (err: any) {
      console.warn("Firebase Auth Error, trying server-side fallback authentication:", err);
      try {
        const response = await fetch("/api/auth/email-login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.trim(), password })
        });
        const data = await response.json();
        if (response.ok && data.success) {
          localStorage.setItem("tnc_custom_user", JSON.stringify(data.user));
          setSuccessText("ലോഗിൻ വിജയകരമായി! (Secure Fallback Active)");
          setTimeout(() => {
            onSuccess(data.user.email, data.user.displayName || "");
          }, 1000);
        } else {
          throw new Error(data.error || "ലോഗിൻ ചെയ്യാൻ സാധിച്ചില്ല.");
        }
      } catch (fallbackErr: any) {
        console.error("Authentication fallback error:", fallbackErr);
        let msg = fallbackErr.message || "ലോഗിൻ ചെയ്യാൻ സാധിച്ചില്ല. ദയവായി വിവരങ്ങൾ പരിശോധിക്കുക.";
        if (err.code === "auth/invalid-email") msg = "തന്നിരിക്കുന്ന ഇമെയിൽ വിലാസം തെറ്റാണ്.";
        else if (err.code === "auth/wrong-password") msg = "നൽകിയ പാസ്‌വേഡ് തെറ്റാണ്.";
        setErrorText(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleSignupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormStates();
    
    if (!fullName.trim()) {
      setErrorText("ദയവായി നിങ്ങളുടെ മുഴുവൻ പേര് നൽകുക.");
      return;
    }
    if (password.length < 6) {
      setErrorText("പാസ്‌വേഡിന് കുറഞ്ഞത് 6 അക്ഷരങ്ങൾ നീളമുണ്ടായിരിക്കണം.");
      return;
    }
    if (password !== confirmPassword) {
      setErrorText("പാസ്‌വേഡുകൾ പരസ്പരം പൊരുത്തപ്പെടുന്നില്ല!");
      return;
    }
    
    if (email.trim().toLowerCase() === "mejo274@gmail.com") {
      setErrorText("ഈ ഇമെയിൽ അഡ്മിൻ ഉപയോഗിക്കുന്നതാണ്. സൈൻ അപ്പ് അനുവദനീയമല്ല.");
      return;
    }

    setIsLoading(true);
    try {
      const userCredential = await createUserWithEmailAndPassword(auth, email.trim(), password);
      await updateProfile(userCredential.user, {
        displayName: fullName.trim()
      });
      
      // Auto-sync user data to server fallback storage
      try {
        await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.trim(), password, displayName: fullName.trim() })
        });
      } catch (syncErr) {
        console.warn("Offline server sync failed", syncErr);
      }

      setSuccessText("അക്കൗണ്ട് വിജയകരമായി സൃഷ്ടിച്ചു! ലോഗിൻ പൂർത്തിയാക്കുന്നു...");
      setTimeout(() => {
        onSuccess(userCredential.user.email || "", fullName.trim());
      }, 1500);
    } catch (err: any) {
      console.warn("Firebase Register Error, trying server-side registration fallback:", err);
      try {
        const response = await fetch("/api/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.trim(), password, displayName: fullName.trim() })
        });
        const data = await response.json();
        if (response.ok && data.success) {
          localStorage.setItem("tnc_custom_user", JSON.stringify(data.user));
          setSuccessText("അക്കൗണ്ട് വിജയകരമായി സൃഷ്ടിച്ചു! (Secure Fallback Active)");
          setTimeout(() => {
            onSuccess(data.user.email, data.user.displayName || fullName.trim());
          }, 1500);
        } else {
          throw new Error(data.error || "രജിസ്‌ട്രേഷൻ പൂർത്തിയാക്കാൻ സാധിച്ചില്ല.");
        }
      } catch (fallbackErr: any) {
        console.error("Registration fallback error:", fallbackErr);
        let msg = fallbackErr.message || "രജിസ്‌ട്രേഷൻ പരാജയപ്പെട്ടു. ദയവായി വീണ്ടും ശ്രമിക്കുക.";
        if (err.code === "auth/email-already-in-use") msg = "ഈ ഇമെയിൽ വിലാസം ഇതിനകം മറ്റൊരു അക്കൗണ്ടിനായി ഉപയോഗിച്ചിട്ടുള്ളതാണ്.";
        else if (err.code === "auth/invalid-email") msg = "തന്നിരിക്കുന്ന ഇമെയിൽ വിലാസം അസാധുവാണ്.";
        setErrorText(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleForgotPasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    resetFormStates();
    
    if (!email.trim()) {
      setErrorText("ദയവായി ഇമെയിൽ വിലാസം നൽകുക.");
      return;
    }
    
    setIsLoading(true);
    try {
      await sendPasswordResetEmail(auth, email.trim());
      setSuccessText("പാസ്‌വേഡ് റീസെറ്റ് ചെയ്യാനുള്ള ലിങ്ക് നിങ്ങളുടെ ഇമെയിലിലേക്ക് അയച്ചിട്ടുണ്ട്. ദയവായി ഇൻബോക്‌സ് പരിശോധിക്കുക.");
      setEmail("");
    } catch (err: any) {
      console.warn("Firebase Forgot PW Error, trying server-side password reset fallback:", err);
      try {
        const response = await fetch("/api/auth/reset-password", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.trim() })
        });
        const data = await response.json();
        if (response.ok && data.success) {
          setSuccessText("പാസ്‌വേഡ് റീസെറ്റ് ചെയ്യാനുള്ള ഇൻസ്ട്രക്ഷൻ നിങ്ങളുടെ ഇമെയിലിലേക്ക് അയച്ചിട്ടുണ്ട്.");
          setEmail("");
        } else {
          throw new Error(data.error || "മാറ്റം വരുത്താൻ സാധിച്ചില്ല.");
        }
      } catch (fallbackErr: any) {
        console.error("Password reset fallback error:", fallbackErr);
        let msg = fallbackErr.message || "ഇമെയിൽ അയക്കാൻ പരാജയപ്പെട്ടു. ഇമെയിൽ വിലാസം പരിശോധിക്കുക.";
        setErrorText(msg);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-md w-full mx-auto bg-white border border-gray-100 rounded-3xl p-6 md:p-8 shadow-xl text-left transform duration-300 max-h-[82vh] overflow-y-auto">
      <div className="text-center mb-6">
        <span className="bg-red-50 text-brand-red px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest inline-block mb-3">
          TNC ന്യൂസ് ഓൺലൈൻ അക്കൗണ്ട്
        </span>
        <h2 className="text-xl md:text-2xl font-black text-gray-900 leading-tight">
          {mode === "login" && "ലോഗിൻ ചെയ്യുക"}
          {mode === "signup" && "ഒരു പുതിയ അക്കൗണ്ട് സൃഷ്ടിക്കുക"}
          {mode === "forgot" && "പാസ്‌വേഡ് വീണ്ടെടുക്കുക"}
        </h2>
        <p className="text-xs text-gray-400 font-medium mt-1">
          {mode === "login" && "തത്സമയ വാർത്താ അപ്ഡേറ്റുകൾക്കായി അക്കൗണ്ടിലേക്ക് കയറുക."}
          {mode === "signup" && "വരിക്കാരാകാനും അഭിപ്രായങ്ങൾ പങ്കുവെക്കാനും തത്സമയം അക്കൗണ്ട് എടുക്കുക."}
          {mode === "forgot" && "നിങ്ങളുടെ രജിസ്റ്റർ ചെയ്ത ഇമെയിൽ വിലാസം വഴി പാസ്‌വേഡ് അപ്‌ഡേറ്റ് ചെയ്യുക."}
        </p>
      </div>

      {/* Success and Error Toast / Block Alerts */}
      {errorText && (
        <div className="mb-5 space-y-3">
          <div className="p-3.5 bg-red-50 border-l-4 border-red-500 rounded-r-xl flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-600 shrink-0 mt-0.5" />
            <p className="text-xs text-red-800 font-bold leading-normal">{errorText}</p>
          </div>
          
          {hasConfigError && (
            <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl space-y-3">
              <h4 className="text-xs font-black text-amber-900 uppercase tracking-wider">
                അടിയന്തിര ഫയർബേസ് സജ്ജീകരണ നിർദ്ദേശം (Setup Instructions):
              </h4>
              <ol className="text-[11px] text-amber-800 space-y-1 pl-4 list-decimal font-semibold">
                <li>Google Firebase Console-ലേക്ക് പ്രവേശിക്കുക.</li>
                <li><strong>Build &gt; Authentication</strong> ക്ലിക്ക് ചെയ്യുക.</li>
                <li><strong>Sign-in method</strong> എന്ന ടാബിലേക്ക് മാറുക.</li>
                <li><strong>Email/Password</strong> തിരഞ്ഞെടുത്ത് "Enable" കൊടുത്ത ശേഷം <strong>Save</strong> ചെയ്യുക.</li>
              </ol>
              
              <div className="pt-2 border-t border-amber-200/50">
                <p className="text-[10px] text-amber-700 font-medium mb-2 leading-relaxed">
                  പൂർണ്ണ പ്രവർത്തനത്തിനായി ഫയർബേസ് സജ്ജീകരിക്കുക.
                </p>
              </div>
            </div>
          )}
        </div>
      )}

      {successText && (
        <div className="mb-5 p-3.5 bg-emerald-50 border-l-4 border-emerald-500 rounded-r-xl flex items-start gap-2.5">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <p className="text-xs text-emerald-800 font-bold leading-normal text-left">{successText}</p>
        </div>
      )}

      {/* Auth Submit Forms */}
      {mode === "login" && (
        <form onSubmit={handleLoginSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              ഇമെയിൽ വിലാസം (Email)
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                placeholder="നിങ്ങളുടെ ഇമെയിൽ എഴുതുക..."
                value={email}
                onChange={(e) => { resetFormStates(); setEmail(e.target.value); }}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1 pl-1">
              <label className="text-[11px] font-bold text-gray-500">
                പാസ്‌വേഡ് (Password)
              </label>
              <button
                type="button"
                onClick={() => { resetFormStates(); setMode("forgot"); }}
                className="text-[10px] font-black text-brand-red hover:underline"
              >
                പാസ്‌വേഡ് ഓർമ്മയില്ലേ? (Forgot Password)
              </button>
            </div>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder="നിങ്ങളുടെ പാസ്‌വേഡ് നൽകുക..."
                value={password}
                onChange={(e) => { resetFormStates(); setPassword(e.target.value); }}
                className="w-full pl-10 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
              <button
                type="button"
                onClick={handleTogglePassword}
                className="absolute right-3.5 text-gray-400 hover:text-gray-600 focus:outline-none cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-brand-red hover:bg-brand-dark text-white font-extrabold py-3 rounded-xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> ലോഗിൻ ചെയ്യുന്നു...
              </>
            ) : (
              "ലോഗിൻ ചെയ്യുക (Login)"
            )}
          </button>
        </form>
      )}

      {mode === "signup" && (
        <form onSubmit={handleSignupSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              മുഴുവൻ പേര് (Full Name)
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <User className="w-4 h-4" />
              </span>
              <input
                type="text"
                required
                placeholder="മുഴുവൻ പേര് എഴുതുക..."
                value={fullName}
                onChange={(e) => { resetFormStates(); setFullName(e.target.value); }}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              ഇമെയിൽ വിലാസം (Email)
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                placeholder="നിങ്ങളുടെ ഇമെയിൽ എഴുതുക..."
                value={email}
                onChange={(e) => { resetFormStates(); setEmail(e.target.value); }}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              പാസ്‌വേഡ് (Password - കുറഞ്ഞത് 6 അക്ഷരം)
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <Lock className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder="സുരക്ഷിതമായ പാസ്‌വേഡ്..."
                value={password}
                onChange={(e) => { resetFormStates(); setPassword(e.target.value); }}
                className="w-full pl-10 pr-10 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
              <button
                type="button"
                onClick={handleTogglePassword}
                className="absolute right-3.5 text-gray-400 hover:text-gray-600 focus:outline-none cursor-pointer"
              >
                {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              പാസ്‌വേഡ് വീണ്ടും ഉറപ്പാക്കുക (Confirm Password)
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <KeyRound className="w-4 h-4" />
              </span>
              <input
                type={showPassword ? "text" : "password"}
                required
                placeholder="പാസ്‌വേഡ് വീണ്ടും ടൈപ്പ് ചെയ്യുക..."
                value={confirmPassword}
                onChange={(e) => { resetFormStates(); setConfirmPassword(e.target.value); }}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-brand-red hover:bg-brand-dark text-white font-extrabold py-3 rounded-xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> അക്കൗണ്ട് തുറക്കുന്നു...
              </>
            ) : (
              "അക്കൗണ്ട് സൃഷ്ടിക്കുക (Sign Up)"
            )}
          </button>
        </form>
      )}

      {mode === "forgot" && (
        <form onSubmit={handleForgotPasswordSubmit} className="space-y-4">
          <div>
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">
              നിങ്ങളുടെ രജിസ്റ്റർ ചെയ്ത ഇമെയിൽ എഴുതുക
            </label>
            <div className="relative flex items-center">
              <span className="absolute left-3.5 text-gray-400">
                <Mail className="w-4 h-4" />
              </span>
              <input
                type="email"
                required
                placeholder="ഇമെയിൽ എഴുതുക..."
                value={email}
                onChange={(e) => { resetFormStates(); setEmail(e.target.value); }}
                className="w-full pl-10 pr-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white transition-all font-semibold"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-brand-red hover:bg-brand-dark text-white font-extrabold py-3 rounded-xl text-sm transition-all shadow-md active:scale-95 flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
          >
            {isLoading ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" /> ലിങ്ക് അയക്കുന്നു...
              </>
            ) : (
              "റീസെറ്റ് ലിങ്ക് അയക്കാം (Send Verification Link)"
            )}
          </button>

          <button
            type="button"
            onClick={() => { resetFormStates(); setMode("login"); }}
            className="w-full py-2.5 rounded-xl border border-gray-200 hover:bg-gray-50 font-bold text-xs text-gray-600 transition-colors cursor-pointer block text-center"
          >
            ലോഗിൻ പേജിലേക്ക് തിരികെ പോവുക
          </button>
        </form>
      )}

      {/* Tabs / Footer buttons */}
      <div className="mt-6 border-t border-gray-50 pt-4 flex flex-col gap-2">
        {mode === "login" && (
          <div className="text-center">
            <span className="text-xs text-gray-400 font-bold">അക്കൗണ്ട് നിലവിലില്ലേ? </span>
            <button
              onClick={() => { resetFormStates(); setMode("signup"); }}
              className="text-xs font-black text-brand-red hover:underline ml-1"
            >
              പുതിയ പുതിയ അക്കൗണ്ട് സൃഷ്ടിക്കുക (Sign Up)
            </button>
          </div>
        )}

        {mode === "signup" && (
          <div className="text-center">
            <span className="text-xs text-gray-400 font-bold">ഇതിനകം അക്കൗണ്ട് ഉണ്ടോ? </span>
            <button
              onClick={() => { resetFormStates(); setMode("login"); }}
              className="text-xs font-black text-brand-red hover:underline ml-1"
            >
              തത്സമയം ലോഗിൻ ചെയ്യുക (Login)
            </button>
          </div>
        )}

        {onCancel && (
          <button
            onClick={onCancel}
            className="w-full py-1.5 text-xs text-gray-400 font-bold decoration-brand-red hover:text-gray-700 hover:underline cursor-pointer"
          >
            തുടരുക / പിന്നീട് ചെയ്യാം (Skip / Close)
          </button>
        )}
      </div>
    </div>
  );
}
