import React, { useState } from "react";
import { Send, User, MessageCircle, Heart, Share2, CheckCircle, Quote } from "lucide-react";
import { Comment } from "../types";

interface CommentsSectionProps {
  comments: Comment[];
  likes: number;
  onPostComment: (author: string, content: string) => Promise<void>;
  onLike: () => void;
  onShare: (platform: string) => void;
  shareUrl: string;
}

export default function CommentsSection({
  comments,
  likes,
  onPostComment,
  onLike,
  onShare,
  shareUrl,
}: CommentsSectionProps) {
  const [authorName, setAuthorName] = useState("");
  const [commentText, setCommentText] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [likedLocal, setLikedLocal] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authorName.trim() || !commentText.trim()) return;

    setIsSubmitting(true);
    try {
      await onPostComment(authorName, commentText);
      setCommentText(""); // Reset text but keep user name for comfort
    } catch (err) {
      console.error("Failed to post comment:", err);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleShareClick = (platform: string) => {
    if (platform === "copy") {
      navigator.clipboard.writeText(shareUrl || window.location.href);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    } else {
      onShare(platform);
    }
  };

  const localLikeTrigger = () => {
    if (!likedLocal) {
      setLikedLocal(true);
      onLike();
    }
  };

  const formatCommentDate = (dateStr: string) => {
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString("ml-IN", {
        day: "numeric",
        month: "short",
        hour: "2-digit",
        minute: "2-digit",
      });
    } catch {
      return "കുറച്ചു മുൻപ്";
    }
  };

  return (
    <div className="bg-white border border-gray-100 rounded-3xl p-6 shadow-sm mt-8">
      {/* Interact Panel (Likes & Shares) */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-gray-100 pb-6 mb-6">
        <button
          onClick={localLikeTrigger}
          className={`flex items-center space-x-2.5 px-6 py-3 rounded-full text-sm font-bold transition-all ${
            likedLocal
              ? "bg-rose-50 text-rose-600 border border-rose-200"
              : "bg-gray-50 text-gray-700 hover:bg-rose-50 hover:text-rose-600 border border-gray-100"
          }`}
        >
          <Heart className={`w-5 h-5 ${likedLocal ? "fill-current scale-110" : ""} transition-all`} />
          <span>{likes} ലൈക്കുകൾ</span>
        </button>

        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-gray-400 mr-2 flex items-center space-x-1">
            <Share2 className="w-3.5 h-3.5" />
            <span>ഷെയർ ചെയ്യുക:</span>
          </span>

          <button
            onClick={() => handleShareClick("whatsapp")}
            className="bg-emerald-50 hover:bg-emerald-100 text-emerald-700 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center space-x-1 cursor-pointer"
          >
            <span>WhatsApp</span>
          </button>

          <button
            onClick={() => handleShareClick("facebook")}
            className="bg-blue-50 hover:bg-blue-100 text-blue-700 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center space-x-1 cursor-pointer"
          >
            <span>Facebook</span>
          </button>

          <button
            onClick={() => handleShareClick("copy")}
            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold px-3.5 py-2 rounded-xl text-xs flex items-center space-x-1 cursor-pointer"
          >
            <span>{copiedLink ? "ലിങ്ക് കോപ്പി ചെയ്തു!" : "ലിങ്ക് പകർത്തു"}</span>
          </button>
        </div>
      </div>

      {/* Write Comment Form */}
      <div className="mb-8">
        <h3 className="text-lg font-bold text-gray-900 border-l-4 border-brand-red pl-3.5 mb-5 select-none flex items-center space-x-2">
          <MessageCircle className="w-5 h-5 text-brand-red" />
          <span>വായനക്കാരുടെ പ്രതികരണങ്ങൾ ({comments.length})</span>
        </h3>

        <form onSubmit={handleSubmit} className="space-y-4 bg-gray-50/50 p-5 rounded-2xl border border-gray-100">
          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1.5 pl-1">
              നിങ്ങളുടെ പേര് (Your Name)
            </label>
            <div className="relative flex items-center">
              <User className="absolute left-3 w-4 h-4 text-gray-400" />
              <input
                type="text"
                placeholder="ഉദാഹരണത്തിന്: സലീം ഖാൻ"
                value={authorName}
                onChange={(e) => setAuthorName(e.target.value)}
                required
                className="w-full pl-10 pr-4 py-2 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1.5 pl-1">
              അഭിപ്രായം (Comment in Malayalam)
            </label>
            <textarea
              placeholder="ഈ വാർത്തയെക്കുറിച്ചുള്ള നിങ്ങളുടെ നിരീക്ഷണം പങ്കുവെക്കുക..."
              value={commentText}
              onChange={(e) => setCommentText(e.target.value)}
              required
              rows={3}
              className="w-full p-4 bg-white border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red resize-none"
            />
          </div>

          <div className="flex justify-end pr-0">
            <button
              type="submit"
              disabled={isSubmitting || !authorName.trim() || !commentText.trim()}
              className="bg-brand-red disabled:bg-gray-300 text-white font-bold px-6 py-2.5 rounded-xl text-xs flex items-center space-x-2 transition-all shadow-sm hover:shadow"
            >
              <span>പ്രതികരിക്കുക</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>
        </form>
      </div>

      {/* List Comments */}
      {comments.length === 0 ? (
        <div className="text-center py-8 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
          <Quote className="w-8 h-8 text-gray-300 mx-auto mb-2" />
          <p className="text-xs text-gray-400 font-bold">
            ഇതുവരെ പ്രതികരണങ്ങൾ രേഖപ്പെടുത്തിയിട്ടില്ല. ആദ്യ അഭിപ്രായം രേഖപ്പെടുത്തൂ!
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {comments.map((comment) => (
            <div
              key={comment.id}
              className="p-4 border border-gray-100 rounded-2xl bg-white hover:border-red-100 transition-colors"
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center space-x-2">
                  <span className="font-bold text-xs md:text-sm text-gray-800">
                    {comment.author}
                  </span>
                  <CheckCircle className="w-3.5 h-3.5 text-blue-500" title="സ്ഥിരീകരിച്ച വായനക്കാരൻ" />
                </div>
                <span className="text-[10px] text-gray-400 font-bold">
                  {formatCommentDate(comment.createdAt)}
                </span>
              </div>
              <p className="text-xs md:text-sm text-gray-600 font-normal leading-relaxed text-left pl-1">
                {comment.content}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
