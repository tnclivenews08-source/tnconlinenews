import React, { useState, useEffect, useRef } from "react";
import { Search, Calendar, CloudRain, Bell, BellRing, BellOff, Menu, X, Landmark, Globe, Trophy, Film, Home, CheckCircle2, User, LogOut } from "lucide-react";
import { NewsCategory, BreakingNews, PortalNotification } from "../types";

interface HeaderProps {
  categories?: string[];
  currentCategory: NewsCategory;
  onSelectCategory: (category: NewsCategory) => void;
  onSearch: (query: string) => void;
  onOpenAdmin: (tab?: "news" | "ads" | "categories") => void;
  isAdmin: boolean;
  onLogout: () => void;
  breakingNews?: BreakingNews[];
  notifications?: PortalNotification[];
  onSelectArticleById?: (articleId: string) => void;
  isSubscribed?: boolean;
  onToggleSubscribe?: () => void;
  subscribersCount?: number;
  onMarkAllNotificationsRead?: () => void;
  currentUser?: { email: string; displayName?: string } | null;
  onOpenAuth?: () => void;
  onLogoutUser?: () => void;
}

const CATEGORIES_WITH_ICONS: { name: any; icon: React.ReactNode }[] = [
  { name: "എല്ലാം", icon: <Home className="w-4 h-4" /> },
  { name: "കേരളം", icon: <Globe className="w-4 h-4" /> },
  { name: "പ്രാദേശികം", icon: <MapPinIcon className="w-4 h-4" /> },
  { name: "രാഷ്ട്രೀയം", icon: <Landmark className="w-4 h-4" /> },
  { name: "രാഷ്ട്രീയം", icon: <Landmark className="w-4 h-4" /> },
  { name: "കായികം", icon: <Trophy className="w-4 h-4" /> },
  { name: "വിനോദം", icon: <Film className="w-4 h-4" /> },
  { name: "പ്രവാസം", icon: <GlobeIcon className="w-4 h-4" /> },
];

function getCategoryIcon(name: string) {
  const found = CATEGORIES_WITH_ICONS.find((c) => c.name === name);
  return found ? found.icon : <Globe className="w-4 h-4" />;
}

function MapPinIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z" />
      <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1 1 15 0Z" />
    </svg>
  );
}

function GlobeIcon({ className }: { className?: string }) {
  return (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 0 0 8.716-6.747M12 21a9.004 9.004 0 0 1-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 1.003 1.003 0 0 1 7.843 4.582M12 3a8.997 1.003 1.003 0 0 0-7.843 4.582m15.686 0A11.953 11.953 0 0 1 12 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0 1 21 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0 1 12 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 0 1 3 12c0-.778.099-1.533.284-2.253" />
    </svg>
  );
}

export default function Header({
  categories,
  currentCategory,
  onSelectCategory,
  onSearch,
  onOpenAdmin,
  isAdmin,
  onLogout,
  notifications = [],
  onSelectArticleById,
  isSubscribed = false,
  onToggleSubscribe,
  subscribersCount = 324,
  onMarkAllNotificationsRead,
  currentUser = null,
  onOpenAuth,
  onLogoutUser,
}: HeaderProps) {
  const [searchVal, setSearchVal] = useState("");
  const [timeStr, setTimeStr] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showNotifDropdown, setShowNotifDropdown] = useState(false);
  
  const dropdownRef = useRef<HTMLDivElement>(null);
  const mobileRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        if (mobileRef.current && mobileRef.current.contains(event.target as Node)) {
          return;
        }
        setShowNotifDropdown(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    // Current Indian Local Time representation (standard Kerala focus)
    const updateTime = () => {
      const options: Intl.DateTimeFormatOptions = {
        timeZone: "Asia/Kolkata",
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
      };
      const formatter = new Intl.DateTimeFormat("ml-IN", options);
      setTimeStr(formatter.format(new Date()));
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchVal);
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md border-b border-brand-light">
      {/* Top Meta Bar */}
      <div className="bg-brand-red text-white text-[10px] md:text-xs py-1 md:py-2 px-2.5 md:px-4 flex justify-between items-center select-none shadow-sm">
        <div className="flex items-center space-x-1 md:space-x-1.5 shrink-0">
          <CloudRain className="w-3 h-3 md:w-3.5 md:h-3.5 text-blue-200" />
          <span className="font-semibold text-[10px] md:text-xs">തൃശൂർ: 29°C 🌧️</span>
        </div>
        <div className="flex items-center space-x-1 md:space-x-1.5 font-medium shrink-0">
          <Calendar className="w-3 h-3 md:w-3.5 md:h-3.5 text-red-100" />
          <span className="text-[10px] md:text-xs">{timeStr || "യൂണിഫോം സമയം"}</span>
        </div>
      </div>

      {/* Main Branding Bar */}
      <div className="max-w-7xl mx-auto px-4 py-2 md:py-4 flex flex-col md:flex-row justify-between items-center gap-2 md:gap-4">
        {/* Logo and Mobile controls */}
        <div className="flex justify-between items-center w-full md:w-auto">
          <div className="flex items-center space-x-2 md:space-x-4 cursor-pointer" onClick={() => onSelectCategory("എല്ലാം")}>
            <div className="bg-brand-red p-1 md:p-1.5 rounded-lg shadow">
              <div className="bg-white text-brand-red font-black px-2 py-0.5 md:px-3 md:py-1 text-lg md:text-2xl tracking-tighter leading-none rounded">
                TNC
              </div>
            </div>
            <div>
              <h1 className="text-lg md:text-2xl font-extrabold text-brand-red font-display tracking-tight leading-none">
                TNC <span className="font-light opacity-90 underline underline-offset-4 decoration-brand-red">ന്യൂസ് ഓൺലൈൻ</span>
              </h1>
              <p className="text-[9px] md:text-[10px] text-gray-500 font-bold tracking-widest leading-none mt-1 md:mt-1.5">
                ONLINE PORTAL • 24/7 MALAYALAM
              </p>
            </div>
          </div>
          
          {/* Mobile Right Controls: Bell and Menu Trigger */}
          <div className="flex items-center space-x-1 md:hidden">
            {/* Mobile Notification Bell */}
            <div className="relative" ref={mobileRef}>
              <button
                onClick={() => setShowNotifDropdown(!showNotifDropdown)}
                className="relative p-2 text-gray-705 hover:text-brand-red rounded-full hover:bg-gray-50 transition-colors"
                title="നോട്ടിഫിക്കേഷനുകൾ"
              >
                <Bell className="w-5 h-5 text-gray-800" />
                {unreadCount > 0 && (
                  <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 rounded-full text-[9px] font-bold text-white flex items-center justify-center animate-bounce">
                    {unreadCount}
                  </span>
                )}
              </button>
            </div>

            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-1.5 text-gray-700 hover:text-brand-red focus:outline-none"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6 text-gray-800" />}
            </button>
          </div>
        </div>

        {/* Live Search Engine (Clean & Centered now that Breaking News is removed!) */}
        <div className="w-full md:max-w-lg flex flex-col gap-1 md:gap-2">
          <form onSubmit={handleSearchSubmit} className="relative flex items-center">
            <input
              type="text"
              placeholder="വാർത്തകൾ തിരയുക..."
              value={searchVal}
              onChange={(e) => {
                setSearchVal(e.target.value);
                onSearch(e.target.value);
              }}
              className="w-full pl-3.5 pr-8 py-1.5 md:py-2.5 bg-gray-50 border border-gray-200 rounded-full text-xs md:text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:border-transparent transition-all"
            />
            <button
              type="submit"
              className="absolute right-2.5 md:right-3 text-gray-400 hover:text-brand-red transition-colors"
            >
              <Search className="w-3.5 h-3.5 md:w-4 md:h-4" />
            </button>
          </form>
        </div>

        {/* Dynamic Admin & Notification Bell Actions (Desktop Layout) */}
        <div className="hidden md:flex items-center space-x-3 shrink-0">
          {/* Desktop Notification Bell Dropdown Container */}
          <div className="relative" ref={dropdownRef}>
            <button
              onClick={() => setShowNotifDropdown(!showNotifDropdown)}
              className="relative p-2.5 text-gray-600 hover:text-brand-red rounded-full hover:bg-gray-100 transition-colors cursor-pointer"
              title="നോട്ടിഫിക്കേഷനുകൾ"
            >
              <Bell className="w-5.5 h-5.5" />
              {unreadCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-600 rounded-full text-[9px] font-bold text-white flex items-center justify-center animate-bounce">
                  {unreadCount}
                </span>
              )}
            </button>

            {showNotifDropdown && (
              <div className="absolute right-0 mt-2.5 w-80 md:w-96 bg-white border border-gray-100 rounded-2xl shadow-xl z-[999] overflow-hidden">
                {/* Dropdown Header */}
                <div className="bg-gradient-to-r from-brand-red via-red-600 to-red-700 text-white p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <BellRing className="w-4 h-4 text-yellow-300 animate-pulse" />
                      <h3 className="font-extrabold text-sm md:text-base tracking-tight">
                        നോട്ടിഫിക്കേഷനുകൾ
                      </h3>
                    </div>
                    {subscribersCount !== undefined && (
                      <span className="bg-white/15 px-2.5 py-1 rounded-full text-[10px] font-black tracking-wide">
                        👥 {subscribersCount} వരിക്കാർ
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] opacity-80 mt-1">തത്സമയം ഏറ്റവും പുതിയ വാർത്താ അപ്‌ഡേറ്റുകൾ</p>
                </div>

                {/* Subscription Action Section */}
                <div className="p-3 border-b border-gray-100 bg-gray-50 flex items-center justify-between gap-2">
                  <p className="text-[11px] text-gray-500 font-semibold leading-tight flex-1 justify-start text-left">
                    {isSubscribed 
                      ? "നിങ്ങൾ നോട്ടിഫിക്കേഷൻ വരിക്കാരനാണ് ✓" 
                      : "പുതിയ വാർത്തകൾ ലഭിക്കാൻ സബ്‌സ്‌ക്രൈബ് ചെയ്യുക:"}
                  </p>
                  <button
                    onClick={() => {
                      if (onToggleSubscribe) onToggleSubscribe();
                    }}
                    className={`px-3 py-1.5 rounded-full font-black text-[10px] shadow-sm transition-all duration-300 transform active:scale-95 cursor-pointer whitespace-nowrap shrink-0 ${
                      isSubscribed
                        ? "bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100"
                        : "bg-brand-red hover:bg-brand-dark text-white hover:shadow"
                    }`}
                  >
                    {isSubscribed ? "സബ്‌സ്‌ക്രൈബ്ഡ് ✓" : "സബ്‌സ്‌ക്രൈബ് 🔔"}
                  </button>
                </div>

                {/* Notifications list */}
                <div className="max-h-80 overflow-y-auto divide-y divide-gray-100">
                  {notifications.length > 0 ? (
                    notifications.map((item) => (
                      <div
                        key={item.id}
                        onClick={() => {
                          if (onSelectArticleById && item.articleId) {
                            onSelectArticleById(item.articleId);
                          }
                          setShowNotifDropdown(false);
                        }}
                        className={`p-3.5 hover:bg-red-50/40 transition-colors cursor-pointer text-left flex items-start gap-3 ${
                          !item.read ? "bg-red-50/20 border-l-4 border-brand-red font-medium" : ""
                        }`}
                      >
                        <div className="bg-red-100 p-1.5 rounded-lg text-brand-red shrink-0 mt-0.5">
                          <CheckCircle2 className="w-4 h-4" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center justify-between gap-1 mb-0.5">
                            <span className="text-[11px] font-extrabold text-brand-red uppercase tracking-wider block">
                              {item.title}
                            </span>
                            {!item.read && (
                              <span className="w-1.5 h-1.5 bg-red-600 rounded-full animate-ping"></span>
                            )}
                          </div>
                          <p className="text-xs text-gray-800 font-bold line-clamp-2 leading-relaxed">
                            {item.message}
                          </p>
                          <span className="text-[10px] text-gray-400 font-medium block mt-1.5">
                            {new Date(item.createdAt).toLocaleTimeString("ml-IN", {
                              hour: "2-digit",
                              minute: "2-digit",
                              hour12: true
                            })}
                          </span>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="p-8 text-center">
                      <p className="text-xs text-gray-400 font-bold">നിലവിൽ നോട്ടിഫിക്കേഷനുകൾ ഒന്നുമില്ല!</p>
                    </div>
                  )}
                </div>

                {/* Footer action */}
                {notifications.length > 0 && (
                  <div className="p-2 border-t border-gray-100 bg-gray-50 text-center">
                    <button
                      onClick={() => {
                        if (onMarkAllNotificationsRead) onMarkAllNotificationsRead();
                      }}
                      className="text-[11px] text-brand-red font-extrabold hover:underline"
                    >
                      എല്ലാം വായിച്ചതായി അടയാളപ്പെടുത്തുക
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* User Account / Profile Icon Widget */}
          {currentUser ? (
            <div className="flex items-center gap-2 border border-gray-100 bg-gray-50 rounded-full py-1 pl-2 pr-3 shrink-0 scale-95 shadow-xs">
              <div 
                className="w-7 h-7 rounded-full bg-brand-red text-white flex items-center justify-center font-bold text-xs shrink-0 shadow-xs uppercase"
                title={currentUser.email}
              >
                {currentUser.displayName ? currentUser.displayName.charAt(0) : currentUser.email.charAt(0)}
              </div>
              <div className="flex flex-col text-left">
                <span className="text-[10px] text-gray-900 font-black truncate max-w-[100px] leading-none">
                  {currentUser.displayName || currentUser.email.split("@")[0]}
                </span>
                <span className="text-[8px] text-gray-400 font-medium leading-none mt-0.5">
                  വരിക്കാരൻ ✓
                </span>
              </div>
              <button
                onClick={onLogoutUser}
                className="text-gray-400 hover:text-brand-red p-1 rounded-full hover:bg-gray-200 transition-all cursor-pointer"
                title="അക്കൗണ്ടിൽ നിന്ന് പുറത്തു കടക്കുക (Sign Out)"
              >
                <LogOut className="w-3.5 h-3.5" />
              </button>
            </div>
          ) : (
            <button
              onClick={onOpenAuth}
              className="border border-brand-red text-brand-red hover:bg-brand-red hover:text-white px-3 py-1.5 rounded-full font-extrabold text-[11px] transition-all cursor-pointer shrink-0"
            >
              ലോഗിൻ ചെയ്യുക
            </button>
          )}

          {/* Admin Control Switch */}
          {isAdmin ? (
            <div className="flex items-center space-x-2 shrink-0">
              <button
                onClick={() => onOpenAdmin()}
                className="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-full font-bold text-xs tracking-wide transition-all shadow-xs hover:shadow-sm cursor-pointer"
              >
                അഡ്മിൻ ഡാഷ്‌ബോർഡ്
              </button>
              <button
                onClick={onLogout}
                className="bg-gray-100 hover:bg-gray-250 text-gray-800 font-bold px-2.5 py-1.5 rounded-lg text-xs transition-colors cursor-pointer"
                title="അഡ്മിൻ ഭാഗം പുറത്തു കടക്കുക"
              >
                അഡ്മിൻ ലോഗൗട്ട്
              </button>
            </div>
          ) : (
            <button
              onClick={() => onOpenAdmin()}
              className="bg-brand-red hover:bg-brand-dark text-white px-3.5 py-1.5 rounded-full font-bold text-xs tracking-wider transition-all shadow-xs hover:shadow-sm cursor-pointer shrink-0"
            >
              തത്സമയം അഡ്മിൻ
            </button>
          )}
        </div>
      </div>

      {/* Shared Dropdown rendering for Mobile Bell Icon Triggered view too */}
      {showNotifDropdown && (
        <div className="block md:hidden border-t border-gray-100 bg-white">
          <div className="bg-gradient-to-r from-brand-red via-red-600 to-red-700 text-white p-3 flex justify-between items-center text-xs">
            <span className="font-extrabold flex items-center gap-1">
              <BellRing className="w-3.5 h-3.5" /> നോട്ടിഫിക്കേഷനുകൾ
            </span>
            <span className="bg-white/20 px-2 py-0.5 rounded-full text-[10px]">
              👥 {subscribersCount} വരിക്കാർ
            </span>
          </div>
          
          <div className="p-3 border-b border-gray-100 bg-gray-50 flex items-center justify-between gap-2 text-xs">
            <p className="text-[10.5px] text-gray-500 font-semibold leading-tight text-left">
              {isSubscribed ? "നോട്ടിഫിക്കേഷൻ വരിക്കാരനാണ് ✓" : "വാർത്തകൾ ലഭിക്കാൻ സബ്‌സ്‌ക്രൈബ് ചെയ്യുക:"}
            </p>
            <button
              onClick={() => {
                if (onToggleSubscribe) onToggleSubscribe();
              }}
              className={`px-2.5 py-1 rounded-full font-black text-[9px] shadow-xs cursor-pointer ${
                isSubscribed ? "bg-emerald-50 text-emerald-700 border border-emerald-200" : "bg-brand-red text-white"
              }`}
            >
              {isSubscribed ? "സബ്‌സ്‌ക്രൈബ്ഡ് ✓" : "സബ്‌സ്‌ക്രൈബ് 🔔"}
            </button>
          </div>

          <div className="max-h-72 overflow-y-auto divide-y divide-gray-100 text-left">
            {notifications.length > 0 ? (
              notifications.map((item) => (
                <div
                  key={item.id}
                  onClick={() => {
                    if (onSelectArticleById && item.articleId) {
                      onSelectArticleById(item.articleId);
                    }
                    setShowNotifDropdown(false);
                    setMobileMenuOpen(false);
                  }}
                  className={`p-3 text-left hover:bg-red-50/20 flex items-start gap-2.5 cursor-pointer ${
                    !item.read ? "bg-red-50/10 border-l-4 border-brand-red" : ""
                  }`}
                >
                  <div className="bg-red-100 p-1.5 rounded-lg text-brand-red shrink-0 mt-0.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <span className="text-[10px] font-extrabold text-brand-red uppercase block mb-0.5 leading-none">
                      {item.title}
                    </span>
                    <p className="text-xs text-gray-800 font-bold line-clamp-2 leading-relaxed">
                      {item.message}
                    </p>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-6 text-center">
                <p className="text-xs text-gray-400 font-bold">നിലവിൽ നോട്ടിഫിക്കേഷനുകൾ ഒന്നുമില്ല</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Categories Toolbar (Desktop) */}
      <div className="border-t border-gray-105 bg-gray-50 text-gray-800">
        <div className="max-w-7xl mx-auto px-4 py-1 overflow-x-auto scrollbar-none flex space-x-2 md:space-x-8">
          {(categories && categories.length > 0 ? categories : CATEGORIES_WITH_ICONS.map(c => c.name)).map((catName) => (
            <button
              key={catName}
              onClick={() => {
                onSelectCategory(catName);
                setMobileMenuOpen(false);
              }}
              className={`flex items-center space-x-1 md:space-x-1.5 py-1.5 md:py-2 px-2.5 md:px-3.5 rounded-full text-[11px] md:text-sm font-semibold whitespace-nowrap transition-all-custom cursor-pointer ${
                currentCategory === catName
                  ? "bg-brand-red text-white shadow-sm"
                  : "text-gray-600 hover:bg-gray-200 hover:text-brand-red"
              }`}
            >
              {getCategoryIcon(catName)}
              <span>{catName}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Mobile Drawer Navigation Links */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-gray-100 bg-white text-gray-800 p-4 space-y-3 shadow-inner">
          <p className="font-bold text-xs text-gray-400 uppercase tracking-widest pl-2 mb-1">
            വിഭാഗങ്ങൾ (Categories)
          </p>
          <div className="grid grid-cols-2 gap-2">
            {(categories && categories.length > 0 ? categories : CATEGORIES_WITH_ICONS.map(c => c.name)).map((catName) => (
              <button
                key={catName}
                onClick={() => {
                  onSelectCategory(catName);
                  setMobileMenuOpen(false);
                }}
                className={`flex items-center space-x-2 p-2 rounded-lg text-xs font-bold leading-normal text-left ${
                  currentCategory === catName
                    ? "bg-brand-red text-white"
                    : "bg-gray-50 hover:bg-brand-light text-gray-700 hover:text-brand-red"
                }`}
              >
                {getCategoryIcon(catName)}
                <span>{catName}</span>
              </button>
            ))}
          </div>
          {/* User Account Controls on Mobile Drawer */}
          <div className="pt-3 border-t border-gray-100 flex flex-col gap-2">
            {currentUser ? (
              <div className="flex items-center justify-between p-2.5 bg-gray-50 border border-gray-105 rounded-xl">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-brand-red text-white flex items-center justify-center font-bold text-sm uppercase">
                    {currentUser.displayName ? currentUser.displayName.charAt(0) : currentUser.email.charAt(0)}
                  </div>
                  <div className="flex flex-col text-left">
                    <span className="text-xs text-gray-900 font-black truncate max-w-[130px]">
                      {currentUser.displayName || currentUser.email.split("@")[0]}
                    </span>
                    <span className="text-[10px] text-gray-400 font-bold leading-none mt-0.5">
                      വരിക്കാരൻ ✓
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => {
                    if (onLogoutUser) onLogoutUser();
                    setMobileMenuOpen(false);
                  }}
                  className="text-xs bg-red-50 text-brand-red border border-red-100 rounded-lg px-2.5 py-1 font-bold cursor-pointer hover:bg-red-100"
                >
                  ലോഗൗട്ട്
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  if (onOpenAuth) onOpenAuth();
                  setMobileMenuOpen(false);
                }}
                className="w-full border border-brand-red hover:bg-brand-red hover:text-white text-brand-red text-center py-2.5 rounded-lg text-xs font-extrabold transition-all cursor-pointer"
              >
                അക്കൗണ്ട് ലോഗിൻ / രജിസ്റ്റർ
              </button>
            )}

            {/* Admin Buttons for Mobile Drawer */}
            {isAdmin ? (
              <div className="flex items-center justify-between w-full gap-2 mt-1">
                <button
                  onClick={() => {
                    onOpenAdmin();
                    setMobileMenuOpen(false);
                  }}
                  className="bg-emerald-600 text-white px-3 py-2 text-xs rounded-lg font-bold hover:bg-emerald-700 flex-grow text-center cursor-pointer"
                >
                  അഡ്മിൻ ഡാഷ്‌ബോർഡ്
                </button>
                <button
                  onClick={() => {
                    onLogout();
                    setMobileMenuOpen(false);
                  }}
                  className="bg-gray-100 text-gray-800 px-3 py-2 text-xs rounded-lg font-bold hover:bg-gray-200 cursor-pointer"
                >
                  അഡ്മിൻ ലോഗൗട്ട്
                </button>
              </div>
            ) : (
              <button
                onClick={() => {
                  onOpenAdmin();
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-brand-red hover:bg-brand-dark text-white text-center py-2.5 rounded-lg text-xs font-bold transition-all shadow-sm cursor-pointer"
              >
                തത്സമയം അഡ്മിൻ ലോഗിൻ
              </button>
            )}
          </div>
        </div>
      )}
    </header>
  );
}
