import React, { useState, useEffect } from "react";
import { Lock, FileText, BarChart3, Upload, PlusCircle, Trash2, Eye, FileSymlink, LogOut, CheckCircle, HelpCircle, Megaphone, Globe, Link, Pencil } from "lucide-react";
import { NewsArticle, NewsCategory, AdBannerType, BreakingNews } from "../types";

interface AdminDashboardProps {
  articles: NewsArticle[];
  onUpload: (newArticle: Partial<NewsArticle> & { imageBase64?: string }) => Promise<void>;
  onDelete: (id: string) => Promise<void>;
  onClose: () => void;
  isAdmin: boolean;
  onLogin: (token: string) => void;
  // Advertisements management
  ads: AdBannerType[];
  onUploadAd: (newAd: Partial<AdBannerType> & { imageBase64?: string }) => Promise<void>;
  onDeleteAd: (id: string) => Promise<void>;
  // NEW callbacks
  onUpdate?: (id: string, updatedArticle: Partial<NewsArticle> & { imageBase64?: string }) => Promise<void>;
  onUpdateAd?: (id: string, updatedAd: Partial<AdBannerType> & { imageBase64?: string }) => Promise<void>;
  // Breaking News management
  breakingNews?: BreakingNews[];
  onAddBreaking?: (text: string) => Promise<void>;
  onUpdateBreaking?: (id: string, text: string) => Promise<void>;
  onDeleteBreaking?: (id: string) => Promise<void>;
  // Categories management
  categories?: string[];
  onUpdateCategories?: (cats: string[]) => Promise<void>;
  initialTab?: "news" | "ads" | "categories";
}

export default function AdminDashboard({
  articles,
  onUpload,
  onDelete,
  onClose,
  isAdmin,
  onLogin,
  ads,
  onUploadAd,
  onDeleteAd,
  onUpdate,
  onUpdateAd,
  breakingNews = [],
  onAddBreaking,
  onUpdateBreaking,
  onDeleteBreaking,
  categories = ["എല്ലാം", "കേരളം", "പ്രാദേശികം", "രാഷ്ട്രീയം", "കായികം", "വിനോദം", "പ്രവാസം"],
  onUpdateCategories,
  initialTab = "news",
}: AdminDashboardProps) {
  // Navigation tabs
  const [adminTab, setAdminTab] = useState<"news" | "ads" | "categories">(initialTab);

  useEffect(() => {
    if (initialTab) {
      setAdminTab(initialTab);
    }
  }, [initialTab]);

  // Login states
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [authError, setAuthError] = useState("");
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  // Form states for creating news
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [content, setContent] = useState("");
  const [category, setCategory] = useState<string>("പ്രാദേശികം");
  const [customCategory, setCustomCategory] = useState("");
  const [author, setAuthor] = useState("");
  const [thumbnailUrl, setThumbnailUrl] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [imageBase64, setImageBase64] = useState("");
  const [imageName, setImageName] = useState("");

  const [formError, setFormError] = useState("");
  const [formSuccess, setFormSuccess] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [adminNewsFilter, setAdminNewsFilter] = useState("all");

  // Form states for managing advertisements
  const [adTitle, setAdTitle] = useState("");
  const [adSubtitle, setAdSubtitle] = useState("");
  const [adSponsor, setAdSponsor] = useState("");
  const [adLink, setAdLink] = useState("");
  const [adImageUrl, setAdImageUrl] = useState("");
  const [adImageBase64, setAdImageBase64] = useState("");
  const [adImageName, setAdImageName] = useState("");
  const [adSlot, setAdSlot] = useState<"top" | "middle" | "sidebar">("top");
  const [adCategory, setAdCategory] = useState<string>("All");

  const [adFormError, setAdFormError] = useState("");
  const [adFormSuccess, setAdFormSuccess] = useState(false);
  const [isUploadingAd, setIsUploadingAd] = useState(false);

  // Editing state trackers
  const [editingArticleId, setEditingArticleId] = useState<string | null>(null);
  const [editingAdId, setEditingAdId] = useState<string | null>(null);

  // Delete confirmation trackers
  const [deleteConfirmArticleId, setDeleteConfirmArticleId] = useState<string | null>(null);
  const [deleteConfirmAdId, setDeleteConfirmAdId] = useState<string | null>(null);

  // Breaking News form and management states
  const [breakingText, setBreakingText] = useState("");
  const [editingBreakingId, setEditingBreakingId] = useState<string | null>(null);
  const [breakingFormError, setBreakingFormError] = useState("");
  const [breakingFormSuccess, setBreakingFormSuccess] = useState(false);
  const [isUploadingBreaking, setIsUploadingBreaking] = useState(false);
  const [deleteConfirmBreakingId, setDeleteConfirmBreakingId] = useState<string | null>(null);

  // Categories management states
  const [categoryInputName, setCategoryInputName] = useState("");
  const [editingCategoryName, setEditingCategoryName] = useState<string | null>(null);
  const [categoryFormError, setCategoryFormError] = useState("");
  const [categoryFormSuccess, setCategoryFormSuccess] = useState(false);

  // Statistics
  const totalViews = articles.reduce((sum, a) => sum + (a.views || 0), 0);
  const totalLikes = articles.reduce((sum, a) => sum + (a.likes || 0), 0);
  const totalComments = articles.reduce((sum, a) => sum + (a.comments?.length || 0), 0);

  // Handle Login click
  const handleAuthSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setIsLoggingIn(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onLogin(data.token);
      } else {
        setAuthError(data.error || "അധികാരമില്ലാത്ത ലോഗിൻ വിവരങ്ങൾ!");
      }
    } catch {
      setAuthError("കണക്ഷൻ തകരാറിലായി. വീണ്ടും ശ്രമിക്കുക.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Instant quick admin login for convenience
  const handleQuickLogin = async () => {
    setAuthError("");
    setIsLoggingIn(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username: "tnclive", password: "Mejo@2255#" }),
      });

      const data = await res.json();
      if (res.ok && data.success) {
        onLogin(data.token);
      } else {
        setAuthError(data.error || "അധികാരമില്ലാത്ത ലോഗിൻ വിവരങ്ങൾ!");
      }
    } catch {
      setAuthError("കണക്ഷൻ തകരാറിലായി. വീണ്ടും ശ്രമിക്കുക.");
    } finally {
      setIsLoggingIn(false);
    }
  };

  // Convert uploaded image file to base64
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setFormError("ചിത്രത്തിന്റെ വലുപ്പം 5MB-യിൽ കൂടരുത്!");
      return;
    }

    setImageName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => {
      setImageBase64(reader.result as string);
      setThumbnailUrl(""); // Prioritize base64 file upload over random string URLs
    };
    reader.readAsDataURL(file);
  };

  // Start editing article
  const handleStartEditArticle = (art: NewsArticle) => {
    setEditingArticleId(art.id);
    setTitle(art.title);
    setDescription(art.description);
    setContent(art.content);
    
    const categoryList = categories.filter(c => c !== "എല്ലാം");
    if (categoryList.includes(art.category)) {
      setCategory(art.category);
      setCustomCategory("");
    } else {
      setCategory("മറ്റുള്ളവ");
      setCustomCategory(art.category);
    }

    setAuthor(art.author || "");
    setThumbnailUrl(art.thumbnail || "");
    setVideoUrl(art.videoUrl || "");
    setImageBase64("");
    setImageName("");
    setFormError("");
    setFormSuccess(false);
  };

  // Cancel editing article
  const handleCancelEditArticle = () => {
    setEditingArticleId(null);
    setTitle("");
    setDescription("");
    setContent("");
    setCategory("പ്രാദേശികം");
    setCustomCategory("");
    setAuthor("");
    setThumbnailUrl("");
    setVideoUrl("");
    setImageBase64("");
    setImageName("");
    setFormError("");
  };

  // Start editing advertisement
  const handleStartEditAd = (ad: AdBannerType) => {
    setEditingAdId(ad.id);
    setAdTitle(ad.title);
    setAdSubtitle(ad.subtitle || "");
    setAdSponsor(ad.sponsor);
    setAdLink(ad.link === "#" ? "" : ad.link);
    setAdImageUrl(ad.imageUrl || "");
    setAdImageBase64("");
    setAdImageName("");
    setAdSlot(ad.slot || "top");
    setAdCategory(ad.category || "All");
    setAdFormError("");
    setAdFormSuccess(false);
  };

  // Cancel editing advertisement
  const handleCancelEditAd = () => {
    setEditingAdId(null);
    setAdTitle("");
    setAdSubtitle("");
    setAdSponsor("");
    setAdLink("");
    setAdImageUrl("");
    setAdImageBase64("");
    setAdImageName("");
    setAdSlot("top");
    setAdCategory("All");
    setAdFormError("");
  };

  // Start editing breaking news
  const handleStartEditBreaking = (item: BreakingNews) => {
    setEditingBreakingId(item.id);
    setBreakingText(item.text);
    setBreakingFormError("");
    setBreakingFormSuccess(false);
  };

  // Cancel editing breaking news
  const handleCancelEditBreaking = () => {
    setEditingBreakingId(null);
    setBreakingText("");
    setBreakingFormError("");
    setBreakingFormSuccess(false);
  };

  // Submit breaking news
  const handleBreakingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBreakingFormError("");
    setBreakingFormSuccess(false);

    if (!breakingText.trim()) {
      setBreakingFormError("ബ്രേക്കിംഗ് ന്യൂസ് വിവരങ്ങൾ നിർബന്ധമാണ്!");
      return;
    }

    setIsUploadingBreaking(true);
    try {
      if (editingBreakingId) {
        if (onUpdateBreaking) {
          await onUpdateBreaking(editingBreakingId, breakingText.trim());
        }
        setEditingBreakingId(null);
      } else {
        if (onAddBreaking) {
          await onAddBreaking(breakingText.trim());
        }
      }
      setBreakingText("");
      setBreakingFormSuccess(true);
    } catch (err: any) {
      setBreakingFormError("ബ്രേക്കിംഗ് ന്യൂസ് അപ്‌ലോഡ് ചെയ്യുന്നതിൽ പരാജയം.");
    } finally {
      setIsUploadingBreaking(false);
    }
  };

  // Category Submit
  const handleCategorySubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setCategoryFormError("");
    setCategoryFormSuccess(false);

    if (!categoryInputName.trim()) {
      setCategoryFormError("വിഭാഗത്തിന്റെ പേര് നൽകുക (Category name is required).");
      return;
    }

    try {
      const val = categoryInputName.trim();
      let updatedCategories = [...categories];

      if (editingCategoryName) {
        // Find existing to rename
        const oldIndex = updatedCategories.indexOf(editingCategoryName);
        if (oldIndex > -1) {
          updatedCategories[oldIndex] = val;
        }
      } else {
        if (updatedCategories.includes(val)) {
          setCategoryFormError("ഈ വിഭാഗം മുൻപ് ചേർത്തിട്ടുണ്ട് (Category already exists).");
          return;
        }
        updatedCategories.push(val);
      }

      if (onUpdateCategories) {
        await onUpdateCategories(updatedCategories);
      }

      setCategoryInputName("");
      setEditingCategoryName(null);
      setCategoryFormSuccess(true);
      setTimeout(() => setCategoryFormSuccess(false), 3000);
    } catch {
      setCategoryFormError("Failed to save category.");
    }
  };

  // Delete Category
  const handleDeleteCategory = async (name: string) => {
    if (name === "എല്ലാം") return; // Keep "All"
    try {
      let updatedCategories = categories.filter((c) => c !== name);
      if (onUpdateCategories) {
        await onUpdateCategories(updatedCategories);
      }
    } catch {
      alert("Failed to delete category.");
    }
  };

  // Submit article
  const handleArticleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError("");
    setFormSuccess(false);

    if (!title.trim() || !description.trim() || !content.trim()) {
      setFormError("വാർത്തയുടെ തലക്കെട്ട്, വിവരണം, ഉള്ളടക്കം എന്നിവ നിർബന്ധമാണ്!");
      return;
    }

    const finalCategory = category === "മറ്റുള്ളവ" ? customCategory.trim() : category;
    if (!finalCategory) {
      setFormError("വാർത്തയുടെ വിഭാഗം (Category) തെരഞ്ഞെടുക്കുകയോ അല്ലെങ്കിൽ പുതിയ വിഭാഗം എഴുതി ചേർക്കുകയോ ചെയ്യുക!");
      return;
    }

    setIsUploading(true);
    try {
      if (editingArticleId) {
        if (onUpdate) {
          await onUpdate(editingArticleId, {
            title,
            description,
            content,
            category: finalCategory,
            author: author.trim() || "TNC ചീഫ് എഡിറ്റർ",
            thumbnail: thumbnailUrl.trim() || undefined,
            videoUrl: videoUrl.trim() || undefined,
            imageBase64: imageBase64 || undefined,
          });
        }
        setEditingArticleId(null);
      } else {
        await onUpload({
          title,
          description,
          content,
          category: finalCategory,
          author: author.trim() || "TNC ചീഫ് എഡിറ്റർ",
          thumbnail: thumbnailUrl.trim() || undefined,
          videoUrl: videoUrl.trim() || undefined,
          imageBase64: imageBase64 || undefined,
        });
      }

      // Clear states
      setTitle("");
      setDescription("");
      setContent("");
      setCategory("പ്രാദേശികം");
      setCustomCategory("");
      setAuthor("");
      setThumbnailUrl("");
      setVideoUrl("");
      setImageBase64("");
      setImageName("");
      setFormSuccess(true);
      setTimeout(() => setFormSuccess(false), 5000);
    } catch {
      setFormError(editingArticleId ? "വാർത്ത പുതുക്കാൻ സാധിച്ചില്ല. ദയവായി പരിശോധിക്കുക." : "വാർത്ത അപ്‌ലോഡ് ചെയ്യാൻ സാധിച്ചില്ല. ദയവായി പരിശോധിക്കുക.");
    } finally {
      setIsUploading(false);
    }
  };

  // Convert uploaded ad image file to base64
  const handleAdFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      setAdFormError("ചിത്രത്തിന്റെ വലുപ്പം 5MB-യിൽ കൂടരുത്!");
      return;
    }

    setAdImageName(file.name);
    const reader = new FileReader();
    reader.onloadend = () => {
      setAdImageBase64(reader.result as string);
      setAdImageUrl(""); // Reset url text if local file uploaded
    };
    reader.readAsDataURL(file);
  };

  // Submit advertisement
  const handleAdSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setAdFormError("");
    setAdFormSuccess(false);

    if (!adTitle.trim() || !adSponsor.trim()) {
      setAdFormError("പരസ്യത്തിന്റെ തലക്കെട്ടും സ്പോൺസറും നിർബന്ധമാണ്!");
      return;
    }

    setIsUploadingAd(true);
    try {
      if (editingAdId) {
        if (onUpdateAd) {
          await onUpdateAd(editingAdId, {
            title: adTitle.trim(),
            subtitle: adSubtitle.trim() || undefined,
            sponsor: adSponsor.trim(),
            link: adLink.trim() || "#",
            imageUrl: adImageUrl.trim() || undefined,
            imageBase64: adImageBase64 || undefined,
            slot: adSlot,
            category: adCategory,
          });
        }
        setEditingAdId(null);
      } else {
        await onUploadAd({
          title: adTitle.trim(),
          subtitle: adSubtitle.trim() || undefined,
          sponsor: adSponsor.trim(),
          link: adLink.trim() || "#",
          imageUrl: adImageUrl.trim() || undefined,
          imageBase64: adImageBase64 || undefined,
          slot: adSlot,
          category: adCategory,
        });
      }

      // Clear states
      setAdTitle("");
      setAdSubtitle("");
      setAdSponsor("");
      setAdLink("");
      setAdImageUrl("");
      setAdImageBase64("");
      setAdImageName("");
      setAdSlot("top");
      setAdCategory("All");
      setAdFormSuccess(true);
      setTimeout(() => setAdFormSuccess(false), 5000);
    } catch {
      setAdFormError(editingAdId ? "പരസ്യം പുതുക്കുന്നതിൽ പരാജയപ്പെട്ടു!" : "പരസ്യം ചേർക്കുന്നതിൽ പരാജയപ്പെട്ടു!");
    } finally {
      setIsUploadingAd(false);
    }
  };

  if (!isAdmin) {
    return (
      <div className="max-w-md mx-auto my-16 bg-white border border-gray-150 rounded-3xl p-8 text-center shadow-lg">
        <div className="bg-red-50 text-brand-red w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-4">
          <Lock className="w-7 h-7" />
        </div>
        <h2 className="text-xl font-black text-gray-900 mb-1 font-display">അഡ്മിൻ പ്രവേശനം (Login)</h2>
        <p className="text-xs text-gray-500 mb-6 font-bold">ദയവായി നിങ്ങളുടെ വിവരങ്ങൾ താഴെ പൂരിപ്പിക്കുക</p>

        {authError && (
          <div className="bg-red-50 text-brand-red border border-red-100 p-3 rounded-xl text-xs mb-4 font-bold">
            {authError}
          </div>
        )}

        <form onSubmit={handleAuthSubmit} className="space-y-4">
          <div className="text-left">
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">USERNAME</label>
            <input
              type="text"
              required
              placeholder="Username ടൈപ്പ് ചെയ്യുക (tnclive)"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
            />
          </div>

          <div className="text-left">
            <label className="block text-[11px] font-bold text-gray-500 mb-1 pl-1">PASSWORD</label>
            <input
              type="password"
              required
              placeholder="Password ടൈപ്പ് ചെയ്യുക"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
            />
          </div>

          <button
            type="submit"
            disabled={isLoggingIn}
            className="w-full bg-brand-red text-white font-bold py-3 rounded-xl text-sm hover:bg-brand-dark transition-colors flex items-center justify-center space-x-2 shadow-sm cursor-pointer"
          >
            {isLoggingIn ? "സ്ഥിരീകരിക്കുന്നു..." : "ലോഗിൻ ചെയ്യുക"}
          </button>
        </form>

        <div className="relative my-6 select-none">
          <div className="absolute inset-0 flex items-center">
            <div className="w-full border-t border-gray-150"></div>
          </div>
          <div className="relative flex justify-center text-xs uppercase">
            <span className="bg-white px-3 text-[10px] text-gray-400 font-black">അല്ലെങ്കിൽ (OR)</span>
          </div>
        </div>

        <button
          onClick={handleQuickLogin}
          disabled={isLoggingIn}
          className="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-bold py-3 rounded-xl text-sm transition-all duration-300 flex items-center justify-center space-x-2 shadow hover:shadow-md cursor-pointer transform hover:scale-[1.01] active:scale-[0.99]"
        >
          <span>✨ ഒറ്റ ക്ലിക്കിൽ പ്രവേശിക്കുക (One-Click Auto-Login)</span>
        </button>

        <p className="mt-6 text-[11px] text-gray-500 font-bold leading-relaxed bg-brand-light p-3.5 rounded-2xl border border-red-100/70 text-left select-none">
          💡 <span className="text-brand-red">ശ്രദ്ധിക്കുക:</span> മുകളിലെ ഫോമിൽ യൂസർനെയിമായി <code className="bg-white px-1.5 py-0.5 border border-red-250 rounded text-brand-dark">tnclive</code> എന്നും പാസ്‌വേഡായി <code className="bg-white px-1.5 py-0.5 border border-red-250 rounded text-brand-dark">Mejo@2255#</code> എന്നും നൽകി ലോഗിൻ ചെയ്യാം. അല്ലെങ്കിൽ അതിനേക്കാൾ എളുപ്പത്തിൽ പച്ച നിറത്തിലുള്ള <strong className="text-emerald-700">ഒറ്റ ക്ലിക്കിൽ പ്രവേശിക്കുക</strong> എന്ന ബട്ടൺ അമർത്തി ഉടൻ തന്നെ അഡ്മിൻ പാനലിൽ കടക്കാവുന്നതാണ്!
        </p>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Dashboard Top Header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8 border-b border-gray-100 pb-6">
        <div>
          <h2 className="text-2xl font-black text-gray-950 font-display">TNC അഡ്മിനിസ്ട്രേറ്റീവ് നിയന്ത്രണം (Content Hub)</h2>
          <p className="text-xs text-gray-500 font-bold tracking-wider mt-1">
            വാർത്തകൾ അപ്‌ലോഡ് ചെയ്യാനും നിലവിലുള്ള വിവരങ്ങൾ നീക്കം ചെയ്യാനും താഴെ പറയുന്നവ ഉപയോഗിക്കുക.
          </p>
        </div>
        <button
          onClick={onClose}
          className="bg-gray-100 hover:bg-red-50 hover:text-red-700 text-gray-800 font-bold px-5 py-2 rounded-xl text-xs transition-colors flex items-center space-x-1 border border-transparent hover:border-red-100 cursor-pointer"
        >
          <span>പ്രധാന വിൻഡോയിലേക്ക്</span>
        </button>
      </div>

      {/* Analytics Counter Widgets */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-10">
        <div className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
          <div className="bg-blue-50 text-blue-600 p-3 rounded-xl">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase">ആകെ വാർത്തകൾ</p>
            <p className="text-xl font-black text-gray-900">{articles.length}</p>
          </div>
        </div>
        <div className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
          <div className="bg-rose-50 text-rose-600 p-3 rounded-xl">
            <Eye className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase">ആകെ വായനക്കാർ (Views)</p>
            <p className="text-xl font-black text-gray-900">{totalViews}</p>
          </div>
        </div>
        <div className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
          <div className="bg-amber-50 text-amber-600 p-3 rounded-xl">
            <Megaphone className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase">നിലവിലെ പരസ്യങ്ങൾ</p>
            <p className="text-xl font-black text-gray-900">{ads.length}</p>
          </div>
        </div>
        <div className="bg-white border border-gray-100 rounded-2xl p-4 flex items-center space-x-4 shadow-sm">
          <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl">
            <CheckCircle className="w-6 h-6" />
          </div>
          <div>
            <p className="text-[10px] text-gray-400 font-bold uppercase">ആകെ ലൈക്കുകൾ</p>
            <p className="text-xl font-black text-gray-900">{totalLikes}</p>
          </div>
        </div>
      </div>
      <div className="flex border-b border-gray-150 mb-8 font-sans select-none overflow-x-auto scrollbar-none">
        <button
          onClick={() => setAdminTab("news")}
          className={`px-5 py-3 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            adminTab === "news"
              ? "border-brand-red text-brand-red font-black"
              : "border-transparent text-gray-400 hover:text-gray-600"
          }`}
        >
          📰 വാർത്തകൾ നിയന്ത്രിക്കുക (Manage News)
        </button>
        <button
          onClick={() => setAdminTab("ads")}
          className={`px-5 py-3 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            adminTab === "ads"
              ? "border-brand-red text-brand-red font-black"
              : "border-transparent text-gray-400 hover:text-gray-600"
          }`}
        >
          📢 പരസ്യങ്ങൾ നിയന്ത്രിക്കുക (Manage Ads)
        </button>
        <button
          onClick={() => setAdminTab("categories")}
          className={`px-5 py-3 font-extrabold text-xs md:text-sm border-b-2 transition-all cursor-pointer whitespace-nowrap ${
            adminTab === "categories"
              ? "border-brand-red text-brand-red font-black"
              : "border-transparent text-gray-400 hover:text-gray-600"
          }`}
        >
          🏷️ വിഭാഗങ്ങൾ നിയന്ത്രിക്കുക (Manage Categories)
        </button>
      </div>

      {adminTab === "news" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          {/* Left column: Add/Upload News Form (7 Cols) */}
          <div className="lg:col-span-7 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center space-x-2 border-b border-gray-50 pb-4 mb-6 select-none">
              {editingArticleId ? (
                <Pencil className="w-5 h-5 text-emerald-600 animate-pulse" />
              ) : (
                <PlusCircle className="w-5 h-5 text-brand-red" />
              )}
              <h3 className="text-lg font-bold text-gray-900">
                {editingArticleId ? "വാർത്ത എഡിറ്റ് ചെയ്യുക (Edit News)" : "പുതിയ വാർത്ത സമർപ്പിക്കുക (Publish News)"}
              </h3>
            </div>

            {formError && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs font-bold p-3.5 rounded-xl mb-4 text-left">
                {formError}
              </div>
            )}

            {formSuccess && (
              <div className="bg-emerald-50 border border-emerald-250 text-emerald-700 text-xs font-bold p-3.5 rounded-xl mb-4 flex items-center space-x-2 text-left">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>വാർത്ത വിജയകരമായി അപ്‌ലോഡ് ചെയ്തു! തത്സമയം ഹോംപേജിൽ ദൃശ്യമാകും.</span>
              </div>
            )}

            <form onSubmit={handleArticleSubmit} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  വാർത്താ തലക്കെട്ട് മലയാളത്തിൽ (Malayalam Title)*
                </label>
                <input
                  type="text"
                  required
                  placeholder="ആകർഷകമായ വാർത്താ തലക്കെട്ട് ഇവിടെ ടൈപ്പ് ചെയ്യുക..."
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    വിഭാഗം (Category / Brand Section)*
                  </label>
                  <div className="space-y-2">
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white cursor-pointer font-medium"
                    >
                      {categories.filter(c => c !== "എല്ലാം").map(catName => (
                        <option key={catName} value={catName}>{catName}</option>
                      ))}
                      <option value="മറ്റുള്ളവ">മറ്റുള്ളവ (Custom Section / Category)...</option>
                    </select>

                    {category === "മറ്റുള്ളവ" && (
                      <input
                        type="text"
                        required
                        placeholder="പുതിയ വിഭാഗത്തിന്റെ/സെക്ഷന്റെ പേര് ടൈപ്പ് ചെയ്യുക..."
                        value={customCategory}
                        onChange={(e) => setCustomCategory(e.target.value)}
                        className="w-full px-4 py-2.5 bg-emerald-50/30 border border-emerald-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:bg-white animate-fade-in placeholder-emerald-600/50 text-emerald-900 font-semibold"
                      />
                    )}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    ലേഖകൻ/റിപ്പോർട്ടർ പേര് (Reporter Name)
                  </label>
                  <input
                    type="text"
                    placeholder="ലേഖകന്റെ പേര് (ഉദാഹരണത്തിന്: സക്കറിയ കോഴിക്കോട്)"
                    value={author}
                    onChange={(e) => setAuthor(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  ഹ്രസ്വ വിവരണം (Short Malayalam Description)*
                </label>
                <textarea
                  required
                  rows={2}
                  placeholder="ഹോംപേജിലെ കാർഡുകളിൽ കാണിക്കുന്ന വിവരണം എഴുതുക..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white resize-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  വാർത്താ ഉള്ളടക്കം മലയാളത്തിൽ (Full News Content)*
                </label>
                <textarea
                  required
                  rows={6}
                  placeholder="വാർത്തയുടെ പൂർണ്ണ വായനാ ഉള്ളടക്കം വരികൾ വിട്ട് വ്യക്തമായി ടൈപ്പ് ചെയ്യുക..."
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                />
              </div>

              {/* Image Upload system */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-150 space-y-3">
                <span className="block text-xs font-black text-gray-600 select-none">
                  വാർത്താ ചിത്രം ചേർക്കുക (Thumbnail Link or File Upload)
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* File picker */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">
                      ഫയൽ അപ്‌ലോഡ് ചെയ്യുക (Limit 5MB)
                    </label>
                    <label className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-xl px-4 py-2.5 bg-white cursor-pointer hover:border-brand-red transition-all text-center">
                      <Upload className="w-5 h-5 text-gray-400 mb-1" />
                      <span className="text-[10px] font-bold text-gray-500 truncate max-w-[150px]">
                        {imageName || "ഫയൽ തിരഞ്ഞെടുക്കൂ"}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Direct image link */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">
                      അല്ലെങ്കിൽ ഓൺലൈൻ ഇമേജ് ലിങ്ക്
                    </label>
                    <input
                      type="url"
                      placeholder="https://images.unsplash.com/..."
                      value={thumbnailUrl}
                      onChange={(e) => {
                        setThumbnailUrl(e.target.value);
                        setImageBase64(""); // Prioritize input link if updated
                        setImageName("");
                      }}
                      className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-brand-red"
                    />
                  </div>
                </div>

                {imageBase64 && (
                  <div className="flex items-center space-x-2 text-emerald-700 bg-white p-2 rounded border border-emerald-100 mt-2">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                    <span className="text-[10px] font-bold">പ്രാദേശിക ചിത്രം അപ്‌ലോഡ് ചെയ്യാൻ തയാറാണ്</span>
                  </div>
                )}
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  യൂട്യൂബ് വീഡിയോ ലിങ്ക് (YouTube Video Url - Optional)
                </label>
                <div className="relative flex items-center">
                  <FileSymlink className="absolute left-3 w-4 h-4 text-gray-400" />
                  <input
                    type="text"
                    placeholder="ഉദാഹരണത്തിന്: https://www.youtube.com/watch?v=dQw4w9WgXcQ"
                    value={videoUrl}
                    onChange={(e) => setVideoUrl(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                  />
                </div>
                <p className="text-[10px] text-gray-400 font-semibold mt-1">
                  സാധാരണ യൂട്യൂബ് ഷെയർ ലിങ്കുകളും നേരിട്ട് നൽകാം (Auto-converted to embed player)
                </p>
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={isUploading}
                  className={`flex-grow font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer text-white ${
                    editingArticleId
                      ? "bg-emerald-600 hover:bg-emerald-700"
                      : "bg-brand-red hover:bg-brand-dark"
                  }`}
                >
                  <span>
                    {isUploading
                      ? "സംരക്ഷിക്കുന്നു..."
                      : editingArticleId
                      ? "മാറ്റങ്ങൾ സംരക്ഷിക്കുക (Save Changes)"
                      : "വാർത്ത പബ്ലിഷ് ചെയ്യുക"}
                  </span>
                </button>

                {editingArticleId && (
                  <button
                    type="button"
                    onClick={handleCancelEditArticle}
                    className="px-4 py-3.5 bg-gray-150 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    റദ്ദാക്കുക (Cancel)
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Right column: Manage existing articles (5 Cols) */}
          <div className="lg:col-span-12 xl:col-span-5 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm flex flex-col h-full">
            <div className="border-b border-gray-50 pb-4 mb-6 text-left flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
              <h3 className="text-lg font-bold text-gray-900">നിലവിലുള്ള വാർത്തകൾ നിയന്ത്രിക്കുക (Manage Articles)</h3>
              <select
                value={adminNewsFilter}
                onChange={(e) => setAdminNewsFilter(e.target.value)}
                className="px-3 py-1.5 bg-gray-50 border border-gray-200 rounded-lg text-xs font-bold focus:outline-none focus:ring-2 focus:ring-brand-red cursor-pointer"
              >
                <option value="all">എല്ലാ വിഭാഗവും (All)</option>
                {categories.filter(c => c !== "എല്ലാം").map(catName => (
                  <option key={catName} value={catName}>{catName}</option>
                ))}
                <option value="others">മറ്റുള്ളവ (Custom Sections)</option>
              </select>
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[600px] flex-grow pr-1">
              {(() => {
                const filtered = articles.filter((art) => {
                  if (adminNewsFilter === "all") return true;
                  if (adminNewsFilter === "others") {
                    const categoryList = categories.filter(c => c !== "എല്ലാം");
                    return !categoryList.includes(art.category);
                  }
                  return art.category === adminNewsFilter;
                });

                if (filtered.length === 0) {
                  return (
                    <p className="text-sm text-gray-400 font-bold py-8 text-center bg-gray-50 rounded-2xl">
                      ഈ വിഭാഗത്തിൽ നിലവിൽ വാർത്തകൾ ഒന്നും തന്നെയില്ല.
                    </p>
                  );
                }

                return filtered.map((article) => (
                  <div
                    key={article.id}
                    className="flex items-center justify-between p-3 border border-gray-100 rounded-2xl hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-3 overflow-hidden text-left">
                      <img
                        src={article.thumbnail}
                        alt={article.title}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 object-cover rounded-lg bg-gray-100 shrink-0"
                      />
                      <div className="overflow-hidden">
                        <h4 className="font-bold text-xs text-gray-950 truncate pr-2 max-w-[200px]">
                          {article.title}
                        </h4>
                        <p className="text-[10px] text-gray-400 font-bold mt-0.5">
                          {article.category} • {article.views} views • {article.comments?.length || 0} comments
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1">
                      {deleteConfirmArticleId === article.id ? (
                        <div className="flex items-center space-x-1 animate-fade-in">
                          <button
                            onClick={async () => {
                              try {
                                await onDelete(article.id);
                              } catch (e) {
                                console.error(e);
                              } finally {
                                setDeleteConfirmArticleId(null);
                              }
                            }}
                            className="bg-red-600 hover:bg-red-700 text-white font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                          >
                            ഡിലീറ്റ് (Confirm)
                          </button>
                          <button
                            onClick={() => setDeleteConfirmArticleId(null)}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                          >
                            റദ്ദാക്കുക
                          </button>
                        </div>
                      ) : (
                        <>
                          <button
                            onClick={() => handleStartEditArticle(article)}
                            className={`p-2 rounded-xl transition-all border text-xs cursor-pointer ${
                              editingArticleId === article.id
                                ? "bg-emerald-50 text-emerald-700 border-emerald-250"
                                : "text-gray-450 hover:text-emerald-700 bg-gray-50 hover:bg-emerald-50 border-gray-100 hover:border-emerald-100"
                            }`}
                            title="വാർത്ത എഡിറ്റ് ചെയ്യുക"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmArticleId(article.id)}
                            className="p-2 text-gray-400 hover:text-red-700 bg-gray-50 hover:bg-red-50 rounded-xl transition-all border border-gray-100 hover:border-red-100 cursor-pointer"
                            title="വാർത്ത നീക്കം ചെയ്യുക"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ));
              })()}
            </div>
          </div>
        </div>
      ) : adminTab === "ads" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fade-in">
          {/* Left column: Add/Upload Ads Form (7 Cols) */}
          <div className="lg:col-span-7 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm">
            <div className="flex items-center space-x-2 border-b border-gray-50 pb-4 mb-6 select-none">
              {editingAdId ? (
                <Pencil className="w-5 h-5 text-emerald-600 animate-pulse" />
              ) : (
                <Megaphone className="w-5 h-5 text-brand-red" />
              )}
              <h3 className="text-lg font-bold text-gray-900">
                {editingAdId ? "പരസ്യം എഡിറ്റ് ചെയ്യുക (Edit Ad)" : "പുതിയ പരസ്യം ചേർക്കുക (Add Advertisement)"}
              </h3>
            </div>

            {adFormError && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs font-bold p-3.5 rounded-xl mb-4 text-left">
                {adFormError}
              </div>
            )}

            {adFormSuccess && (
              <div className="bg-emerald-50 border border-emerald-250 text-emerald-700 text-xs font-bold p-3.5 rounded-xl mb-4 flex items-center space-x-2 text-left">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>പരസ്യം വിജയകരമായി അപ്‌ലോഡ് ചെയ്തു! തത്സമയം വെബ്‌സൈറ്റിൽ ദൃശ്യമാകും.</span>
              </div>
            )}

            <form onSubmit={handleAdSubmit} className="space-y-4 text-left">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  പരസ്യത്തിന്റെ തലക്കെട്ട് (Ad Title)*
                </label>
                <input
                  type="text"
                  required
                  placeholder="പരസ്യത്തിന്റെ തലക്കെട്ട് ഇവിടെ ടൈപ്പ് ചെയ്യുക..."
                  value={adTitle}
                  onChange={(e) => setAdTitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  ഉപതലക്കെട്ട് (Ad Subtitle)
                </label>
                <input
                  type="text"
                  placeholder="പരസ്യ ഉപതലക്കെട്ട് (ഉദാ: പ്രത്യേക ഓഫറുകൾ ലഭിക്കുന്നു...)"
                  value={adSubtitle}
                  onChange={(e) => setAdSubtitle(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    സ്പോൺസർ പേര് (Sponsor Name)*
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="സ്പോൺസറുടെ പേര് (ഉദാ: ഹോം സ്റ്റൈൽ)"
                    value={adSponsor}
                    onChange={(e) => setAdSponsor(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    ലിങ്ക് (Target Link - Optional)
                  </label>
                  <input
                    type="text"
                    placeholder="https://example.com"
                    value={adLink}
                    onChange={(e) => setAdLink(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    പരസ്യ സ്ലോട്ട് (Ad Slot)*
                  </label>
                  <select
                    value={adSlot}
                    onChange={(e) => setAdSlot(e.target.value as "top" | "middle" | "sidebar")}
                    className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white cursor-pointer font-bold"
                  >
                    <option value="top">ഹോംപേജ് മുകളിൽ (Top Slot)</option>
                    <option value="middle">വാര്‍ത്തകള്‍ക്കിടയില്‍ (Middle Grid Slot)</option>
                    <option value="sidebar">വാർത്തയുടെ ഉള്ളിൽ വശങ്ങളിൽ (Sidebar/Reader Slot)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                    വിഭാഗം (Category)*
                  </label>
                  <select
                    value={adCategory}
                    onChange={(e) => setAdCategory(e.target.value)}
                    className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white cursor-pointer font-bold"
                  >
                    <option value="All">എല്ലാ വിഭാഗവും (All Categories)</option>
                    {categories.filter(c => c !== "എല്ലാം").map(catName => (
                      <option key={catName} value={catName}>{catName}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Image Upload system */}
              <div className="bg-gray-50 p-4 rounded-2xl border border-gray-150 space-y-3">
                <span className="block text-xs font-black text-gray-600 select-none">
                  പരസ്യ ചിത്രം ചേർക്കുക (Ad Banner Image Link or File Upload)
                </span>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* File picker */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">
                      ഫയൽ അപ്‌ലോഡ് ചെയ്യുക (Limit 5MB)
                    </label>
                    <label className="flex flex-col items-center justify-center border-2 border-dashed border-gray-300 rounded-xl px-4 py-2.5 bg-white cursor-pointer hover:border-brand-red transition-all text-center">
                      <Upload className="w-5 h-5 text-gray-400 mb-1" />
                      <span className="text-[10px] font-bold text-gray-500 truncate max-w-[150px]">
                        {adImageName || "ഫയൽ തിരഞ്ഞെടുക്കൂ"}
                      </span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleAdFileChange}
                        className="hidden"
                      />
                    </label>
                  </div>

                  {/* Direct image link */}
                  <div>
                    <label className="block text-[10px] font-bold text-gray-500 mb-1">
                      അല്ലെങ്കിൽ ഓൺലൈൻ ഇമേജ് ലിങ്ക്
                    </label>
                    <input
                      type="text"
                      placeholder="https://images.unsplash.com/..."
                      value={adImageUrl}
                      onChange={(e) => {
                        setAdImageUrl(e.target.value);
                        setAdImageBase64(""); // Prioritize input link if updated
                        setAdImageName("");
                      }}
                      className="w-full px-3 py-2.5 bg-white border border-gray-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-brand-red"
                    />
                  </div>
                </div>

                {adImageBase64 && (
                  <div className="flex items-center space-x-2 text-emerald-700 bg-white p-2 rounded border border-emerald-100 mt-2">
                    <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                    <span className="text-[10px] font-bold">പ്രാദേശിക ചിത്രം അപ്‌ലോഡ് ചെയ്യാൻ തയാറാണ്</span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <button
                  type="submit"
                  disabled={isUploadingAd}
                  className={`flex-grow font-bold py-3.5 px-4 rounded-xl text-xs flex items-center justify-center space-x-2 transition-colors cursor-pointer text-white ${
                    editingAdId
                      ? "bg-emerald-600 hover:bg-emerald-700"
                      : "bg-brand-red hover:bg-brand-dark"
                  }`}
                >
                  <span>
                    {isUploadingAd
                      ? "സംരക്ഷിക്കുന്നു..."
                      : editingAdId
                      ? "മാറ്റങ്ങൾ സംരക്ഷിക്കുക (Save Changes)"
                      : "പരസ്യം പബ്ലിഷ് ചെയ്യുക"}
                  </span>
                </button>

                {editingAdId && (
                  <button
                    type="button"
                    onClick={handleCancelEditAd}
                    className="px-4 py-3.5 bg-gray-150 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    റദ്ദാക്കുക (Cancel)
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Right column: Manage advertisements (5 Cols) */}
          <div className="lg:col-span-5 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm flex flex-col h-full">
            <div className="border-b border-gray-50 pb-4 mb-6 text-left">
              <h3 className="text-lg font-bold text-gray-900">നിലവിലുള്ള പരസ്യങ്ങൾ (Active Ads)</h3>
            </div>

            <div className="space-y-3 overflow-y-auto max-h-[600px] flex-grow pr-1">
              {ads.length === 0 ? (
                <p className="text-sm text-gray-400 font-bold py-8 text-center bg-gray-50 rounded-2xl">
                  നിലവിൽ പരസ്യങ്ങൾ ഒന്നും തന്നെയില്ല.
                </p>
              ) : (
                ads.map((ad) => (
                  <div
                    key={ad.id}
                    className="flex items-center justify-between p-3 border border-gray-100 rounded-2xl hover:bg-gray-50 transition-colors"
                  >
                    <div className="flex items-center space-x-3 overflow-hidden text-left">
                      <img
                        src={ad.imageUrl}
                        alt={ad.title}
                        referrerPolicy="no-referrer"
                        className="w-12 h-12 object-cover rounded-lg bg-gray-100 shrink-0"
                      />
                      <div className="overflow-hidden">
                        <div className="flex items-center space-x-1.5 flex-wrap">
                          <h4 className="font-bold text-xs text-gray-950 truncate max-w-[150px] text-left">
                            {ad.title}
                          </h4>
                          <span className="text-[9px] px-1.5 py-0.5 bg-rose-50 text-brand-red rounded-md font-bold uppercase shrink-0">
                            {ad.slot === "middle" ? "Middle" : ad.slot === "sidebar" ? "Sidebar" : "Top"}
                          </span>
                        </div>
                        <p className="text-[10px] text-gray-400 font-bold mt-1.5 truncate max-w-[180px] text-left">
                          {ad.sponsor} • {ad.link !== "#" ? "Link Active" : "No Link"}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-1">
                      {deleteConfirmAdId === ad.id ? (
                        <div className="flex items-center space-x-1 animate-fade-in">
                          <button
                            onClick={async () => {
                              try {
                                await onDeleteAd(ad.id);
                              } catch (e) {
                                console.error(e);
                              } finally {
                                setDeleteConfirmAdId(null);
                              }
                            }}
                            className="bg-red-600 hover:bg-red-700 text-white font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                          >
                            ഡിലീറ്റ് (Confirm)
                          </button>
                          <button
                            onClick={() => setDeleteConfirmAdId(null)}
                            className="bg-gray-100 hover:bg-gray-200 text-gray-700 font-bold text-[10px] px-2.5 py-1.5 rounded-lg transition-colors cursor-pointer whitespace-nowrap"
                          >
                            റദ്ദാക്കുക
                          </button>
                        </div>
                      ) : (
                        <>
                          <button
                            onClick={() => handleStartEditAd(ad)}
                            className={`p-2 rounded-xl transition-all border text-xs cursor-pointer ${
                              editingAdId === ad.id
                                ? "bg-emerald-50 text-emerald-700 border-emerald-205"
                                : "text-gray-450 hover:text-emerald-700 bg-gray-50 hover:bg-emerald-50 border-gray-100 hover:border-emerald-100"
                            }`}
                            title="പരസ്യം എഡിറ്റ് ചെയ്യുക"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmAdId(ad.id)}
                            className="p-2 text-gray-400 hover:text-red-700 bg-gray-50 hover:bg-red-50 rounded-xl transition-all border border-gray-100 hover:border-red-100 cursor-pointer"
                            title="പരസ്യം നീക്കം ചെയ്യുക"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : adminTab === "categories" ? (
        /* adminTab === "categories" */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 text-left">
          {/* Left Column: Create/Edit Form */}
          <div className="lg:col-span-6 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm">
            <h3 className="text-lg font-bold text-gray-900 border-b border-gray-50 pb-4 mb-6 select-none flex items-center gap-2">
              <Pencil className="w-5 h-5 text-brand-red" />
              {editingCategoryName ? "വിഭാഗം എഡിറ്റ് ചെയ്യുക (Edit Category)" : "പുതിയ വിഭാഗം നിർമിക്കുക (Create Category)"}
            </h3>

            {categoryFormError && (
              <div className="bg-red-50 border border-red-200 text-red-700 text-xs font-bold p-3.5 rounded-xl mb-4 text-left">
                {categoryFormError}
              </div>
            )}

            {categoryFormSuccess && (
              <div className="bg-emerald-50 border border-emerald-250 text-emerald-700 text-xs font-bold p-3.5 rounded-xl mb-4 flex items-center space-x-2 text-left">
                <CheckCircle className="w-4 h-4 text-emerald-600" />
                <span>വിഭാഗം വിജയകരമായി സംരക്ഷിച്ചു! (Category Saved!)</span>
              </div>
            )}

            <form onSubmit={handleCategorySubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1 pl-1">
                  വിഭാഗത്തിന്റെ പേര് (Category Name)*
                </label>
                <input
                  type="text"
                  required
                  placeholder="ഉദാ: ടെക്നോളജി, വാണിജ്യം..."
                  value={categoryInputName}
                  onChange={(e) => setCategoryInputName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-gray-50/50 border border-gray-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-brand-red focus:bg-white"
                />
              </div>

              <div className="pt-2 flex items-center space-x-3">
                <button
                  type="submit"
                  className="px-6 py-3.5 bg-brand-red hover:bg-brand-dark text-white font-extrabold rounded-xl text-xs transition-colors shadow-sm cursor-pointer"
                >
                  {editingCategoryName ? "മാറ്റങ്ങൾ സംരക്ഷിക്കുക (Save Changes)" : "വിഭാഗം അപ്‌ലോഡ് ചെയ്യുക (Create)"}
                </button>

                {editingCategoryName && (
                  <button
                    type="button"
                    onClick={() => {
                      setEditingCategoryName(null);
                      setCategoryInputName("");
                    }}
                    className="px-4 py-3.5 bg-gray-150 hover:bg-gray-200 text-gray-700 font-bold rounded-xl text-xs transition-colors cursor-pointer"
                  >
                    റദ്ദാക്കുക (Cancel)
                  </button>
                )}
              </div>
            </form>
          </div>

          {/* Right Column: Manage Existing Categories */}
          <div className="lg:col-span-6 bg-white border border-gray-100 rounded-3xl p-6 shadow-sm flex flex-col h-full">
            <h3 className="text-lg font-bold text-gray-900 border-b border-gray-50 pb-4 mb-6">
              നിലവിലുള്ള വിഭാഗങ്ങൾ നിയന്ത്രിക്കുക (Manage Categories)
            </h3>

            <div className="space-y-3 overflow-y-auto max-h-[500px] flex-grow pr-1">
              {categories.length === 0 ? (
                <p className="text-sm text-gray-400 font-bold py-8 text-center bg-gray-50 rounded-2xl">
                  നിലവിൽ വിഭാഗങ്ങൾ ഒന്നും തന്നെയില്ല.
                </p>
              ) : (
                categories.map((catName, idx) => (
                  <div
                    key={idx}
                    className="flex flex-row items-center justify-between p-4 rounded-2xl border border-gray-100 bg-white hover:border-gray-200 transition-all shadow-[0_2px_8px_-6px_rgba(0,0,0,0.1)]"
                  >
                    <div className="flex flex-col pr-4">
                      <span className="text-sm font-bold text-gray-900">{catName}</span>
                    </div>

                    <div className="flex gap-2">
                      {catName !== "എല്ലാം" && (
                        <>
                          <button
                            onClick={() => {
                              setEditingCategoryName(catName);
                              setCategoryInputName(catName);
                              window.scrollTo({ top: 0, behavior: "smooth" });
                            }}
                            className="p-2 text-gray-500 hover:text-brand-red bg-gray-50 hover:bg-red-50 rounded-xl transition-all border border-gray-100 cursor-pointer"
                            title="എഡിറ്റ് ചെയ്യുക"
                          >
                            <Pencil className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm("ഈ വിഭാഗം ഇല്ലാതാക്കണമെന്ന് ഉറപ്പാണോ?")) {
                                handleDeleteCategory(catName);
                              }
                            }}
                            className="p-2 text-gray-400 hover:text-red-700 bg-gray-50 hover:bg-red-50 rounded-xl transition-all border border-gray-100 hover:border-red-100 cursor-pointer"
                            title="നീക്കം ചെയ്യുക"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </>
                      )}
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}