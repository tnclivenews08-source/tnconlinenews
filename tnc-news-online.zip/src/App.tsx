import React, { useState, useEffect } from "react";
import Header from "./components/Header";
import AdBanner from "./components/AdBanner";
import NewsCard from "./components/NewsCard";
import ArticleReader from "./components/ArticleReader";
import AdminDashboard from "./components/AdminDashboard";
import { NewsArticle, NewsCategory, AdBannerType, BreakingNews, PortalNotification } from "./types";
import { AnimatePresence, motion } from "motion/react";
import { Newspaper, Bell, Heart, ThumbsUp, RefreshCw, Sparkles, MessageSquareDot, CheckCircle2, Megaphone, X, AlertCircle, Pencil } from "lucide-react";

// Firebase Auth & custom view imports
import { onAuthStateChanged, signOut } from "firebase/auth";
import { auth } from "./firebase";
import AuthView from "./components/AuthView";

export default function App() {
  const [articles, setArticles] = useState<NewsArticle[]>([]);
  const [ads, setAds] = useState<AdBannerType[]>([]);
  const [breaking, setBreaking] = useState<BreakingNews[]>([]);
  const [categories, setCategories] = useState<string[]>(["എല്ലാം", "കേരളം", "പ്രാദേശികം", "രാഷ്ട്രീയം", "കായികം", "വിനോദം", "പ്രവാസം"]);
  const [loading, setLoading] = useState(true);
  const [errorMsg, setErrorMsg] = useState("");

  // Notifications and Subscription management state
  const [notifications, setNotifications] = useState<PortalNotification[]>([]);
  const [isSubscribed, setIsSubscribed] = useState<boolean>(() => {
    return localStorage.getItem("tnc_subscribed") === "true";
  });
  const [subscribersCount, setSubscribersCount] = useState<number>(324);
  const [newNotifAlert, setNewNotifAlert] = useState<PortalNotification | null>(null);

  // Stateful Filter Parameters
  const [currentCategory, setCurrentCategory] = useState<NewsCategory>("എല്ലാം");
  const [searchQuery, setSearchQuery] = useState("");

  // Navigation / Router Toggles
  const [selectedArticle, setSelectedArticle] = useState<NewsArticle | null>(null);
  const [isAdminOpened, setIsAdminOpened] = useState(false);
  const [adminInitialTab, setAdminInitialTab] = useState<"news" | "ads" | "categories">("news");
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem("tnc_admin_token");
  });

  // User Authentication Context State
  const [currentUser, setCurrentUser] = useState<any>(null);
  const [isLoadingAuth, setIsLoadingAuth] = useState(true);
  const [isAuthViewOpened, setIsAuthViewOpened] = useState(false);
  const [authViewMode, setAuthViewMode] = useState<"login" | "signup">("login");
  const [toast, setToast] = useState<{ type: "success" | "error"; message: string } | null>(null);

  // Listen to Firebase Authentication State Changes or Local Session Fallback
  useEffect(() => {
    // 1. Instantly restore custom user session if present
    const storedUserRaw = localStorage.getItem("tnc_custom_user");
    if (storedUserRaw) {
      try {
        const storedUser = JSON.parse(storedUserRaw);
        setCurrentUser(storedUser);
        setIsLoadingAuth(false);
        const email = storedUser.email.toLowerCase();
        if (email === "mejo274@gmail.com") {
          const secureToken = "tnc-news-secure-token-authenticated-2026";
          localStorage.setItem("tnc_admin_token", secureToken);
          setAdminToken(secureToken);
        }
      } catch (e) {
        console.error("Error restoration session:", e);
      }
    }

    // 2. Fallback to Firebase monitor
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user);
        setIsLoadingAuth(false);
        
        if (user.email) {
          const email = user.email.toLowerCase();
          if (email === "mejo274@gmail.com") {
            console.log("👑 Auto-enabling Admin Role session:", user.email);
            const secureToken = "tnc-news-secure-token-authenticated-2026";
            localStorage.setItem("tnc_admin_token", secureToken);
            setAdminToken(secureToken);
          }
        }
      } else {
        // Only clear if we don't have an active backend credentials login session
        if (!localStorage.getItem("tnc_custom_user")) {
          setCurrentUser(null);
          setIsLoadingAuth(false);
        }
      }
    });
    return () => unsubscribe();
  }, []);

  // Handle generalized Firebase user logout
  const handleUserLogout = async () => {
    try {
      await signOut(auth);
      localStorage.removeItem("tnc_admin_token");
      localStorage.removeItem("tnc_custom_user");
      setAdminToken(null);
      setCurrentUser(null);
      setIsAdminOpened(false);
      showToast("success", "വിജയകരമായി പുറത്ത് കടന്നു!");
    } catch (e) {
      console.error(e);
      showToast("error", "പുറത്ത് കടക്കാൻ സാധിച്ചില്ല. ദയവായി വീണ്ടും ശ്രമിക്കുക.");
    }
  };

  // Handle successful login/auth from AuthView
  const handleAuthSuccess = (email: string, name?: string) => {
    const cleanEmail = email.trim().toLowerCase();
    const displayName = name || cleanEmail.split("@")[0];
    const userObj = { email: cleanEmail, displayName };
    
    setCurrentUser(userObj);
    localStorage.setItem("tnc_custom_user", JSON.stringify(userObj));
    
    const isAdm = cleanEmail === "mejo274@gmail.com";
    if (isAdm) {
      const secureToken = "tnc-news-secure-token-authenticated-2026";
      localStorage.setItem("tnc_admin_token", secureToken);
      setAdminToken(secureToken);
      setIsAdminOpened(true);
      showToast("success", `സ്വാഗതം അഡ്മിൻ, ${displayName}`);
    } else {
      showToast("success", `ലോഗിൻ വിജയകരം. സ്വാഗതം, ${displayName}!`);
    }
  };

  // Helper to trigger styled responsive toast feedback
  const showToast = (type: "success" | "error", message: string) => {
    setToast({ type, message });
    setTimeout(() => {
      setToast(null);
    }, 4000);
  };

  // Fetch articles on load
  const fetchArticles = async () => {
    setLoading(true);
    setErrorMsg("");
    try {
      const res = await fetch("/api/news");
      if (!res.ok) throw new Error("വാർത്തകൾ ലഭ്യമാക്കുന്നതിൽ പരാജയം!");
      const data = await res.json();
      setArticles(data);

      // Keep reading article active if we are on details page
      setSelectedArticle(prev => {
        if (prev) {
          const refreshed = data.find((a: NewsArticle) => a.id === prev.id);
          return refreshed || prev;
        }
        return prev;
      });
    } catch {
      setErrorMsg("കണക്ഷൻ നഷ്ടപ്പെട്ടു. ദയവായി പേജ് റീഫ്രഷ് ചെയ്യുക.");
    } finally {
      setLoading(false);
    }
  };

  const fetchAds = async () => {
    try {
      const res = await fetch("/api/ads");
      if (res.ok) {
        const data = await res.json();
        setAds(data);
      }
    } catch (e) {
      console.error("Failed to fetch ads:", e);
    }
  };

  const fetchBreaking = async () => {
    try {
      const res = await fetch("/api/breaking");
      if (res.ok) {
        const data = await res.json();
        setBreaking(data);
      }
    } catch (e) {
      console.error("Failed to fetch breaking news:", e);
    }
  };

  const fetchCategories = async () => {
    try {
      const res = await fetch("/api/categories");
      if (res.ok) {
        const data = await res.json();
        setCategories(data);
      }
    } catch (e) {
      console.error("Failed to fetch categories:", e);
    }
  };

  const fetchNotifications = async () => {
    try {
      const res = await fetch("/api/notifications");
      if (res.ok) {
        const data = await res.json();
        
        // If the user has subscribed and a new notification is generated, pop up a gorgeous live alert
        if (notifications.length > 0 && data.length > notifications.length) {
          const isSub = localStorage.getItem("tnc_subscribed") === "true";
          if (isSub) {
            const fresh = data.filter((n: PortalNotification) => !notifications.some((o) => o.id === n.id));
            if (fresh.length > 0) {
              setNewNotifAlert(fresh[0]);
              // Dissolve alert after 8 seconds
              setTimeout(() => {
                setNewNotifAlert(null);
              }, 8000);
            }
          }
        }
        setNotifications(data);
      }
    } catch (e) {
      console.error("Failed to fetch notifications:", e);
    }
  };

  const fetchSubscribersCount = async () => {
    try {
      const res = await fetch("/api/notifications/subscribers");
      if (res.ok) {
        const data = await res.json();
        setSubscribersCount(data.count);
      }
    } catch (e) {
      console.error("Failed to fetch subscriber metrics:", e);
    }
  };

  useEffect(() => {
    fetchArticles();
    fetchAds();
    fetchBreaking();
    fetchCategories();
    fetchNotifications();
    fetchSubscribersCount();
  }, []);

  useEffect(() => {
    // Keep backend state synced in near-real-time every 6 seconds
    const interval = setInterval(() => {
      fetchArticles();
      fetchNotifications();
      fetchSubscribersCount();
    }, 6000);
    return () => clearInterval(interval);
  }, [notifications]);

  // Admin login session persistence
  const handleAdminLogin = (token: string) => {
    localStorage.setItem("tnc_admin_token", token);
    setAdminToken(token);
  };

  const handleAdminLogout = () => {
    localStorage.removeItem("tnc_admin_token");
    setAdminToken(null);
    setIsAdminOpened(false);
  };

  // Like an article
  const handleLike = async (id: string) => {
    try {
      const res = await fetch(`/api/news/${id}/like`, { method: "POST" });
      if (res.ok) {
        // Optimistic state update representing real backend value
        setArticles((prev) =>
          prev.map((art) => (art.id === id ? { ...art, likes: art.likes + 1 } : art))
        );
        if (selectedArticle && selectedArticle.id === id) {
          setSelectedArticle((prev) => prev ? { ...prev, likes: prev.likes + 1 } : null);
        }
      }
    } catch (e) {
      console.error("Failed to like article:", e);
    }
  };

  // Upload an article
  const handleUploadNews = async (newArt: Partial<NewsArticle> & { imageBase64?: string }) => {
    try {
      const res = await fetch("/api/news", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify(newArt),
      });

      if (!res.ok) throw new Error("Upload failed");
      
      // Refresh articles list from database
      await fetchArticles();
    } catch (e) {
      console.error("Upload failed:", e);
      throw e;
    }
  };

  // Delete an article
  const handleDeleteNews = async (id: string) => {
    try {
      const res = await fetch(`/api/news/${id}`, { 
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${adminToken || ""}`
        }
      });
      if (res.ok) {
        await fetchArticles();
        if (selectedArticle?.id === id) {
          setSelectedArticle(null);
        }
      }
    } catch (e) {
      console.error("Delete failed:", e);
    }
  };

  // Upload an ad
  const handleUploadAd = async (newAd: Partial<AdBannerType> & { imageBase64?: string }) => {
    try {
      const res = await fetch("/api/ads", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify(newAd),
      });

      if (!res.ok) throw new Error("Ad upload failed");
      await fetchAds();
    } catch (e) {
      console.error("Ad upload failed:", e);
      throw e;
    }
  };

  // Update an article
  const handleUpdateNews = async (id: string, updatedArt: Partial<NewsArticle> & { imageBase64?: string }) => {
    try {
      const res = await fetch(`/api/news/${id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify(updatedArt),
      });

      if (!res.ok) throw new Error("Update failed");
      await fetchArticles();
    } catch (e) {
      console.error("Update failed:", e);
      throw e;
    }
  };

  // Update an ad
  const handleUpdateAd = async (id: string, updatedAd: Partial<AdBannerType> & { imageBase64?: string }) => {
    try {
      const res = await fetch(`/api/ads/${id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify(updatedAd),
      });

      if (!res.ok) throw new Error("Ad update failed");
      await fetchAds();
    } catch (e) {
      console.error("Ad update failed:", e);
      throw e;
    }
  };

  // Delete an ad
  const handleDeleteAd = async (id: string) => {
    try {
      const res = await fetch(`/api/ads/${id}`, { 
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${adminToken || ""}`
        }
      });
      if (res.ok) {
        await fetchAds();
      }
    } catch (e) {
      console.error("Failed to delete ad:", e);
    }
  };

  // Add breaking news
  const handleAddBreaking = async (text: string) => {
    try {
      const res = await fetch("/api/breaking", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) throw new Error("Adding breaking news failed");
      await fetchBreaking();
    } catch (e) {
      console.error(e);
      throw e;
    }
  };

  // Update breaking news
  const handleUpdateBreaking = async (id: string, text: string) => {
    try {
      const res = await fetch(`/api/breaking/${id}`, {
        method: "PUT",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify({ text }),
      });
      if (!res.ok) throw new Error("Updating breaking news failed");
      await fetchBreaking();
    } catch (e) {
      console.error(e);
      throw e;
    }
  };

  // Delete breaking news
  const handleDeleteBreaking = async (id: string) => {
    try {
      const res = await fetch(`/api/breaking/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${adminToken || ""}`
        }
      });
      if (!res.ok) throw new Error("Deleting breaking news failed");
      await fetchBreaking();
    } catch (e) {
      console.error(e);
      throw e;
    }
  };

  const handleUpdateCategories = async (newCategories: string[]) => {
    try {
      const res = await fetch("/api/categories", {
        method: "POST",
        headers: { 
          "Content-Type": "application/json",
          "Authorization": `Bearer ${adminToken || ""}`
        },
        body: JSON.stringify({ categories: newCategories }),
      });
      if (!res.ok) throw new Error("Updating categories failed");
      await fetchCategories();
    } catch (e) {
      console.error(e);
      throw e;
    }
  };

  // Submit readers comment
  const handlePostComment = async (id: string, author: string, content: string) => {
    try {
      const res = await fetch(`/api/news/${id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ author, content }),
      });

      if (res.ok) {
        const data = await res.json();
        // Dynamic client-side list append
        setArticles((prev) =>
          prev.map((art) => {
            if (art.id === id) {
              return {
                ...art,
                comments: [...art.comments, data.comment],
              };
            }
            return art;
          })
        );
        if (selectedArticle && selectedArticle.id === id) {
          setSelectedArticle((prev) =>
            prev ? { ...prev, comments: [...prev.comments, data.comment] } : null
          );
        }
      }
    } catch (e) {
      console.error("Comment failed:", e);
    }
  };

  // Navigation views selector
  const selectNewsArticle = async (art: NewsArticle) => {
    setSelectedArticle(art);
    setIsAdminOpened(false);
    // Smooth scroll top on navigation
    window.scrollTo({ top: 0, behavior: "smooth" });

    // Optional dynamic views tracker call to server to sync views accurately
    try {
      await fetch(`/api/news/${art.id}`); // This fetches details and increments backend views count
    } catch (e) {
      console.error("Fail views counting:", e);
    }
  };

  // Toggle user preference subscribed flag
  const handleToggleSubscribe = async () => {
    try {
      const targetState = !isSubscribed;
      localStorage.setItem("tnc_subscribed", String(targetState));
      setIsSubscribed(targetState);

      const endpoint = targetState ? "/api/notifications/subscribe" : "/api/notifications/unsubscribe";
      const res = await fetch(endpoint, { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setSubscribersCount(data.count);
      }
    } catch (e) {
      console.error("Error setting subscription state:", e);
    }
  };

  // Mark all server notifications read
  const handleMarkAllNotificationsRead = async () => {
    try {
      const res = await fetch("/api/notifications/mark-all-read", { method: "POST" });
      if (res.ok) {
        const data = await res.json();
        setNotifications(data.notifications);
      }
    } catch (e) {
      console.error("Failed to mark notifications read:", e);
    }
  };

  // Load article from notification row callback
  const handleSelectArticleById = async (articleId: string) => {
    try {
      const res = await fetch(`/api/news/${articleId}`);
      if (res.ok) {
        const artData = await res.json();
        setSelectedArticle(artData);
        setIsAdminOpened(false);
        window.scrollTo({ top: 0, behavior: "smooth" });
        
        // Local Optimistic unread marker update
        setNotifications((prev) => 
          prev.map((n) => n.articleId === articleId ? { ...n, read: true } : n)
        );
      }
    } catch (e) {
      console.error("Failed to fetch notification article:", e);
    }
  };

  // Filters logic
  const filteredArticles = articles.filter((art) => {
    const matchesCategory = currentCategory === "എല്ലാം" || art.category === currentCategory;
    const matchesSearch =
      art.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      art.content.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#F9FAFB] flex flex-col justify-between selection:bg-brand-red selection:text-white">
      <div>
        {/* Navigation Portal Header */}
        <Header
          categories={categories}
          currentCategory={currentCategory}
          onSelectCategory={(cat) => {
            setCurrentCategory(cat);
            setSelectedArticle(null);
            setIsAdminOpened(false);
          }}
          onSearch={setSearchQuery}
          onOpenAdmin={(tab) => {
            setAdminInitialTab(tab || "news");
            setIsAdminOpened(true);
            setSelectedArticle(null);
          }}
          isAdmin={!!adminToken}
          onLogout={handleAdminLogout}
          breakingNews={breaking}
          notifications={notifications}
          onSelectArticleById={handleSelectArticleById}
          isSubscribed={isSubscribed}
          onToggleSubscribe={handleToggleSubscribe}
          subscribersCount={subscribersCount}
          onMarkAllNotificationsRead={handleMarkAllNotificationsRead}
          currentUser={currentUser}
          onOpenAuth={() => {
            setAuthViewMode("login");
            setIsAuthViewOpened(true);
          }}
          onLogoutUser={handleUserLogout}
        />

        {/* Dynamic Navigation/Content Section Router */}
        <AnimatePresence mode="wait">
          <motion.main
            key={isAdminOpened ? "admin" : selectedArticle ? `article-${selectedArticle.id}` : "feed"}
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -12 }}
            transition={{ duration: 0.25 }}
            className="flex-grow pb-12"
          >
            {/* View 1: Administrative dashboard panel (FULLY SECURED!) */}
            {isAdminOpened ? (
              isLoadingAuth ? (
                <div className="flex flex-col items-center justify-center py-20 bg-white border border-gray-100 rounded-3xl p-6 shadow-xs max-w-md mx-auto my-8">
                  <RefreshCw className="w-8 h-8 text-brand-red animate-spin mb-3" />
                  <p className="text-xs text-gray-400 font-extrabold font-sans">പ്രമാണീകരണം പരിശോധിക്കുന്നു...</p>
                </div>
              ) : currentUser === null ? (
                /* Unauthenticated Redirect to Login Page */
                <div className="py-8 max-w-md mx-auto px-4">
                  <div className="mb-4 text-center">
                    <div className="bg-red-50 text-brand-red px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest inline-block mb-3">
                      സുരക്ഷാ പ്രവേശന കവാടം (Security Gate)
                    </div>
                    <p className="text-sm text-gray-600 font-bold leading-relaxed">
                      അഡ്മിൻ ഡാഷ്‌ബോർഡ് ഉപയോഗിക്കുന്നതിനായി ദയവായി നിങ്ങളുടെ അക്കൗണ്ടിലേക്ക് ലോഗിൻ ചെയ്യുക.
                    </p>
                  </div>
                  <AuthView
                    defaultMode="login"
                    onSuccess={(email, name) => {
                      handleAuthSuccess(email, name);
                    }}
                  />
                </div>
              ) : !adminToken ? (
                /* Authenticated but Not Authorized (Not Admin) */
                <div className="max-w-md mx-auto bg-white border border-gray-150 rounded-3xl p-6 md:p-8 shadow-xl text-center my-8">
                  <div className="bg-red-50 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 text-brand-red">
                    <AlertCircle className="w-8 h-8" />
                  </div>
                  <h3 className="text-lg font-black text-gray-950 mb-2">പ്രവേശനം നിഷേധിച്ചിരിക്കുന്നു</h3>
                  <p className="text-xs text-gray-500 font-semibold leading-relaxed mb-6">
                    നിങ്ങൾ ലോഗിൻ ചെയ്തിരിക്കുന്ന അക്കൗണ്ടിന് (<span className="text-brand-red">{currentUser.email}</span>) അഡ്മിൻ അനുമതികൾ ലഭ്യമല്ല. ദയവായി ശരിയായ പ്രമാണങ്ങൾ ഉള്ള അഡ്മിൻ അക്കൗണ്ട് ഉപയോഗിച്ച് ലോഗിൻ ചെയ്യുക.
                  </p>
                  <div className="flex flex-col gap-2.5">
                    <button
                      onClick={handleUserLogout}
                      className="bg-brand-red hover:bg-brand-dark text-white font-extrabold py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      മറ്റൊരു അക്കൗണ്ടിലേക്ക് മാറുക (Switch Account)
                    </button>
                    <button
                      onClick={() => setIsAdminOpened(false)}
                      className="border border-gray-200 hover:bg-gray-50 text-gray-700 font-bold py-2.5 rounded-xl text-xs transition-colors cursor-pointer"
                    >
                      പ്രധാന വാർത്തകളിലേക്ക് മടങ്ങുക
                    </button>
                  </div>
                </div>
              ) : (
                /* Authenticated as Admin -> Dashboard Access */
                <AdminDashboard
                  articles={articles}
                  onUpload={handleUploadNews}
                  onDelete={handleDeleteNews}
                  onClose={() => setIsAdminOpened(false)}
                  isAdmin={true}
                  onLogin={handleAdminLogin}
                  ads={ads}
                  onUploadAd={handleUploadAd}
                  onDeleteAd={handleDeleteAd}
                  onUpdate={handleUpdateNews}
                  onUpdateAd={handleUpdateAd}
                  breakingNews={breaking}
                  onAddBreaking={handleAddBreaking}
                  onUpdateBreaking={handleUpdateBreaking}
                  onDeleteBreaking={handleDeleteBreaking}
                  initialTab={adminInitialTab}
                  categories={categories}
                  onUpdateCategories={handleUpdateCategories}
                />
              )
            ) : selectedArticle ? (
              /* View 2: Full News Article Reader Details */
              <ArticleReader
                article={selectedArticle}
                onBack={() => {
                  setSelectedArticle(null);
                  fetchArticles(); // Reload newest views/likes on return
                }}
                onLike={() => handleLike(selectedArticle.id)}
                onPostComment={(author, content) => handlePostComment(selectedArticle.id, author, content)}
                relatedArticles={articles}
                onSelectArticle={selectNewsArticle}
                ads={ads}
                isAdmin={!!adminToken}
                onOpenAdmin={(tab) => {
                  setAdminInitialTab(tab || "news");
                  setIsAdminOpened(true);
                  setSelectedArticle(null);
                }}
              />
            ) : (
              /* View 3: Homepage News Feed */
              <div>
                {/* Advertisement banner section */}
                <AdBanner
                  ads={ads}
                  slot="top"
                  isAdmin={!!adminToken}
                  currentCategory={currentCategory}
                  onOpenAdmin={(tab) => {
                    setAdminInitialTab(tab || "news");
                    setIsAdminOpened(true);
                    setSelectedArticle(null);
                  }}
                />

                {/* Main Articles grid */}
                <div className="max-w-7xl mx-auto px-4 mt-1.5 md:mt-4 overflow-hidden">
                  <div className="flex items-center justify-between border-b border-gray-100 pb-2 md:pb-4 mb-3 md:mb-6">
                    <div className="flex items-center space-x-2 md:space-x-3 text-left select-none">
                      <span className="w-1 h-4 md:w-1.5 md:h-6 bg-brand-red rounded-full shrink-0"></span>
                      <h2 className="text-base md:text-xl font-black text-gray-950 font-display leading-none tracking-tight">
                        {currentCategory === "എല്ലാം" ? "തത്സമയ വാർത്തകൾ (Latest News)" : `${currentCategory} വാർത്തകൾ`}
                      </h2>
                    </div>

                    <div className="flex items-center space-x-2">
                      <button
                        onClick={fetchArticles}
                        className="p-1.5 hover:text-brand-red text-gray-400 hover:bg-gray-100 rounded-lg transition-all cursor-pointer"
                        title="വാർത്തകൾ വീണ്ടും ലോഡ് ചെയ്യുക"
                      >
                        <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin text-brand-red" : ""}`} />
                      </button>
                    </div>
                  </div>

                  {/* Loading overlay & empty states */}
                  {loading && articles.length === 0 ? (
                    <div className="flex flex-col items-center justify-center py-20">
                      <div className="relative mb-4">
                        <div className="w-12 h-12 border-4 border-t-brand-red border-red-100 rounded-full animate-spin"></div>
                        <Sparkles className="absolute inset-0 m-auto text-brand-red w-4 h-4 animate-pulse" />
                      </div>
                      <p className="text-sm font-bold text-gray-400 font-sans">തത്സമയ വാർത്തകൾ ലോഡ് ചെയ്യുന്നു...</p>
                    </div>
                  ) : errorMsg ? (
                    <div className="bg-red-50 border border-red-100 text-red-700 p-6 rounded-2xl text-center max-w-md mx-auto my-12 shadow-sm font-sans">
                      <p className="font-bold text-sm mb-2">{errorMsg}</p>
                      <button
                        onClick={fetchArticles}
                        className="bg-brand-red text-white text-xs px-4 py-2 rounded-lg font-bold cursor-pointer animate-pulse"
                      >
                        വീണ്ടും ശ്രമിക്കുക
                      </button>
                    </div>
                  ) : filteredArticles.length === 0 ? (
                    <div className="text-center py-20 bg-white border border-gray-100 rounded-3xl shadow-sm max-w-lg mx-auto my-8 font-sans">
                      <MessageSquareDot className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                      <p className="text-sm font-bold text-gray-400">
                        {searchQuery
                          ? `"${searchQuery}" എന്ന വാക്കിൽ വാർത്തകൾ ഒന്നും കണ്ടെത്താനായില്ല.`
                          : "ഈ കാറ്റഗറിയിൽ വാർത്തകൾ ഒന്നും ലഭ്യമല്ല."}
                      </p>
                    </div>
                  ) : (
                    <div className="space-y-6 md:space-y-12">
                      {/* Grid 1: Main Highlight Cards */}
                      <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 md:gap-6 animate-fade-in animate-once">
                        {filteredArticles.slice(0, 3).map((article, index) => (
                          <motion.div
                            key={article.id}
                            initial={{ opacity: 0, y: 15 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.2, delay: index * 0.05 }}
                            className={index === 0 ? "lg:col-span-2" : ""}
                          >
                            <NewsCard
                              article={article}
                              onClick={() => selectNewsArticle(article)}
                            />
                          </motion.div>
                        ))}
                      </div>

                      {/* Center Grid: Remainder articles row with injected inline Ads */}
                      {filteredArticles.length > 3 && (
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 md:gap-6 animate-fade-in select-none">
                          {(() => {
                            // Filter Ads suitable for Grid injection (e.g. matching category)
                            const gridAds = ads.filter(ad => 
                              ad.slot === "middle" && 
                              (!ad.category || ad.category === "All" || ad.category === currentCategory)
                            );
                            
                            const feedItems: any[] = [];
                            filteredArticles.slice(3).forEach((article, index) => {
                              feedItems.push({ type: "article", data: article });
                              // Inject an ad every 3 articles (if available)
                              if ((index + 1) % 3 === 0) {
                                const adIndex = Math.floor(index / 3) % gridAds.length;
                                if (gridAds[adIndex]) {
                                  feedItems.push({ type: "ad", data: gridAds[adIndex], id: `ad-${index}` });
                                }
                              }
                            });

                            return feedItems.map((item, i) => (
                              <motion.div
                                key={item.type === "article" ? item.data.id : item.id}
                                layout
                                initial={{ opacity: 0, scale: 0.95 }}
                                animate={{ opacity: 1, scale: 1 }}
                                transition={{ duration: 0.2 }}
                              >
                                {item.type === "article" ? (
                                  <NewsCard
                                    article={item.data}
                                    onClick={() => selectNewsArticle(item.data)}
                                  />
                                ) : (
                                  // Inline Ad Card mimicking NewsCard structure
                                  <div
                                    onClick={() => {
                                      if (item.data.link && item.data.link !== "#") {
                                        window.open(item.data.link.startsWith("http") ? item.data.link : `https://${item.data.link}`, "_blank");
                                      }
                                    }}
                                    className="group cursor-pointer bg-amber-50/50 rounded-xl md:rounded-2xl overflow-hidden shadow-sm hover:shadow-xl border border-amber-200 transition-all duration-300 flex flex-col h-full transform hover:-translate-y-1 relative"
                                  >
                                    <div className="absolute top-2 right-2 z-10 flex space-x-2">
                                      <span className="bg-amber-500/90 text-white text-[9px] font-black tracking-widest px-2 py-0.5 rounded shadow-sm opacity-90">
                                        SPONSORED
                                      </span>
                                      {adminToken && (
                                        <button
                                          onClick={(e) => {
                                            e.stopPropagation();
                                            setAdminInitialTab("ads");
                                            setIsAdminOpened(true);
                                          }}
                                          className="bg-yellow-400 hover:bg-yellow-500 text-black text-[9px] font-black px-1.5 py-0.5 rounded shadow-sm flex items-center space-x-1"
                                        >
                                          <Pencil className="w-2.5 h-2.5" />
                                          <span>Edit</span>
                                        </button>
                                      )}
                                    </div>
                                    <div className="relative aspect-video w-full overflow-hidden bg-amber-100 shrink-0 border-b border-amber-100">
                                      <img
                                        src={item.data.imageUrl}
                                        alt={item.data.title}
                                        referrerPolicy="no-referrer"
                                        className="w-full h-full object-cover group-hover:scale-103 transition-transform duration-500"
                                        loading="lazy"
                                      />
                                    </div>
                                    <div className="p-4 md:p-5 flex flex-col flex-grow">
                                      <div className="mb-2 flex items-center gap-1 text-amber-600">
                                        <Megaphone className="w-3 h-3 block" />
                                        <span className="inline-block text-[10px] font-bold px-1 rounded-full uppercase tracking-wider">
                                          {item.data.sponsor}
                                        </span>
                                      </div>
                                      <h3 className="font-bold text-gray-900 text-[15px] md:text-lg leading-tight mb-2 line-clamp-2">
                                        {item.data.title}
                                      </h3>
                                      {item.data.subtitle && (
                                        <p className="text-gray-600 text-xs leading-relaxed line-clamp-3 mb-4 font-medium flex-grow">
                                          {item.data.subtitle}
                                        </p>
                                      )}
                                      <div className="mt-auto pt-3 border-t border-amber-100 flex items-center justify-between">
                                        <span className="text-[11px] font-bold text-amber-700 underline decoration-amber-300 underline-offset-2">
                                          സന്ദർശിക്കുക
                                        </span>
                                      </div>
                                    </div>
                                  </div>
                                )}
                              </motion.div>
                            ));
                          })()}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              </div>
            )}
          </motion.main>
        </AnimatePresence>
      </div>

      {/* Decorative, literal, human Malayalam Portal Footer */}
      <footer className="bg-gray-950 text-gray-400 border-t border-red-950 py-5 mt-6 text-sm w-full font-sans">
        <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-6 text-left">
          {/* Logo Column */}
          <div className="space-y-2">
            <div className="flex items-center space-x-2 select-none">
              <span className="bg-brand-red text-white p-1.5 rounded-lg font-black text-xs">TNC</span>
              <span className="text-white font-extrabold text-xs tracking-tight select-none font-sans uppercase">TNC news online</span>
            </div>
            <p className="text-xs text-gray-500 leading-relaxed font-semibold">
              ഒരു ലളിതവും ആധുനികവുമായ പ്രാദേശിക വാർത്താ പോർട്ടൽ. വിശ്വസനീയമായ വാർത്തകൾ കണ്മുന്നിൽ യഥാർത്ഥ സമയത്ത് നിങ്ങളിലേക്ക് എത്തിക്കുന്നു.
            </p>
          </div>

          {/* Contact Details Column */}
          <div className="font-sans font-semibold">
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-2 font-sans select-none">ബന്ധപ്പെടുക (Contact)</h4>
            <p className="text-xs text-gray-500 leading-relaxed font-sans">
              കേരള, തൃശ്ശൂർ, മണ്ണുത്തി 680651<br />
              ബന്ധപ്പെടുക: 6238995482<br />
              ഇമെയിൽ: tnclivenews08@gmail.com
            </p>
            <p className="text-[10px] text-gray-600 font-bold mt-2 tracking-wider select-none uppercase">
              AUTHORIZED PORTAL LICENSED INC DAILY REPORTING
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto px-4 mt-6 pt-4 border-t border-red-950 text-center text-[11px] text-gray-600 font-bold select-none font-sans">
          © {new Date().getFullYear()} TNC News Online. എല്ലാ അവകാശങ്ങളും നിക്ഷിപ്തം.
        </div>
      </footer>

      {/* Real-time Toast Notification Alert Popup */}
      <AnimatePresence>
        {newNotifAlert && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 30, scale: 0.95 }}
            className="fixed bottom-6 right-6 z-[9999] max-w-sm w-11/12 sm:w-full bg-slate-900 text-white rounded-2xl shadow-2xl overflow-hidden border border-slate-800 p-4 text-left font-sans"
          >
            <div className="flex items-start gap-3">
              <div className="bg-red-650 p-2 rounded-xl bg-brand-red text-white shrink-0 shadow animate-bounce mt-0.5">
                <Bell className="w-5 h-5" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className="text-[10px] font-black text-red-500 uppercase tracking-widest block leading-none Malayalam">
                    പുതിയ വാർത്താ അപ്‌ഡേറ്റ്! 🔔
                  </span>
                  <button 
                    onClick={() => setNewNotifAlert(null)}
                    className="text-slate-400 hover:text-white transition-colors cursor-pointer"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
                <h4 className="text-xs font-extrabold text-slate-100 line-clamp-1 block">
                  {newNotifAlert.title}
                </h4>
                <p className="text-xs text-slate-300 line-clamp-2 mt-1 leading-normal font-semibold Malayalam">
                  {newNotifAlert.message}
                </p>
                <button
                  onClick={() => {
                    if (newNotifAlert.articleId) {
                      handleSelectArticleById(newNotifAlert.articleId);
                    }
                    setNewNotifAlert(null);
                  }}
                  className="mt-3.5 w-full bg-brand-red hover:bg-brand-dark py-2 px-3 rounded-xl text-[10px] font-black tracking-wide flex items-center justify-center gap-1 cursor-pointer transition-all active:scale-95 shadow-sm text-white"
                >
                  ഈ വാർത്ത വായിക്കാം ➜
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Unified Authentication Modal PopUp overlay */}
      <AnimatePresence>
        {isAuthViewOpened && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center p-4">
            {/* Abs Backdrop overlay */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setIsAuthViewOpened(false)}
              className="absolute inset-0 bg-black/60 backdrop-blur-xs"
            />
            {/* Modal Card wrapper */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 15 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 15 }}
              transition={{ type: "spring", damping: 25 }}
              className="relative z-10 w-full max-w-md"
            >
              <div className="absolute right-4 top-4 z-20">
                <button
                  onClick={() => setIsAuthViewOpened(false)}
                  className="p-1.5 rounded-full bg-gray-150 hover:bg-gray-200 text-gray-500 hover:text-gray-900 transition-colors cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <AuthView
                defaultMode={authViewMode}
                onSuccess={(email, name) => {
                  setIsAuthViewOpened(false);
                  handleAuthSuccess(email, name);
                }}
                onCancel={() => setIsAuthViewOpened(false)}
              />
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Custom Toast Notification System */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, y: 25 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 25 }}
            className="fixed bottom-6 right-6 z-[2000] max-w-sm w-full px-4"
          >
            <div className={`p-4 rounded-2xl shadow-xl flex items-center gap-3 border ${
              toast.type === "success" 
                ? "bg-emerald-50 text-emerald-950 border-emerald-150 shadow-emerald-100" 
                : "bg-red-50 text-red-950 border-red-150 shadow-red-100"
            }`}>
              {toast.type === "success" ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
              ) : (
                <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
              )}
              <p className="text-xs font-extrabold leading-tight text-left">
                {toast.message}
              </p>
              <button 
                onClick={() => setToast(null)}
                className="ml-auto text-gray-400 hover:text-gray-700 cursor-pointer"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
